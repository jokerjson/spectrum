package com.jo.spectrum.global;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.SeekBar;
import android.widget.Toast;

import com.jo.spectrum.R;
import com.mapbox.mapboxsdk.camera.CameraPosition;
import com.mapbox.mapboxsdk.maps.MapboxMap;

/**
 * Created by JO on 2/27/2018.
 */

public class Utils {

    public static void showShortToast(final Context context, final int res_id) {

        (new Handler(Looper.getMainLooper())).post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(context, res_id, Toast.LENGTH_SHORT).show();

            }
        });

    }

    public static void showShortToast(final Context context, final String msg) {
        (new Handler(Looper.getMainLooper())).post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
            }
        });

    }

    public static void log(String log) {
        Log.e("LOG from sandy", log);
    }

    public static void showProgress(final Context context) {

        (new Handler(Looper.getMainLooper())).post(new Runnable() {
            @Override
            public void run() {
                if (GlobalConstant.progressDialog != null) {
                    GlobalConstant.progressDialog.dismiss();
                }

                GlobalConstant.progressDialog = new ProgressDialog(context);
                GlobalConstant.progressDialog.setCancelable(false);
                GlobalConstant.progressDialog.setMessage(context.getString(R.string.please_wait));
                GlobalConstant.progressDialog.show();
            }
        });

    }

    public static void hideProgress() {

        (new Handler(Looper.getMainLooper())).post(new Runnable() {
            @Override
            public void run() {
                if (GlobalConstant.progressDialog == null) {
                    return;
                }

                GlobalConstant.progressDialog.dismiss();
                GlobalConstant.progressDialog = null;
            }
        });


    }
    public static boolean isNetworkConnected(Context context) {
        if(context==null) return false;
        ConnectivityManager cm = (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
        //showShortToast(context,"Server connection error");

        return cm.getActiveNetworkInfo() != null;
    }


    public static int TYPE_WIFI = 1;
    public static int TYPE_MOBILE = 2;
    public static int TYPE_NOT_CONNECTED = 0;
    public static final int NETWORK_STATUS_NOT_CONNECTED=0,NETWORK_STAUS_WIFI=1,NETWORK_STATUS_MOBILE=2;

    public static int getConnectivityStatus(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        if (null != activeNetwork) {
            if(activeNetwork.getType() == ConnectivityManager.TYPE_WIFI)
                return TYPE_WIFI;

            if(activeNetwork.getType() == ConnectivityManager.TYPE_MOBILE)
                return TYPE_MOBILE;
        }
        return TYPE_NOT_CONNECTED;
    }

    public static int getConnectivityStatusString(Context context) {
        int conn = getConnectivityStatus(context);
        int status = 0;
        if (conn == TYPE_WIFI) {
            status = NETWORK_STAUS_WIFI;
        } else if (conn == TYPE_MOBILE) {
            status =NETWORK_STATUS_MOBILE;
        } else if (conn == TYPE_NOT_CONNECTED) {
            status = NETWORK_STATUS_NOT_CONNECTED;
        }
        return status;
    }
  public static  void setMapUtilityToolsInMonintor(final MapboxMap mapboxMap,View rootView) {
      SeekBar seek_zoom =(SeekBar)rootView.findViewById(R.id.seek_zoom);

      seek_zoom.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
          int progressValue=0;
          @Override
          public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
              progressValue = progress;
              CameraPosition cameraPosition = mapboxMap.getCameraPosition();
              CameraPosition new_cameraPosition = new CameraPosition.Builder().target(cameraPosition.target).zoom((double)progressValue).bearing(0).tilt(0).build();
              mapboxMap.setCameraPosition(new_cameraPosition);
          }

          @Override
          public void onStartTrackingTouch(SeekBar seekBar) {

          }

          @Override
          public void onStopTrackingTouch(SeekBar seekBar) {

          }
      });
  }

    public static  void setMapUtilityToolsInReplay(final MapboxMap mapboxMap,View rootView) {
        SeekBar seek_zoom=(SeekBar)rootView.findViewById(R.id.seek_zoom_replay);
        //.setProgress(9);
        //seek_zoom.setProgress((int)mapboxMap.getCameraPosition().zoom);

        seek_zoom.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            int progressValue=0;
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                progressValue=progress;
                CameraPosition cameraPosition= mapboxMap.getCameraPosition();
                CameraPosition new_cameraPosition=new CameraPosition.Builder().target(cameraPosition.target).zoom((double)progressValue).bearing(0).tilt(0).build();
                mapboxMap.setCameraPosition(new_cameraPosition);

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    public static  void setMapUtilityToolsInGeofence(final MapboxMap mapboxMap,View rootView) {
        SeekBar seek_zoom=(SeekBar)rootView.findViewById(R.id.seek_zoom_geofence);
        //seek_zoom.setProgress(9);
        //seek_zoom.setProgress((int)mapboxMap.getCameraPosition().zoom);

        seek_zoom.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            int progressValue=0;
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                progressValue=progress;
                CameraPosition cameraPosition= mapboxMap.getCameraPosition();
                CameraPosition new_cameraPosition=new CameraPosition.Builder().target(cameraPosition.target).zoom((double)progressValue).bearing(0).tilt(0).build();
                mapboxMap.setCameraPosition(new_cameraPosition);

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    public static String trucatLabelString(String name,int toIndex) {
        if(name.length()-1>toIndex)
        {
            name=name.substring(0,toIndex);
            name+="...";
        }

        return name;
    }

}




