package com.jo.spectrum.api;

import android.support.annotation.Nullable;

import java.util.HashMap;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiInterface {

    @POST("auth/login")
    Call<ResponseBody> authLogin(
            @Body HashMap<String, Object> body);

    @POST("auth/register")
    Call<ResponseBody> authRegister(
            @Body HashMap<String, Object> body);

    @POST("auth/verify")
    Call<ResponseBody> authVerify(
            @Body HashMap<String, Object> body);

    @POST("auth/reset-password")
    Call<ResponseBody> resetPassword(
            @Body HashMap<String, Object> body);


    @POST("auth/resend-password-reset")
    Call<ResponseBody> authResendPasswordReset(
            @Body HashMap<String, Object> body);

    @GET("assets")
    Call<ResponseBody> assets(
            @Header("X-CSRFToken") String xCSRFToken);

    @GET("trackers/{id}")
    Call<ResponseBody> trackers_id(
            @Header("X-CSRFToken") String xCSRFToken,
            @Path("id") String trackerId);

    @GET("assets/{id}/logs")
    Call<ResponseBody> assets_logs(
            @Header("X-CSRFToken") String xCSRFToken,
            @Path("id") String trackerId,
            @Query("startDate") String startDate,
            @Query("endDate") String endDate);

    @GET("triplog/{id}/logs")
    Call<ResponseBody> trip_logs(
            @Header("X-CSRFToken") String xCSRFToken,
            @Path("id") String reportingId,
            @Query("startDate") String startDate,
            @Query("endDate") String endDate);

    @GET("alertlog/{id}/logs")
    Call<ResponseBody> event_logs(
            @Header("X-CSRFToken") String xCSRFToken,
            @Path("id") String reportingId,
            @Query("startDate") String startDate,
            @Query("endDate") String endDate);

    @POST("https://app.spectrumtracking.com/php/route.php")
    Call<ResponseBody> tokenizeCreditCard(
            @Body HashMap<String, Object> body);

    @GET("auth")
    Call<ResponseBody> doAuth(
            @Header("X-CSRFToken") String xCSRFToken);

    @PUT("users/{id}")
    Call<ResponseBody> updateCreditCardInfoSecondary(
            @Header("X-CSRFToken") String xCSRFToken,
            @Path("id") String userId,
            @Query("token_type") String tokenType,
            @Query("token_number") String tokenNumber,
            @Query("cardholder_name") String cardholderName,
            @Query("card_type") String cardType,
            @Query("exp_date") String expDate);


    @PUT("assets/{id}")
    Call<ResponseBody> updateAsset(
            @Header("X-CSRFToken") String xCSRFToken,
            @Path("id") String userId,
            @Body HashMap<String, Object> body
            );

    @POST("trackers/register")
    Call<ResponseBody> trackerRegister(
            @Header("X-CSRFToken") String xCSRFToken,
            @Body HashMap<String, Object> body);

    @POST("orders/generateToken")
    Call<ResponseBody> generateToken(
            @Header("X-CSRFToken") String xCSRFToken,
            @Body HashMap<String, Object> body);

    @POST("assets")
    Call<ResponseBody> createAssets(
            @Header("X-CSRFToken") String xCSRFToken,
            @Body HashMap<String, Object> body);

    @POST("orders/payment")
    Call<ResponseBody> ordersPayment(
            @Body HashMap<String, Object> body);

    @POST("trackers/setGeoFence")
    Call<ResponseBody> setGeoFence(
            @Header("X-CSRFToken") String xCSRFToken,
            @Body HashMap<String, Object> body);

    @POST("trackers/modify")
    Call<ResponseBody> modify(
            @Header("X-CSRFToken") String xCSRFToken,
            @Body HashMap<String, Object> body);


    @GET("trackers/byAssetName/{id}")
    Call<ResponseBody> alarm(
            @Header("X-CSRFToken") String xCSRFToken,
            @Path("id") String trackerId);

    @GET("api-interface/coord2AddressMapbox/{latLng}")
    Call<ResponseBody> coord2AddressMapbox(
            @Header("X-CSRFToken") String xCSRFToken,
            @Path("latLng") String latLng);

    @GET("api-interface/coord2AddressMapbox/{latLng}")
    Call<ResponseBody> coord2Address(
            @Header("X-CSRFToken") String xCSRFToken,
            @Path("latLng") String latLng);


    @GET("data/2.5/forecast")
    Call<ResponseBody> getWeather(
           @Query("lat") Double lat,
           @Query("lon") Double lon,
           @Query("APPID") String AppID
    );

}
