package com.jo.spectrum.fragment.datepicker;

import java.util.Calendar;

public interface DateRangePickedListener {

    void OnDateRangePicked(Calendar fromDate, Calendar toDate);

    void OnDatePickCancelled();

}
