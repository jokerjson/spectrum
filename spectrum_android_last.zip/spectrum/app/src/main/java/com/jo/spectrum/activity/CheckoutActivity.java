package com.jo.spectrum.activity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.gson.Gson;
import com.jo.spectrum.R;
import com.jo.spectrum.adapter.OrderSummaryRecyclerViewAdapter;
import com.jo.spectrum.api.ApiClient;
import com.jo.spectrum.api.ApiInterface;
import com.jo.spectrum.global.GlobalConstant;
import com.jo.spectrum.global.Utils;
import com.jo.spectrum.model.OrderService;
import com.jo.spectrum.model.OrderSummary;
import com.jo.spectrum.model.OrderTracker;
import com.jo.spectrum.model.Resp_Error;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CheckoutActivity extends AppCompatActivity {

    Toolbar toolbar;

    @BindView(R.id.sp_checkout_states)
    Spinner spCheckoutStates;


    @BindView(R.id.edit_name_on_card)
    EditText editNameOnCard;

    @BindView(R.id.edit_street_address)
    EditText editStreetAddress;

    @BindView(R.id.edit_city)
    EditText editCity;

    @BindView(R.id.edit_zip)
    EditText editZip;

    @BindView(R.id.edit_card_number)
    EditText editCardNumber;

    @BindView(R.id.edit_expiration_date)
    EditText editExpirationDate;

    @BindView(R.id.edit_cv_code)
    EditText editCVCode;

    public String userId; // get after auth api called

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        ButterKnife.bind(this);

        setToolbar();

        setStateSpinner();

        orderSummaryClicked();

    }

    private void setStateSpinner() {

        String[] states = {
                "Alabama",
                "Alaska",
                "Arizona",
                "Arkansas",
                "California",
                "Colorado",
                "Connecticut",
                "Delaware",
                "District Of Columbia",
                "Florida",
                "Georgia",
                "Hawaii",
                "Idaho",
                "Illinois",
                "Indiana",
                "Iowa",
                "Kansas",
                "Kentucky",
                "Louisiana",
                "Maine",
                "Maryland",
                "Massachusetts",
                "Michigan",
                "Minnesota",
                "Mississippi",
                "Missouri",
                "Montana",
                "Nebraska",
                "Nevada",
                "New Hampshire",
                "New Jersey",
                "New Mexico",
                "New York",
                "North Carolina",
                "North Dakota",
                "Ohio",
                "Oklahoma",
                "Oregon",
                "Pennsylvania",
                "Rhode Island",
                "South Carolina",
                "South Dakota",
                "Tennessee",
                "Texas",
                "Utah",
                "Vermont",
                "Virginia",
                "Washington",
                "West Virginia",
                "Wisconsin",
                "Wyoming"
        };

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, Arrays.asList(states));
        spCheckoutStates.setAdapter(arrayAdapter);
        spCheckoutStates.setSelection(0);
    }

    private void setToolbar() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

    }

  /*  @OnClick(R.id.txt_privacy_policy)
    public void onPrivacyPolicyClicked() {
        final AlertDialog.Builder alertDlgBuilder = new AlertDialog.Builder(this);
        alertDlgBuilder.setTitle("Privacy Policy")
                .setMessage("We will never sell your personal information and we use secure transmission to protect your personal information.")
                .setCancelable(false)
                .setPositiveButton("Okay", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDlgBuilder.show();
    }
*/
   // @OnClick(R.id.txt_order_summary)
    public void orderSummaryClicked() {
        Intent intent = getIntent();

        String from = intent.getExtras().getString("from", "");
        List<OrderSummary> orderSummaryList=new ArrayList<OrderSummary>();



        if ("OrderServiceFragment".equals(from)) {
            // this is from order service fragment
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

            List<OrderService> itemList = GlobalConstant.orderServiceItemList;
            double sum1 = 0, sum2 = 0;
            int index=0;
            for (OrderService item : itemList) {
                index++;
               String tracker=item.name;

               String dataPlan="$"+item.servicePlanList.get(item.selectedServicePlanId).price;
               String LTEData="$"+item.lteDataList.get(item.selectedLTEDataId).price;
               Date dateTd=null;
                try {
                   dateTd=formatter.parse(item.expirationDate);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
               if(dateTd.after(new Date())) dateTd=new Date();
                if(dataPlan.contains("No Service") || dataPlan.equals("")) {
                    dateTd.setMonth(dateTd.getMonth()+1);
                }
                else if(dataPlan.contains("Annual")) {
                    dateTd.setYear(dateTd.getYear()+1);
                    dateTd.setMonth(dateTd.getMonth()+1);
                }
                else {
                    dateTd.setMonth(dateTd.getMonth()+2);
                }

                boolean autoRenew=item.autoReview;
                OrderSummary orderSummary=new OrderSummary();
                orderSummary.vehicle="Vehicle #"+index;
                orderSummary.tracker=tracker;
                orderSummary.dateTd=formatter.format(dateTd);
                orderSummary.dataPlan=dataPlan;
                orderSummary.LTEData=LTEData;
                orderSummary.autoRenew=String.valueOf(autoRenew);
                orderSummaryList.add(orderSummary);

                sum1 += item.servicePlanList.get(item.selectedServicePlanId).price;
                sum2 += item.lteDataList.get(item.selectedLTEDataId).price;

            }

            double amount = sum1 + sum2;

            final Dialog dialog = new Dialog(this, R.style.Dialog);
            dialog.setContentView(R.layout.dialog_order_summary);
            dialog.setTitle("Order Summary");
            dialog.setCancelable(true);

            final SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
            final Date current = new Date();

            RecyclerView orderSummaryRecyclerView=(RecyclerView)dialog.findViewById(R.id.orderSummaryRecyclerView);
            OrderSummaryRecyclerViewAdapter adapter=new OrderSummaryRecyclerViewAdapter(this,orderSummaryList,R.layout.recyclerview_order_summary_row_layout);
            orderSummaryRecyclerView.setAdapter(adapter);
            orderSummaryRecyclerView.setLayoutManager(new LinearLayoutManager(this.getApplicationContext()));
            orderSummaryRecyclerView.setItemAnimator(new DefaultItemAnimator());

            ((TextView) dialog.findViewById(R.id.txt_dlg_order_summary_service_plan)).setText(String.format("$%.2f", sum1));
            ((TextView) dialog.findViewById(R.id.txt_dlg_order_summary_lte_plan)).setText(String.format("$%.2f", sum2));
            ((TextView) dialog.findViewById(R.id.txt_dlg_order_summary_tax)).setText("$0.00");
            ((TextView) dialog.findViewById(R.id.txt_dlg_order_summary_total)).setText(String.format("$%.2f", amount));
            ((TextView) dialog.findViewById(R.id.txt_dlg_order_summary_time)).setText(sdf.format(current));

            Button btnOk = dialog.findViewById(R.id.txt_dlg_order_summary_ok);
            btnOk.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

            dialog.show();
        } else if ("ShippingAddressActivity".equals(from)) {
            // this is order tracker


        }

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @OnClick(R.id.btn_place_your_order)
    public void onPlaceYourOrderClicked() {

        if(!checkEntries()) {
            return;
        }


        Intent intent = getIntent();
        String from = intent.getExtras().getString("from", "");
        if ("OrderServiceFragment".equals(from)) {
            // this is from order service fragment
            doAuth(new Runnable() {
                @Override
                public void run() {
                    doWorkForOrderService();
                }
            });
        } else if ("ShippingAddressActivity".equals(from)) {
            // this is order tracker
            doAuth(new Runnable() {
                @Override
                public void run() {
                    doWorkForOrderTracker();
                }
            });

        }
    }

    private boolean checkEntries() {
        String card = editNameOnCard.getText().toString().trim();
        String streetAddress = editStreetAddress.getText().toString().trim();
        String city = editCity.getText().toString().trim();
        String zipCode = editZip.getText().toString().trim();
        String state = spCheckoutStates.getSelectedItem().toString().trim();
        String cardNumber=editCardNumber.getText().toString().trim();
        String expirationDate=editCardNumber.getText().toString().trim();
        String cvCode=editCVCode.getText().toString().trim();


        if ("".equals(card)) {
            Utils.showShortToast(this, "Please enter card name");
            return false;
        }
        if ("".equals(cardNumber)) {
            Utils.showShortToast(this, "Please enter card number");
            return false;
        }
        if ("".equals(streetAddress)) {
            Utils.showShortToast(this, "Please enter street address");
            return false;
        }
        if ("".equals(city)) {
            Utils.showShortToast(this, "Please enter city");
            return false;
        }
        if ("".equals(zipCode)) {
            Utils.showShortToast(this, "Please enter zip code");
            return false;
        }
        if ("".equals(state)) {
            Utils.showShortToast(this, "Please enter state");
            return false;
        }

        if ("".equals(expirationDate)) {
            Utils.showShortToast(this, "Please enter expiration date");
            return false;
        }
        if ("".equals(cvCode)) {
            Utils.showShortToast(this, "Please enter CV code");
            return false;
        }
        return  true;
    }

    private void doWorkForOrderTracker() {

        List<OrderTracker> itemList = GlobalConstant.orderTrackerList;

        JSONArray paymentItems = new JSONArray();

        try {
            for (OrderTracker item : itemList) {
                ;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


        double amount = 0;

        double subTotal = 0;
        for(OrderTracker tracker: itemList) {
            subTotal += tracker.price * tracker.count;
        }

        double upTax = 1;
        double downTax = 0;
        double shipping;
        double defaultShipping = 0;
        shipping = (subTotal > 0 && subTotal < (100 / upTax)) ? defaultShipping : 0;

        amount = subTotal * upTax + shipping;


       // Utils.showProgress(this);

        ApiInterface apiInterface = ApiClient.getClient(this).create(ApiInterface.class);
        HashMap<String, Object> body = new HashMap<>();

        body.put("tractionType", "purchase");
        body.put("card_holder_name", editNameOnCard.getText().toString());
        body.put("streetaddress", editStreetAddress.getText().toString());
        body.put("city", editCity.getText().toString());
        body.put("zipcode", editZip.getText().toString());
        body.put("card_number", editCardNumber.getText().toString());
        body.put("card_expiry", editExpirationDate.getText().toString().replace("/", ""));
        body.put("card_cvv", editCVCode.getText().toString());
        body.put("currency_code", "USD");
        body.put("amount", amount);
        body.put("items", paymentItems.toString());
        body.put("auth", userId);
        body.put("productService", "card");
        body.put("sendHtml", make_tracker_service_html(itemList));



        apiInterface.ordersPayment(body).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                Utils.hideProgress();

                int code = response.code();
                Gson gson = new Gson();

                if (code == 200) {
                    // success
                    ResponseBody responseBody = response.body();
                    JSONObject object = null;
                    try {
                        object = new JSONObject(responseBody.string());
                        /*String err = object.getString("error");
                        if (!"".equals(err)) {
                            Utils.showShortToast(CheckoutActivity.this, err);
                        } else {
                            Utils.showShortToast(CheckoutActivity.this, "Your have successfully made payment. The confirmation has been sent to your email");
                        }*/
                        String err = object.getString("success");
                        if (!Boolean.parseBoolean(err)) {
                            Utils.showShortToast(CheckoutActivity.this, err);
                           //CheckoutActivity.this.finish();
                            return;
                        } else {
                            Utils.showShortToast(CheckoutActivity.this, "Your have successfully made payment. The confirmation has been sent to your email");
                            gotoMonitor();
                        }


                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(CheckoutActivity.this, "response parse error");
                        //CheckoutActivity.this.finish();
                        return;
                    }
                    //CheckoutActivity.this.finish();
                    return;
                } else {

                    ResponseBody errorBody = response.errorBody();
                    Resp_Error error = null;
                    Utils.hideProgress();
                    try {
                        error = gson.fromJson(errorBody.string(), Resp_Error.class);
                        Utils.showShortToast(CheckoutActivity.this, error.message);
                        return;
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(CheckoutActivity.this, "response parse error");
                        //CheckoutActivity.this.finish();
                        return;
                    }

                }

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Utils.hideProgress();
                t.printStackTrace();
                Utils.showShortToast(CheckoutActivity.this, "server connect error");
            }
        });


    }

    private Object make_tracker_service_html( List<OrderTracker> itemList) {
        String sendHtml="";
        String customer_name= GlobalConstant.shippingAddress.name;
        String card_number=editCardNumber.getText().toString();
        String card_type = "false";
        if (card_number.substring(0).equals("3")) card_type = "American Express";
        if (card_number.substring(0).equals("4")) card_type = "Visa";
        if (card_number.substring(0).equals("5")) card_type = "Mastercard";
        if (card_number.substring(0).equals('6')) card_type = "Discover";
        sendHtml="<p style='text-align:center; font-size:20px; color:blue;'>Order Summary</p>";
        sendHtml+=" <br>  ";
        sendHtml += "<h3>Dear "+customer_name+ ", thank-you for ordering from us!  Here is a summary of your purchase order. </h3>";
        sendHtml+="<table class='order-summay' cellspacing='10' width='390'>";
        sendHtml+="<tbody>";
        sendHtml+="<tr>";

        sendHtml+="<td>Email: </td><td class='order-summay-right-text'>"+GlobalConstant.shippingAddress.email+"</td>";
        sendHtml+="</tr>";
        sendHtml+="<tr>";
        sendHtml+="<td>Name: </td><td class='order-summay-right-text'>"+GlobalConstant.shippingAddress.name+"</td>";
        sendHtml+="</tr>";
        sendHtml+="<tr>";
        sendHtml+="<td>Card type: </td><td class='order-summay-right-text'>"+card_type+"</td>";
        sendHtml+="</tr>";
        sendHtml+="<tr>";

        sendHtml+="<td>Card last 4 digits: </td><td class='order-summay-right-text'>"+card_number.substring(card_number.length()-4,card_number.length())+"</td>";

        sendHtml+="</tr>";
        sendHtml+="<tr>";

        sendHtml+="<td>Shipping Address: </td><td class='order-summay-right-text'>"+GlobalConstant.shippingAddress.streetAddress+"</td>";
        sendHtml+="</tr>";
        sendHtml+="<tr>";
        sendHtml+="<td> </td><td class='order-summay-right-text'>"+GlobalConstant.shippingAddress.streetAddress+"</td>";
        sendHtml+="</tr>";
        sendHtml+="<tr>";
        sendHtml+="<td> </td><td class='order-summay-right-text'>"+GlobalConstant.shippingAddress.streetAddress+"  "+GlobalConstant.shippingAddress.state+"  "+ GlobalConstant.shippingAddress.zipCode+"</td>";
        sendHtml+="</tr>";



        double subTotal=0;

        for(OrderTracker item : itemList){

            String productName= item.name;
            int unit=item.count;
            sendHtml+="<tr>";
            sendHtml+="<td>Product:</td><td class='order-summay-right-text'> "+productName+"</td>";
            sendHtml+="</tr>";
            sendHtml+="<tr>";
            sendHtml+="<td>Unit : </td><td class='order-summay-right-text'> "+unit+"</td>";
            sendHtml+="</tr>";
            subTotal+=item.count*item.price;
        }

        Spinner stateSpinner=(Spinner)findViewById(R.id.sp_checkout_states);

        String state=stateSpinner.getSelectedItem().toString();
        sendHtml+="<tr>";

        double upTax=1.00;
        double downTax=0.00;

        if(state=="Kentucky") {
            upTax=1.06;
            downTax=0.06;
        }
        else  {
            upTax=1.00;
            downTax=0.00;
        }

        //subTotal=parseFloat($("#subtotalCtr").find(".cart-totals-value").html().replace(/[^0-9\.-]+/g,""));
        float taxPrice=(float) (subTotal * downTax);
        float totalPrice=(float)(subTotal * upTax );

        sendHtml+="</tr>";
        sendHtml+="<tr>";
        sendHtml+="<td>Products:</td><td class='order-summay-right-text'>"+"$"+subTotal+"</td>";
        sendHtml+="</tr>";
        sendHtml+="<tr>";
        sendHtml+="<td>Shipping: </td><td class='order-summay-right-text'>"+"$"+ totalPrice+"</td>";
        sendHtml+="</tr>";
        sendHtml+="<tr>";
        sendHtml+="<td>Tax: </td><td class='order-summay-right-text'>"+"$"+taxPrice+"</td>";
        sendHtml+="</tr>";
        sendHtml+="<tr>";

        sendHtml+="<tr>";
        Date now = new Date();
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        //String date=now.getYear()+"-"+now.getMonth()+"-"+now.getDate()+" " +now.toLocaleTimeString();
        sendHtml+="<td>Time: </td><td class='order-summay-right-text'>"+dateFormat.format(now)+"</td>";
        sendHtml+="</tr>";
        sendHtml+="</tbody>";
        sendHtml+="</table>";

        return sendHtml;
    }

    private void doAuth(final Runnable r) {
        Utils.showProgress(this);

        ApiInterface apiInterface = ApiClient.getClient(this).create(ApiInterface.class);

        apiInterface.doAuth(GlobalConstant.X_CSRF_TOKEN).enqueue(new Callback<ResponseBody>() {


            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {


                Utils.hideProgress();

                int code = response.code();

                if (code == 200) {
                    // success
                    ResponseBody responseBody = response.body();
                    JSONObject object = null;
                    try {
                        object = new JSONObject(responseBody.string());

                        CheckoutActivity.this.userId = object.getString("userId");

                        r.run();

                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(CheckoutActivity.this, "response parse error");
                        Utils.hideProgress();
                        //CheckoutActivity.this.finish();
                        return;

                    }
                } else {

                    Utils.showShortToast(CheckoutActivity.this, "failed to get user Id");

                }

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                t.printStackTrace();

                Utils.hideProgress();
                Utils.showShortToast(CheckoutActivity.this, "server connect error");
            }
        });

    }


    private void doWorkForOrderService() {

        List<OrderService> itemList = GlobalConstant.orderServiceItemList;

        JSONArray paymentItems = new JSONArray();

        try {
            for (OrderService item : itemList) {

                if (item.servicePlanList.size() != 1) {
                    String servicePlan = item.servicePlanList.get(item.selectedServicePlanId).servicePlan;


                    JSONObject obj;
                    obj = new JSONObject();
                    obj.put("renew", item.autoReview ? "Yes" : "No");

                    String plaText=item.lteDataList.get(item.selectedLTEDataId).lteData;
                    if(plaText.equals("N\\/A")); plaText="";
                    obj.put("plan", plaText);
                    obj.put("trackerId", item.trackerId);

                    paymentItems.put(obj);

                    obj = new JSONObject();
                    obj.put("renew", item.autoReview ? "Yes" : "No");
                    obj.put("service", true);
                    obj.put("name", servicePlan.substring(0, servicePlan.indexOf(':')));
                    obj.put("lte", item.lteDataList.get(item.selectedLTEDataId).lteData);
                    obj.put("trackerId", item.trackerId);

                    paymentItems.put(obj);

                } else {

                    JSONObject obj;
                    obj = new JSONObject();
                    obj.put("service", true);
                    obj.put("renew", item.autoReview ? "Yes" : "No");
                    String plaText=item.lteDataList.get(item.selectedLTEDataId).lteData;
                    if(plaText.equals("N\\/A")); plaText="";
                    obj.put("plan", plaText);
                    obj.put("trackerId", item.trackerId);
                    paymentItems.put(obj);

                }

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }


        double amount = 0;

        double servicePlanListSum, lteDataListSum;

        servicePlanListSum = 0;
        lteDataListSum = 0;

        for (OrderService item : itemList) {
            servicePlanListSum += item.servicePlanList.get(item.selectedServicePlanId).price;
            lteDataListSum += item.lteDataList.get(item.selectedLTEDataId).price;
        }

        amount = servicePlanListSum + lteDataListSum;


        Utils.showProgress(this);

        ApiInterface apiInterface = ApiClient.getClient(this).create(ApiInterface.class);
        HashMap<String, Object> body = new HashMap<>();

        body.put("tractionType", "purchase");
        body.put("card_holder_name", editNameOnCard.getText().toString());
        body.put("streetaddress", editStreetAddress.getText().toString());
        body.put("city", editCity.getText().toString());
        body.put("zipcode", editZip.getText().toString());
        body.put("card_number", editCardNumber.getText().toString().replace(" ",""));
        String card_expiry=editExpirationDate.getText().toString().replace("/", "");

        if(card_expiry.length()!=4) {
            AlertDialog.Builder alertDialogBuilder=new AlertDialog.Builder(this);
            alertDialogBuilder.setTitle("Warning");
            alertDialogBuilder.setMessage("expiration date format is wrong. Use mmyy. For example, if expiration date is December 2030, use 1230");
            alertDialogBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                   return;
                }
            });
        }

        body.put("card_expiry", card_expiry);
        body.put("card_cvv", editCVCode.getText().toString().replace(" ",""));
        body.put("currency_code", "USD");
        body.put("amount", amount);
        body.put("items", paymentItems.toString());
        body.put("auth", userId);
        body.put("productService", "service");
        // body.put("sendHtml", "Yor order was successfully");
        body.put("sendHtml",make_order_sumary_html(itemList,servicePlanListSum,lteDataListSum,amount));

        apiInterface.ordersPayment(body).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                Utils.hideProgress();

                int code = response.code();
                Gson gson = new Gson();

                if (code == 200) {
                    // success
                    ResponseBody responseBody = response.body();
                    JSONObject object = null;
                    try {
                        object = new JSONObject(responseBody.string());
                        String err = object.getString("success");
                        if (!Boolean.parseBoolean(err)) {
                            Utils.showShortToast(CheckoutActivity.this, err);
                        } else {
                            Utils.showShortToast(CheckoutActivity.this, "Your have successfully made payment. The confirmation has been sent to your email");
                            gotoMonitor();
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(CheckoutActivity.this, "response parse error");
                    }
                    //CheckoutActivity.this.finish();
                    return;
                } else {

                    ResponseBody errorBody = response.errorBody();
                    Resp_Error error = null;

                    try {
                        error = gson.fromJson(errorBody.string(), Resp_Error.class);
                        Utils.showShortToast(CheckoutActivity.this, error.message);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(CheckoutActivity.this, "response parse error");
                    }

                }

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Utils.hideProgress();
                t.printStackTrace();
                Utils.showShortToast(CheckoutActivity.this, "server connect error");
            }
        });


    }

    private String make_order_sumary_html(List<OrderService> itemList,double servicePlanListSum,double lteDataListSum,double amount){

        String sendHtml="";

        //String customer_name = $("#shipping_name").val();
        String card_number=editCardNumber.getText().toString();
        String card_type = "false";
        if (card_number.substring(0).equals("3")) card_type = "American Express";
        if (card_number.substring(0).equals("4")) card_type = "Visa";
        if (card_number.substring(0).equals("5")) card_type = "Mastercard";
        if (card_number.substring(0).equals('6')) card_type = "Discover";


        sendHtml+="<H3>Here is a summary of your purchase order. Thank you for your business.</H3>";
        sendHtml+="<br>";
        sendHtml += "<replace_data>";

        sendHtml+="<table class='order-summay' cellspacing='10' width='390'>";
        sendHtml+="<tbody>";

        //var products = $(".shopping-cart--list-item");

        sendHtml+="<tr>";

        float  upTax=1f;
        float  downTax=0f;


        //var tableElem = document.getElementById('payment_table');
        //console.log(tableElem);


      /*  var rowLen = tableElem.rows.length;
        //console.log(rowLen);
        var lastRow = tableElem.rows[rowLen - 1];

        //console.log(lastRow);
        var servicePrice = parseFloat(lastRow.cells[2].innerHTML).to_$();
        var LTEDataPrice = parseFloat(lastRow.cells[3].innerHTML).to_$();
        var subTotal=parseFloat(lastRow.cells[4].innerHTML);
        var taxPrice = (subTotal*downTax).to_$();
        var totalSum = (subTotal*upTax).to_$();*/


        float taxPrice =(float) (amount*downTax);
        float totalSum = (float)(amount*upTax);

        sendHtml+="</tr>";
        sendHtml+="<tr>";
        sendHtml+="<td>Service Plan:</td><td class='order-summay-right-text'>"+servicePlanListSum+"</td>";
        sendHtml+="</tr>";
        sendHtml+="<tr>";
        //sendHtml+='<td>LTE Plan: </td><td class="order-summay-right-text">'+ $("#shippingCtr").find(".cart-totals-value").html()+'</td>';
        sendHtml+="<td>LTE Plan: </td><td class='order-summay-right-text'>"+ lteDataListSum+"</td>";
        sendHtml+="</tr>";
        sendHtml+="<tr>";
        //sendHtml+='<td>Tax: </td><td class="order-summay-right-text">'+taxPrice+'</td>';
        sendHtml+="<td>Tax: </td><td class='order-summay-right-text'>"+"$"+taxPrice+"</td>";
        sendHtml+="</tr>";
        sendHtml+="<tr>";
        sendHtml+="<td>Total: </td><td class='order-summay-right-text'>"+"$"+totalSum+"</td>";
        sendHtml+="</tr>";
        sendHtml+="<tr>";
        Date now = new Date();
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        //String date=now.getYear()+"-"+now.getMonth()+"-"+now.getDate()+" " +now.toLocaleTimeString();
        sendHtml+="<td>Time: </td><td class='order-summay-right-text'>"+dateFormat.format(now)+"</td>";

        sendHtml+="</tr>";
        sendHtml+="</tbody>";
        sendHtml+="</table>";
        return sendHtml;

    }
    private void gotoMonitor(){
        Intent intent=new Intent(this,MainActivity.class);
        startActivity(intent);
    }

}
