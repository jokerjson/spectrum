package com.jo.spectrum.fragment;

import android.app.AlertDialog;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.CardView;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.LongSerializationPolicy;
import com.google.gson.reflect.TypeToken;
import com.jo.spectrum.R;
import com.jo.spectrum.adapter.AssetListSingleSelectRecyclerViewAdapter;
import com.jo.spectrum.adapter.EventAdapter;
import com.jo.spectrum.api.ApiClient;
import com.jo.spectrum.api.ApiInterface;
import com.jo.spectrum.fragment.datepicker.DatePickerDialog;
import com.jo.spectrum.fragment.datepicker.DateRangePickedListener;
import com.jo.spectrum.global.GlobalConstant;
import com.jo.spectrum.global.Utils;
import com.jo.spectrum.model.Resp_Asset;
import com.jo.spectrum.model.Resp_AssetLog;
import com.jo.spectrum.model.Resp_Error;
import com.jo.spectrum.model.Resp_Event;
import com.jo.spectrum.model.Resp_Tracker;
import com.jo.spectrum.model.Resp_TripLog;


import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import it.carlom.stikkyheader.core.StikkyHeaderBuilder;
import it.carlom.stikkyheader.core.animator.AnimatorBuilder;
import it.carlom.stikkyheader.core.animator.HeaderStikkyAnimator;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EventFragment extends Fragment {

    @BindView(R.id.topView)
    LinearLayout topView;

    @BindView(R.id.rv_replay_right_options)
    RecyclerView rvAssetSingleSelect;

    @BindView(R.id.eventRecyclerView)
    RecyclerView eventRecyclerView;

    @BindView(R.id.startDate)
    TextView txt_start_date;

    @BindView(R.id.endDate)
    TextView txt_end_date;

    @BindView(R.id.bottomView)
    ScrollView bottomView;

    boolean isFragmentAlive = false;

    Calendar replayStartDate;
    Calendar replayEndDate;

    List<Resp_Asset> assetList = null; // entire assets
    List<Resp_Event> assetLogList = null;
    AssetListSingleSelectRecyclerViewAdapter adapter = null;
    EventAdapter event_adapter = null;
    Resp_Asset selectedAsset = null;

    boolean businessUser = false;
    private DatePickerDialog datePickerDialog;
    private DateRangePickedListener dateRangePickedListener;

    public EventFragment() {
        // Required empty public constructor
    }

    public static EventFragment newInstance() {
        EventFragment fragment = new EventFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        isFragmentAlive = true;

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        isFragmentAlive = false;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_events, container, false);

        ButterKnife.bind(this, rootView);

        return rootView;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        getActivity().setTitle("Events");
        initRightPanel();
        loadAllDrivers();
        rvAssetSingleSelect.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        rvAssetSingleSelect.setHasFixedSize(true);
        StikkyHeaderBuilder.stickTo(bottomView)
                .setHeader(topView.getId(), (ViewGroup) getView())
                .minHeightHeader(0)
                .animator(new ParallaxStikkyAnimator())
                .build();
    }
    private class ParallaxStikkyAnimator extends HeaderStikkyAnimator {
        @Override
        public AnimatorBuilder getAnimatorBuilder() {
            View mHeader_image = getHeader().findViewById(R.id.topLayout);
            return AnimatorBuilder.create().applyVerticalParallax(mHeader_image,1);
        }
    }
    private void loadAllDrivers() {

        if (!isFragmentAlive) {
            return;
        }
        if(!Utils.isNetworkConnected(this.getContext())){
            return;
        }
        if (assetList == null) {
            assetList = new ArrayList<>();
        }

        ApiInterface apiInterface = ApiClient.getClient(this.getContext()).create(ApiInterface.class);

        apiInterface.assets(GlobalConstant.X_CSRF_TOKEN).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                if (!isFragmentAlive) {
                    return;
                }

                int code = response.code();

                GsonBuilder gsonBuilder = new GsonBuilder();
                gsonBuilder.setLongSerializationPolicy(LongSerializationPolicy.STRING);

                Gson gson = gsonBuilder.create();

                if (code == 200) {
                    // success
                    ResponseBody responseBody = response.body();
                    JSONObject object = null;

                    try {
                        object = new JSONObject(responseBody.string());
                        JSONArray items = (JSONArray) object.get("items");


                        Type type = new TypeToken<List<Resp_Asset>>() {
                        }.getType();
                        assetList = gson.fromJson(items.toString(), type);

                        for (Resp_Asset asset : assetList) {
                            asset.isSelected = false;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(EventFragment.this.getContext(), "response parse error");
                    }

                    setAssetSingleSelectTableData();

                } else {

                    ResponseBody errorBody = response.errorBody();
                    Resp_Error error = null;
                    try {
                        error = gson.fromJson(errorBody.string(), Resp_Error.class);
                        Utils.showShortToast(EventFragment.this.getContext(), error.message);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(EventFragment.this.getContext(), "response parse error");
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {

                t.printStackTrace();

                if (!isFragmentAlive) {
                    return;
                }

                Utils.showShortToast(EventFragment.this.getContext(), "server connect error");
            }
        });

    }

    private void setAssetSingleSelectTableData() {

        if (!isFragmentAlive) {
            return;
        }
        // items
        adapter = new AssetListSingleSelectRecyclerViewAdapter(this, assetList, R.layout.recyclerview_row_asset_single_select);

        rvAssetSingleSelect.setAdapter(adapter);
        rvAssetSingleSelect.setLayoutManager(new LinearLayoutManager(this.getContext()));
        rvAssetSingleSelect.setItemAnimator(new DefaultItemAnimator());
    }

    private void setEventRecyclerView() {
        if (!isFragmentAlive) {
            return;
        }

        event_adapter = new EventAdapter(this, assetLogList, R.layout.recyclerview_events_row);

        eventRecyclerView.setAdapter(event_adapter);
        eventRecyclerView.setLayoutManager(new LinearLayoutManager(this.getContext()));
        eventRecyclerView.setItemAnimator(new DefaultItemAnimator());
    }
    public void setAddressClick(String url) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(url.replaceAll(" ","")));
        EventFragment.this.getActivity().startActivity(i);
    }
    public void setSelectedAsset(Resp_Asset selectedAsset) {
        if (!isFragmentAlive) {
            return;
        }

        this.selectedAsset = selectedAsset;

        if (adapter != null) {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    adapter.notifyDataSetChanged();
                }
            }, 100);
        }
        loadReplayClick();
    }


    @OnClick(R.id.btn_calendar)
    public void replayStartDateClick() {
        if (!isFragmentAlive) {
            return;
        }
        FragmentManager fragmentManager = this.getActivity().getSupportFragmentManager(); //Initialize fragment manager
        datePickerDialog = DatePickerDialog.newInstance(); // Create datePickerDialog Instance
        dateRangePickedListener=new DateRangePickedListener() {
            @Override
            public void OnDateRangePicked(Calendar from, Calendar to) {
                replayStartDate=from;
                replayEndDate=to;
                setAssetLogStartDate(from);
                setAssetLogEndDate(to);
                loadReplayClick();
            }
            @Override
            public void OnDatePickCancelled() {

            }
        };
        datePickerDialog.setOnDateRangePickedListener(dateRangePickedListener);
        datePickerDialog.show(fragmentManager,"Date Picker1");
    }

    @OnClick(R.id.btn_next)
    public void onNextDay() {
        if (!isFragmentAlive) {
            return;
        }
        replayStartDate.add(Calendar.DAY_OF_YEAR,1);
        replayEndDate.add(Calendar.DAY_OF_YEAR,1);
        setAssetLogStartDate(replayStartDate);
        setAssetLogEndDate(replayEndDate);
        loadReplayClick();
    }

    @OnClick(R.id.btn_prev)
    public void onPrevDay() {
        if (!isFragmentAlive) {
            return;
        }
        replayStartDate.add(Calendar.DAY_OF_YEAR,-1);
        replayEndDate.add(Calendar.DAY_OF_YEAR,-1);
        setAssetLogStartDate(replayStartDate);
        setAssetLogEndDate(replayEndDate);
        loadReplayClick();
    }

    private void initRightPanel() {
        if (!isFragmentAlive) {
            return;
        }
        Calendar day7before_start = Calendar.getInstance();
        day7before_start.add(Calendar.DAY_OF_YEAR, 0);
        setAssetLogStartDate(day7before_start);
        Calendar day7before_end = Calendar.getInstance();
        day7before_end.add(Calendar.DAY_OF_YEAR, 1);
        setAssetLogEndDate(day7before_end);
    }

    private void setAssetLogStartDate(Calendar date) {
        if (!isFragmentAlive) {
            return;
        }
        replayStartDate = date;
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd");
        System.out.println(replayStartDate.getTime().toString());
        txt_start_date.setText(sdf.format(replayStartDate.getTime()));
    }

    private void setAssetLogEndDate(Calendar date) {
        if (!isFragmentAlive) {
            return;
        }
        replayEndDate = date;
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd");
        System.out.println(replayEndDate.getTime().toString());
        txt_end_date.setText(sdf.format(replayEndDate.getTime()));
    }

    public void loadReplayClick() {
        if (!isFragmentAlive) {
            return;
        }
        if(!Utils.isNetworkConnected(this.getContext())){
            return;
        }

        if (selectedAsset == null) {
            Utils.showShortToast(this.getContext(), "please select vehicle");
            return;
        }

        String id = selectedAsset.trackerId;

        ApiInterface apiInterface = ApiClient.getClient(this.getContext()).create(ApiInterface.class);

        apiInterface.trackers_id(GlobalConstant.X_CSRF_TOKEN, id).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                if (!isFragmentAlive) {
                    return;
                }
                int code = response.code();
                GsonBuilder gsonBuilder = new GsonBuilder();
                gsonBuilder.setLongSerializationPolicy(LongSerializationPolicy.STRING);
                Gson gson = gsonBuilder.create();

                if (code == 200) {
                    ResponseBody responseBody = response.body();

                    Resp_Tracker tracker = null;
                    try {
                        String bodyString = responseBody.string();
                        tracker = gson.fromJson(bodyString, Resp_Tracker.class);
                        loadTripLogs(tracker.reportingId);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(EventFragment.this.getContext(), "response parse error");
                    }
                }
                else {
                    ResponseBody errorBody = response.errorBody();
                    Resp_Error error = null;
                    try {
                        error = gson.fromJson(errorBody.string(), Resp_Error.class);
                        Utils.showShortToast(EventFragment.this.getContext(), error.message);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(EventFragment.this.getContext(), "response parse error");
                    }
                }
            }
            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                t.printStackTrace();

                if (!isFragmentAlive) {
                    return;
                }
                Utils.showShortToast(EventFragment.this.getContext(), "server connect error");
            }
        });
    }

    public void loadTripLogs(String reportingId) {

        Date startTime = replayStartDate.getTime();
        Date endTime = replayEndDate.getTime();
        startTime.setHours(0);
        startTime.setMinutes(0);
        startTime.setSeconds(0);

        endTime.setHours(0);
        endTime.setMinutes(0);
        endTime.setSeconds(0);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-M-d HH:mm:ss");
        sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
        String startTimeString = sdf.format(startTime);
        String endTimeString = sdf.format(endTime);

        ApiInterface apiInterface = ApiClient.getClient(this.getContext()).create(ApiInterface.class);

        apiInterface.event_logs(GlobalConstant.X_CSRF_TOKEN, reportingId, startTimeString, endTimeString).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                if (!isFragmentAlive) {
                    return;
                }
                int code = response.code();
                GsonBuilder gsonBuilder = new GsonBuilder();
                gsonBuilder.setLongSerializationPolicy(LongSerializationPolicy.STRING);
                Gson gson = gsonBuilder.create();

                if (code == 200) {
                    ResponseBody responseBody = response.body();
                    JSONObject object = null;

                    assetLogList = null;

                    try {
                        object = new JSONObject("{'items':"+responseBody.string()+"}");
                        JSONArray items = (JSONArray)object.get("items");
                        Log.d("tripLogs",responseBody.string());
                        Type type = new TypeToken<List<Resp_Event>>() {
                        }.getType();
                        assetLogList = gson.fromJson(items.toString(), type);

                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(EventFragment.this.getContext(), "response parse error");
                    }
                    if (assetLogList != null) {

                        if (assetLogList.size() != 0) {
                            setEventRecyclerView();
                        }
                        else {
                            Utils.showShortToast(EventFragment.this.getContext(), "No Data. Change to another day");
                        }
                    }

                }
                else {
                    ResponseBody errorBody = response.errorBody();
                    Resp_Error error = null;
                    try {
                        error = gson.fromJson(errorBody.string(), Resp_Error.class);
                        Utils.showShortToast(EventFragment.this.getContext(), error.message);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(EventFragment.this.getContext(), "response parse error");
                    }
                }
            }
            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                t.printStackTrace();

                if (!isFragmentAlive) {
                    return;
                }
                Utils.showShortToast(EventFragment.this.getContext(), "server connect error");
            }
        });
    }

}
