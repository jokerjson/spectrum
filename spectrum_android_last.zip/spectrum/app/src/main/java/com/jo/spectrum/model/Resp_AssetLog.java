package com.jo.spectrum.model;

import java.util.Date;

/**
 * Created by JO on 3/22/2018.
 */

public class Resp_AssetLog {
    public String _id;
    public String reportingId;
    public double lat;
    public double lng;
    public Date dateTime;
    public double speedInMph;
    public Boolean isGpsValid;
    public double heading;
    public String trackerId;
    public String assetId;
    public String trackerModel;
    public String reportType;

    public huahengType huaheng;
    public sinocastelType sinocastel;
    public mictrackType mictrack;
    public cctrType cctr;
    public int ACCStatus;

    public static class huahengType {

        public double coolantTemp;
        public double aveSpeed;
        public String tripID;
        public double voltage;
        public int alarmNumberAdd1;
        public double mileageM;
        public double fuelConsump;
        public double fuelEfficiency;
        public int RPM;
    }

    public static class sinocastelType {
        public Date ACCOnTime;
        public double currentTripConsum;
        public double currentTripMileage;
        public double totalFuelConsum;
        public double totalMileage;
        public vehicleStatusType vehicleStatus;

    }

    public static class mictrackType {
        public vehicleStatusType vehicleStatus;
    }

    public static class cctrType {
        public vehicleStatusType vehicleStatus;
    }

    public static class vehicleStatusType {

        public int vibration = 0;
        public int dangerousDriving = 0;
        public int noCard = 0;
        public int unlock = 0;
        public int MIL = 0;
        public int OBDError = 0;
        public int powerOff = 0;
        public int noGPSDevice = 0;
        public int privacyStatus = 0;
        public Integer ignitionOn ;
        public int illegalIgnition = 0;
        public int illegalEnter = 0;
        public int tamper = 0;
        public int crash = 0;
        public int emergency = 0;
        public int fatigueDriving = 0;
        public int sharpTurn = 0;
        public int quickLaneChange = 0;
        public int powerOn = 0;
        public int highRPM = 0;
        public int exhauseEmission = 0;
        public Integer idleEngine;
        public Integer hardDece ;
        public Integer hardAcce ;
        public int coolantTemp = 0;
        public Integer speeding;
        public int towing = 0;
        public int lowVoltag = 0;
        public int ACCOff = 0;
        public int lowVoltage = 0;
        public int unPlug = 0;
        public Integer overSpeed2;
        public int batteryLowAlarm = 0;
        public Integer ignitionOff;

    }

}
