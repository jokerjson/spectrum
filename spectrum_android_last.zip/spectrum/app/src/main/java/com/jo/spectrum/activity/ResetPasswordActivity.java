package com.jo.spectrum.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import com.jo.spectrum.R;
import com.jo.spectrum.api.ApiClient;
import com.jo.spectrum.api.ApiInterface;
import com.jo.spectrum.global.Utils;
import com.jo.spectrum.model.Resp_Error;

import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ResetPasswordActivity extends AppCompatActivity {
    @BindView(R.id.reset_email)
    EditText resetEmailTxt;

    @BindView(R.id.reset_verify_code)
    EditText resetVerifyCodeTxt;

    @BindView(R.id.reset_new_password)
    EditText resetNewPasswordTxt;

    @BindView(R.id.reset_confirm_password)
    EditText resetConfirmPasswordTxt;

    @BindView(R.id.btn_reset_password)
    Button btn_resetPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);

        ButterKnife.bind(this);
        Intent intent=getIntent();
        String email=intent.getStringExtra("email");
        resetEmailTxt.setText(email);
    }
    @OnClick(R.id.txt_back)
    public void onBackClick() {
        this.finish();
    }

    @OnClick(R.id.btn_reset_password)
    public void onResetPasswordClick(){
        String email=resetEmailTxt.getText().toString();
        String newPassword=resetNewPasswordTxt.getText().toString();
        String confirmPassword=resetConfirmPasswordTxt.getText().toString();
        String verificationCode=resetVerifyCodeTxt.getText().toString();

        if(email.equals("")) {
            Utils.showShortToast(this, "please enter email");
            return;
        }

        if(newPassword.equals("") || confirmPassword.equals("")){
            Utils.showShortToast(this, "please enter password");
            return;
        }
        if(!newPassword.equals(confirmPassword)) {
            Utils.showShortToast(this, "password confirm does not match");
        }
        if(verificationCode.equals("")) {
            Utils.showShortToast(this, "please enter verification code");
            return;
        }

        ApiInterface apiInterface = ApiClient.getClient(this).create(ApiInterface.class);
        HashMap<String, Object> body = new HashMap<>();
        Utils.showProgress(ResetPasswordActivity.this);
        body.put("email", email);
        body.put("code", verificationCode);
        body.put("password",newPassword);

        apiInterface.resetPassword(body).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {


                int code = response.code();

                if (code == 200) {
                    // success
                    ResponseBody responseBody = response.body();
                    Utils.showShortToast(ResetPasswordActivity.this, "Reset Password has been successfully");

                } else {
                    ResponseBody errorBody = response.errorBody();
                    Resp_Error error = null;
                    try {

                        Utils.showShortToast(ResetPasswordActivity.this, error.message);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(ResetPasswordActivity.this, "Response parse error");
                    }
                }
                Utils.hideProgress();
                //   btnVerify.setEnabled(true);

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Utils.hideProgress();
                t.printStackTrace();
                Utils.showShortToast(ResetPasswordActivity.this, "server connect error");
                // btnVerify.setEnabled(true);
            }
        });

    }

}
