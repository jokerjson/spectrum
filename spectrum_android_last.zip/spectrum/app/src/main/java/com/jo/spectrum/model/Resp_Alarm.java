package com.jo.spectrum.model;

public class Resp_Alarm {

    public String speedLimit;

    public String fatigueTime;

    public String harshTurn;

    public String harshAcceleration;


    public String harshDeceleration;


    public String email;


    public String phoneNumber;


    public Boolean  speedingAlarmStatus;


    public Boolean  fatigueAlarmStatus;


    public Boolean  harshTurnAlarmStatus;


    public Boolean  harshAcceAlarmStatus;


    public Boolean  harshDeceAlarmStatus;


    public Boolean  tamperAlarmStatus;


    public Boolean  geoFenceAlarmStatus;


    public Boolean  emailAlarmStatus;


    public Boolean  phoneAlarmStatus;

    public Boolean accAlarmStatus;

    public Boolean soundAlarmStatus;

    public Boolean vibrationAlarmStatus;

    public Boolean stopAlarmStatus;
}
