package com.jo.spectrum.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.LongSerializationPolicy;
import com.google.gson.reflect.TypeToken;
import com.jo.spectrum.R;
import com.jo.spectrum.activity.CheckoutActivity;
import com.jo.spectrum.adapter.OrderServiceRecyclerViewAdapter;
import com.jo.spectrum.api.ApiClient;
import com.jo.spectrum.api.ApiInterface;
import com.jo.spectrum.global.GlobalConstant;
import com.jo.spectrum.global.Utils;
import com.jo.spectrum.model.LTEData;
import com.jo.spectrum.model.OrderService;
import com.jo.spectrum.model.Resp_Asset;
import com.jo.spectrum.model.Resp_Error;
import com.jo.spectrum.model.Resp_Tracker;
import com.jo.spectrum.model.ServicePlan;
import com.mapbox.mapboxsdk.annotations.Marker;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.mapbox.mapboxsdk.Mapbox.getApplicationContext;

public class OrderServiceFragment extends Fragment {


    @BindView(R.id.rv_order_service)
    RecyclerView rvOrderService;

    @BindView(R.id.txt_service_plan_sum)
    TextView txtServicePlanSum;

    @BindView(R.id.txt_lte_data_sum)
    TextView txtLTEDataSum;

    @BindView(R.id.txt_total_sum)
    TextView txtTotalSum;

    List<Resp_Asset> assetList = null; // entire assets

    Map<Resp_Asset, Resp_Tracker> trackers = null; // trackers

    List<Marker> markers = null;

    OrderServiceRecyclerViewAdapter adapter = null;

    boolean isFragmentAlive;


    public OrderServiceFragment() {
        // Required empty public constructor
    }

    public static OrderServiceFragment newInstance() {
        OrderServiceFragment fragment = new OrderServiceFragment();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        isFragmentAlive = true;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        isFragmentAlive = false;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View rootView = inflater.inflate(R.layout.fragment_order_service, container, false);

        ButterKnife.bind(this, rootView);

        return rootView;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        getActivity().setTitle("Order Service");

        loadAllDrivers();

    }

    private void loadAllDrivers() {

        if (!isFragmentAlive) {
            return;
        }
        if(!Utils.isNetworkConnected(this.getContext())){
            return;
        }

        if (assetList == null) {
            assetList = new ArrayList<>();
        }
        if (trackers == null) {
            trackers = new HashMap<>();
        }

        //Utils.showProgress(this.getContext());

        ApiInterface apiInterface = ApiClient.getClient(this.getContext()).create(ApiInterface.class);

        apiInterface.assets(GlobalConstant.X_CSRF_TOKEN).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                if (!isFragmentAlive) {
                    return;
                }

              //  Utils.hideProgress();


                int code = response.code();

                GsonBuilder gsonBuilder = new GsonBuilder();
                gsonBuilder.setLongSerializationPolicy(LongSerializationPolicy.STRING);

                Gson gson = gsonBuilder.create();

                if (code == 200) {
                    // success
                    ResponseBody responseBody = response.body();
                    JSONObject object = null;

                    try {
                        object = new JSONObject(responseBody.string());
                        JSONArray items = (JSONArray) object.get("items");


                        Type type = new TypeToken<List<Resp_Asset>>() {
                        }.getType();
                        assetList = gson.fromJson(items.toString(), type);

                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(OrderServiceFragment.this.getContext(), "response parse error");
                    }
                    trackers.clear();
                    loadTrackersFrom(0);

                } else {

                    if (!isFragmentAlive) {
                        return;
                    }

                    ResponseBody errorBody = response.errorBody();
                    Resp_Error error = null;
                    try {
                        error = gson.fromJson(errorBody.string(), Resp_Error.class);
                        Utils.showShortToast(OrderServiceFragment.this.getContext(), error.message);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(OrderServiceFragment.this.getContext(), "response parse error");
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                t.printStackTrace();

                if (!isFragmentAlive) {
                    return;
                }

                //Utils.hideProgress();


                Utils.showShortToast(OrderServiceFragment.this.getContext(), "server connect error");
            }
        });

    }

    private void loadTrackersFrom(final int assetIdOnSelectedAssetList) {

        if (!isFragmentAlive) {
            return;
        }
        if(!Utils.isNetworkConnected(this.getContext())){
            return;
        }
        if (assetIdOnSelectedAssetList == assetList.size()) {
            onTrackersAllLoaded();
            return;
        }

        final Resp_Asset asset = assetList.get(assetIdOnSelectedAssetList);

       // Utils.showProgress(this.getContext());

        ApiInterface apiInterface = ApiClient.getClient(this.getContext()).create(ApiInterface.class);

        apiInterface.trackers_id(GlobalConstant.X_CSRF_TOKEN, asset.trackerId).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                if (!isFragmentAlive) {
                    return;
                }

               // Utils.hideProgress();

                int code = response.code();
                Gson gson = new Gson();

                if (code == 200) {
                    // success
                    ResponseBody responseBody = response.body();

                    Resp_Tracker tracker = null;

                    try {
                        String bodyString = responseBody.string();
                        tracker = gson.fromJson(bodyString, Resp_Tracker.class);
                        trackers.put(asset, tracker);

                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(OrderServiceFragment.this.getContext(), "response parse error");
                    }



                } else {
                    ResponseBody errorBody = response.errorBody();
                    Resp_Error error = null;
                    try {
                        error = gson.fromJson(errorBody.string(), Resp_Error.class);
                        Utils.showShortToast(OrderServiceFragment.this.getContext(), error.message);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(OrderServiceFragment.this.getContext(), "response parse error");
                    }
                }
                loadTrackersFrom(assetIdOnSelectedAssetList + 1);
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                t.printStackTrace();
                if (!isFragmentAlive) {
                    return;
                }

               // Utils.hideProgress();

                Utils.showShortToast(OrderServiceFragment.this.getContext(), "server connect error");
            }
        });

    }

    private void onTrackersAllLoaded() {

        if (!isFragmentAlive) {
            return;
        }

        showTable();

    }


    private void showTable() {
//        List<Resp_Tracker> trackerList = new ArrayList<>(trackers.values());
        List<OrderService> items = new ArrayList<>();

        for (Resp_Asset asset : assetList) {

            Resp_Tracker tracker = trackers.get(asset);
            if(tracker == null)continue;
            OrderService item = new OrderService();

            item.name = asset.name;
            item.trackerId = asset.trackerId;

            item.servicePlanList = new ArrayList<>();
            item.lteDataList = new ArrayList<>();

            item.servicePlanList.add(new ServicePlan("No Service: $0.00", 0));
            item.servicePlanList.add(new ServicePlan("Personal Economy: $9.95", 9.95));
            item.servicePlanList.add(new ServicePlan("Personal Premium: $12.95", 12.95));
            item.servicePlanList.add(new ServicePlan("Business Economy: $14.95", 14.95));
            item.servicePlanList.add(new ServicePlan("Business Premium: $17.95", 17.95));
            item.servicePlanList.add(new ServicePlan("International Month: $14.95", 14.95));
            item.servicePlanList.add(new ServicePlan("Personal Economy annual: $99.50", 99.5));
            item.servicePlanList.add(new ServicePlan("Personal Premium annual: $129.50", 129.5));
            item.servicePlanList.add(new ServicePlan("Business Economy annual: $149.50", 149.5));
            item.servicePlanList.add(new ServicePlan("Business Premium annual: $179.50", 179.5));
            item.servicePlanList.add(new ServicePlan("International Annual: $149.5", 149.5));

            item.lteDataList.add(new LTEData("No Data: $0.00", 0));
            item.lteDataList.add(new LTEData("1G LTE Data: $12.50", 12.5));
            item.lteDataList.add(new LTEData("2G LTE Data: $22.00", 22));

            item.servicePlanEnabled = true;
            item.lteDataEnabled = true;
            Date expDate = null;//You will get date object relative to server/client timezone wherever it is parsed

            expDate = tracker.expirationDate;

            String tmp;

            if (!"".equals(tracker.dataPlan) && tracker.dataPlan != null) {
                tmp = tracker.dataPlan;
                for(int i=0;i<item.servicePlanList.size();i++)
                {
                    if(tmp.endsWith(item.servicePlanList.get(i).servicePlan)){
                        item.selectedServicePlanId = i;
                    }
                }
            }
            else  item.selectedServicePlanId = 0;

            if (!"".equals(tracker.LTEData) && tracker.LTEData != null) {
                tmp = tracker.LTEData;
                for(int i=0;i<item.lteDataList.size();i++)
                {
                    if(tmp.endsWith(item.lteDataList.get(i).lteData)){
                        item.selectedLTEDataId = i;
                    }
                }
            }
            else   item.selectedLTEDataId = 0;

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            item.expirationDate = sdf.format(expDate);

            item.autoReview = true;

            items.add(item);
        }

        adapter = new OrderServiceRecyclerViewAdapter(this, items, R.layout.recyclerview_row_order_service);

        rvOrderService.setAdapter(adapter);
        rvOrderService.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        rvOrderService.setItemAnimator(new DefaultItemAnimator());


        updateBottomPrices();

    }


    public void updateBottomPrices() {
        List<OrderService> items = adapter.getItemList();

        double sum1, sum2;

        sum1 = 0;
        sum2 = 0;

        for (OrderService item : items) {
            sum1 += item.servicePlanList.get(item.selectedServicePlanId).price;
            sum2 += item.lteDataList.get(item.selectedLTEDataId).price;
        }

        txtServicePlanSum.setText("$"+String.format("%.2f", sum1));
        txtLTEDataSum.setText("$"+String.format("%.2f", sum2));
        txtTotalSum.setText("$"+String.format("%.2f", sum1 + sum2));

    }

    @OnClick(R.id.btn_proceed_to_checkout)
    public void onProceedToCheckoutClick() {
        Intent intent = new Intent(this.getContext(), CheckoutActivity.class);
        intent.putExtra("from", "OrderServiceFragment");
        if(adapter==null) return;
        GlobalConstant.orderServiceItemList = adapter.getItemList();
        this.startActivity(intent);
    }
}
