package com.jo.spectrum.fragment;


import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import android.hardware.GeomagneticField;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.LongSerializationPolicy;
import com.google.gson.reflect.TypeToken;
import com.jo.spectrum.R;
import com.jo.spectrum.adapter.AssetListMultiSelectRecyclerViewAdapter;
import com.jo.spectrum.adapter.AssetListSingleSelectRecyclerViewAdapter;
import com.jo.spectrum.api.ApiClient;
import com.jo.spectrum.api.ApiInterface;
import com.jo.spectrum.global.GlobalConstant;
import com.jo.spectrum.global.LowPassFilter;
import com.jo.spectrum.global.Utils;
import com.jo.spectrum.libs.MovableFloatingActionButton;
import com.jo.spectrum.model.Resp_Asset;
import com.jo.spectrum.model.Resp_AssetLog;
import com.jo.spectrum.model.Resp_Error;
import com.jo.spectrum.model.Resp_Tracker;
import com.jo.spectrum.tracking.GPSTracker;
import com.jo.spectrum.view.CompassView;
import com.mapbox.mapboxsdk.Mapbox;
import com.mapbox.mapboxsdk.annotations.Icon;
import com.mapbox.mapboxsdk.annotations.IconFactory;
import com.mapbox.mapboxsdk.annotations.Marker;
import com.mapbox.mapboxsdk.annotations.MarkerOptions;
import com.mapbox.mapboxsdk.annotations.MarkerView;
import com.mapbox.mapboxsdk.annotations.MarkerViewOptions;
import com.mapbox.mapboxsdk.annotations.Polyline;
import com.mapbox.mapboxsdk.annotations.PolylineOptions;
import com.mapbox.mapboxsdk.camera.CameraPosition;
import com.mapbox.mapboxsdk.geometry.ILatLng;
import com.mapbox.mapboxsdk.geometry.LatLng;
import com.mapbox.mapboxsdk.geometry.ProjectedMeters;
import com.mapbox.mapboxsdk.maps.MapView;
import com.mapbox.mapboxsdk.maps.MapboxMap;
import com.mapbox.mapboxsdk.maps.OnMapReadyCallback;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Timer;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import it.carlom.stikkyheader.core.StikkyHeaderBuilder;
import it.carlom.stikkyheader.core.animator.AnimatorBuilder;
import it.carlom.stikkyheader.core.animator.HeaderStikkyAnimator;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class GeofenceFragment extends Fragment implements SensorEventListener{


    @BindView(R.id.mapView)
    MapView mapView;

    @BindView(R.id.rv_geofence_right_options)
    RecyclerView rvAssetSingleSelect;

    @BindView(R.id.topView)
    RelativeLayout topView;

    @BindView(R.id.btn_toggle_basemap)
    ImageView btn_toggle_basemap;


    @BindView(R.id.bottomView)
    ScrollView bottomView;

    private float defaultPtZoom=15f;
    private Marker vehicleMarker;


    private Marker moveMarker;
    private String style=GlobalConstant.MAP_BOX_STYLE_URL;

    MapboxMap mapboxMap;

    Boolean onViewCreatedOnceCalled = false;

    List<Resp_Asset> assetList = null; // entire assets

    Resp_Asset selectedAsset = null;
    List<Resp_AssetLog> assetLogList = null;

    AssetListMultiSelectRecyclerViewAdapter adapter = null;

    boolean isFragmentAlive = false;

    private Marker geofenceMarker;
    private Polyline geofecePolyline;
    boolean clicked=false;
    double distance;



    private GPSTracker gpsTracker;
    private GeomagneticField geomagneticField;
    private float[] smoothed;
    private float[] geomagnetic = new float[3];
    private double bearing = 0;
    private float[] rotation = new float[9];
    // orientation (azimuth, pitch, roll)
    private float[] orientation = new float[3];
    private float[] gravity = new float[3];
    private SensorManager mSensorManager;
    private Sensor mSensorAccelerometer;
    private Sensor mSensorMagnetometer;


    public GeofenceFragment() {
        // Required empty public constructor
    }


    // TODO: Rename and change types and number of parameters
    public static GeofenceFragment newInstance() {
        GeofenceFragment fragment = new GeofenceFragment();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        isFragmentAlive = true;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        isFragmentAlive = false;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_geofence, container, false);

        ButterKnife.bind(this, rootView);
        mSensorManager = (SensorManager)this.getActivity().getSystemService(
                Context.SENSOR_SERVICE);
        mSensorAccelerometer = mSensorManager.getDefaultSensor(
                Sensor.TYPE_ACCELEROMETER);
        mSensorMagnetometer = mSensorManager.getDefaultSensor(
                Sensor.TYPE_MAGNETIC_FIELD);

        Mapbox.getInstance(this.getActivity(), GlobalConstant.MAP_BOX_ACCESS_TOKEN);
        return rootView;
    }
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        if (onViewCreatedOnceCalled) {
            return;
        }
        onViewCreatedOnceCalled = true;

        getActivity().setTitle("Geofence");

        initMap(savedInstanceState);
        //seekGeo.getThumb().setColorFilter(Color.RED, PorterDuff.Mode.MULTIPLY);

        loadAllDrivers();

        rvAssetSingleSelect.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        rvAssetSingleSelect.setHasFixedSize(true);

        StikkyHeaderBuilder.stickTo(bottomView)
                .setHeader(topView.getId(), (ViewGroup) getView())
                .minHeightHeader(0)
                .animator(new ParallaxStikkyAnimator())
                .build();
    }
    private class ParallaxStikkyAnimator extends HeaderStikkyAnimator {
        @Override
        public AnimatorBuilder getAnimatorBuilder() {
            View mHeader_image = getHeader().findViewById(R.id.mapView);
            return AnimatorBuilder.create().applyVerticalParallax(mHeader_image,1);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void initMap(Bundle savedInstanceState) {
        final IconFactory iconFactory = IconFactory.getInstance(GeofenceFragment.this.getContext());
        mapView.onCreate(savedInstanceState);

        mapView.setStyleUrl(GlobalConstant.MAP_BOX_STYLE_URL);

        final MyView myView=new MyView(this.getActivity());

        myView.setOnTouchListener(new View.OnTouchListener() {
            float firstX, firstY;
            float secondX, secondY;
            @Override
            public boolean onTouch(View v, MotionEvent event) {


                int action=event.getActionMasked();

                switch(action) {
                    case MotionEvent.ACTION_DOWN:
                        if(clicked){
                           firstX=event.getX();
                           firstY=event.getY();
                        }
                        break;
                    case MotionEvent.ACTION_MOVE:
                        if(clicked){
                            secondX=event.getX();
                            secondY=event.getY();

                            ILatLng firstLatLng=mapboxMap.getProjection().fromScreenLocation(new PointF(firstX,firstY));
                            ILatLng secondLatLng=mapboxMap.getProjection().fromScreenLocation(new PointF(secondX,secondY));

                            Location l1=new Location("first");
                            l1.setLatitude(firstLatLng.getLatitude());
                            l1.setLongitude(firstLatLng.getLongitude());

                            Location l2=new Location("first");
                            l2.setLatitude(secondLatLng.getLatitude());
                            l2.setLongitude(secondLatLng.getLongitude());

                            distance=l1.distanceTo(l2);

                            if(geofecePolyline!=null)  GeofenceFragment.this.mapboxMap.removePolyline(geofecePolyline);
                            PolylineOptions polylineOptions = new PolylineOptions();
                            polylineOptions.color(Color.parseColor("#0000FF"));
                            polylineOptions.width(0.5f); // change the line width here
                            polylineOptions.addAll(getCirclePoints(geofenceMarker.getPosition(), distance));
                            geofecePolyline=mapboxMap.addPolyline(polylineOptions);

                        }
                        break;
                    case MotionEvent.ACTION_UP:
                        if(clicked)
                        {

                            myView.setVisibility(View.GONE);
                            clicked=false;
                            saveGeofence(geofenceMarker.getPosition(),distance);
                        }

                        break;
                }

                return true;
            }
        });

        myView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.FILL_PARENT));

        mapView.addView(myView);
        mapView.bringChildToFront(myView);
        myView.setVisibility(View.GONE);

        mapView.getMapAsync(new OnMapReadyCallback() {
            @Override
            public void onMapReady(final MapboxMap mapboxMap) {
                GeofenceFragment.this.mapboxMap = mapboxMap;
                GeofenceFragment.this.mapboxMap.setCameraPosition(new CameraPosition.Builder().target(new LatLng(38.2534189, -85.7551944)).zoom(defaultPtZoom).build());
                GeofenceFragment.this.mapboxMap.getUiSettings().setRotateGesturesEnabled(false);
                Utils.setMapUtilityToolsInGeofence( GeofenceFragment.this.mapboxMap,mapView.getRootView());
                GeofenceFragment.this.mapboxMap.addOnMapClickListener(new MapboxMap.OnMapClickListener() {
                    @Override
                    public void onMapClick(@NonNull LatLng point) {

                       // mapboxMap.getUiSettings().setScrollGesturesEnabled(false);
                        if(geofenceMarker==null) {
                            geofenceMarker=GeofenceFragment.this.mapboxMap.addMarker(new MarkerOptions()
                                    .position(point)
                                    .setIcon(iconFactory.fromResource(R.drawable.speedingupicon)));
                        }
                        else {
                            GeofenceFragment.this.mapboxMap.removeMarker(geofenceMarker);
                            geofenceMarker=GeofenceFragment.this.mapboxMap.addMarker(new MarkerOptions()
                                    .position(point)
                                    .setIcon(iconFactory.fromResource(R.drawable.speedingupicon)));
                          if(geofecePolyline!=null)  GeofenceFragment.this.mapboxMap.removePolyline(geofecePolyline);
                        }
                        clicked=true;
                        myView.setVisibility(View.VISIBLE);
                    }
                });
            }
        });
    }

    private void saveGeofence(final LatLng position, final double distance) {
        ApiInterface apiInterface = ApiClient.getClient(this.getContext()).create(ApiInterface.class);

        for(Resp_Asset asset:assetList){
            if(asset.isSelected) {
                HashMap<String,Object> param=new HashMap<String,Object>();
                param.put("latGeo",String.valueOf(position.getLatitude()));
                param.put("lngGeo",String.valueOf(position.getLongitude()));
                param.put("radiusGeo",String.valueOf(distance));
                param.put("trackerId",asset.trackerId);
                param.put("plateNumber",asset.name);
                param.put("driverName",asset.driverName);

                apiInterface.setGeoFence(GlobalConstant.X_CSRF_TOKEN,param).enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                        Utils.showShortToast(GeofenceFragment.this.getContext(),"Geofence is set");

                        IconFactory iconFactory = IconFactory.getInstance(GeofenceFragment.this.getContext());
                        Icon icon = iconFactory.fromResource(R.drawable.speedingupicon);

                        if(moveMarker!=null) mapboxMap.removeMarker(moveMarker);

                        ProjectedMeters projectedMeters=mapboxMap.getProjection().getProjectedMetersForLatLng(position);
                        ProjectedMeters converted=new ProjectedMeters(projectedMeters.getNorthing()-distance,projectedMeters.getEasting());
                        LatLng moveMarkerPos=mapboxMap.getProjection().getLatLngForProjectedMeters(converted);

                        MarkerViewOptions markerViewOptions = new MarkerViewOptions()
                                .position(new LatLng(moveMarkerPos))
                                .icon(icon);

                        moveMarker= mapboxMap.addMarker(markerViewOptions);

                    }
                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        Utils.showShortToast(GeofenceFragment.this.getContext(),"Failed");
                    }
                });
            }
        }
    }

    private static ArrayList<LatLng> getCirclePoints(LatLng position, double radius) {
        int degreesBetweenPoints = 10; // change here for shape
        int numberOfPoints = (int) Math.floor(360 / degreesBetweenPoints);
        double distRadians = radius / 6371000.0; // earth radius in meters
        double centerLatRadians = position.getLatitude() * Math.PI / 180;
        double centerLonRadians = position.getLongitude() * Math.PI / 180;
        ArrayList<LatLng> polygons = new ArrayList<>(); // array to hold all the points
        for (int index = 0; index < numberOfPoints; index++) {
            double degrees = index * degreesBetweenPoints;
            double degreeRadians = degrees * Math.PI / 180;
            double pointLatRadians = Math.asin(Math.sin(centerLatRadians) * Math.cos(distRadians)
                    + Math.cos(centerLatRadians) * Math.sin(distRadians) * Math.cos(degreeRadians));
            double pointLonRadians = centerLonRadians + Math.atan2(Math.sin(degreeRadians)
                            * Math.sin(distRadians) * Math.cos(centerLatRadians),
                    Math.cos(distRadians) - Math.sin(centerLatRadians) * Math.sin(pointLatRadians));
            double pointLat = pointLatRadians * 180 / Math.PI;
            double pointLon = pointLonRadians * 180 / Math.PI;
            LatLng point = new LatLng(pointLat, pointLon);
            polygons.add(point);
        }
        // add first point at end to close circle
        polygons.add(polygons.get(0));
        return polygons;
    }
    private void loadAllDrivers() {

        if (!isFragmentAlive) {
            return;
        }
        if(!Utils.isNetworkConnected(this.getContext())){
            return;
        }
        if (assetList == null) {
            assetList = new ArrayList<>();
        }

        ApiInterface apiInterface = ApiClient.getClient(this.getContext()).create(ApiInterface.class);

        apiInterface.assets(GlobalConstant.X_CSRF_TOKEN).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                if (!isFragmentAlive) {
                    return;
                }

                int code = response.code();

                GsonBuilder gsonBuilder = new GsonBuilder();
                gsonBuilder.setLongSerializationPolicy(LongSerializationPolicy.STRING);

                Gson gson = gsonBuilder.create();

                if (code == 200) {
                    // success
                    ResponseBody responseBody = response.body();
                    JSONObject object = null;

                    try {
                        object = new JSONObject(responseBody.string());
                        JSONArray items = (JSONArray) object.get("items");


                        Type type = new TypeToken<List<Resp_Asset>>() {
                        }.getType();
                        assetList = gson.fromJson(items.toString(), type);

                        for (Resp_Asset asset : assetList) {
                            asset.isSelected = false;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(GeofenceFragment.this.getContext(), "response parse error");
                    }

                    setAssetSingleSelectTableData();

                } else {

                    ResponseBody errorBody = response.errorBody();
                    Resp_Error error = null;
                    try {
                        error = gson.fromJson(errorBody.string(), Resp_Error.class);
                        Utils.showShortToast(GeofenceFragment.this.getContext(), error.message);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(GeofenceFragment.this.getContext(), "response parse error");
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {

                t.printStackTrace();

                if (!isFragmentAlive) {
                    return;
                }

                //Utils.hideProgress();

                Utils.showShortToast(GeofenceFragment.this.getContext(), "server connect error");
            }
        });

    }
    private void setAssetSingleSelectTableData() {

        if (!isFragmentAlive) {
            return;
        }

        // items
        adapter = new AssetListMultiSelectRecyclerViewAdapter(this, assetList, R.layout.recyclerview_row_asset_multi_select);

        rvAssetSingleSelect.setAdapter(adapter);
        rvAssetSingleSelect.setLayoutManager(new LinearLayoutManager(this.getContext()));
        rvAssetSingleSelect.setItemAnimator(new DefaultItemAnimator());
    }
    public void setSelectedAsset(Resp_Asset selectedAsset) {

        if (!isFragmentAlive) {
            return;
        }

        this.selectedAsset = selectedAsset;


        if (adapter != null) {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    adapter.notifyDataSetChanged();
                }
            }, 100);

        }
    }
    @OnClick(R.id.btn_toggle_basemap)
    public  void onToogleBaseMapClick()
    {

        Resources resources=this.getActivity().getResources();
        //mapView.setStyleUrl(GlobalConstant.MAP_BOX_STYLE_URL);
        if(style.equals(GlobalConstant.MAP_BOX_STYLE_URL)) {
            style=GlobalConstant.MAP_BOX_SATELLITE_URL;
        }
        else {

            style=GlobalConstant.MAP_BOX_STYLE_URL;
        }
        mapView.setStyleUrl(style);

    }

    public void onRightPanelAssetListCheckChanged(int position, boolean isChecked) {
        if (position >= assetList.size()) {
            return;
        }
        Resp_Asset asset=assetList.get(position);
        asset.isSelected = isChecked;
        if(!asset.isSelected) return;
       // assetList.get(position).
        ApiInterface apiInterface = ApiClient.getClient(this.getContext()).create(ApiInterface.class);

        apiInterface.trackers_id(GlobalConstant.X_CSRF_TOKEN, asset.trackerId).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                //Utils.hideProgress();
                if (!isFragmentAlive) {
                    return;
                }

                //pBarLoading.setVisibility(View.INVISIBLE);

                int code = response.code();
                Gson gson = new Gson();

                if (code == 200) {
                    // success
                    ResponseBody responseBody = response.body();

                    Resp_Tracker tracker = null;

                    try {
                        String bodyString = responseBody.string();
                        tracker = gson.fromJson(bodyString, Resp_Tracker.class);
                        if(tracker.lat==0 || tracker.lng==0 ) return;
                        LatLng point = new LatLng(tracker.lat, tracker.lng);

                        IconFactory iconFactory = IconFactory.getInstance(GeofenceFragment.this.getContext());
                        Icon icon = iconFactory.fromResource(R.drawable.locationcirclesmall_pre);

                        if(vehicleMarker!=null) mapboxMap.removeMarker(vehicleMarker);

                            MarkerViewOptions markerViewOptions = new MarkerViewOptions()
                                .position(point)
                                .icon(icon);

                        //vehicleMarker= mapboxMap.addMarker(markerViewOptions);

                        CameraPosition cameraPosition=new CameraPosition.Builder().target(point).bearing(0).zoom(defaultPtZoom).tilt(0).build();
                        mapboxMap.setCameraPosition(cameraPosition);


                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(GeofenceFragment.this.getContext(), "response parse error");
                    }

                } else {
                    ResponseBody errorBody = response.errorBody();
                    Resp_Error error = null;
                    try {
                        error = gson.fromJson(errorBody.string(), Resp_Error.class);
                        Utils.showShortToast(GeofenceFragment.this.getContext(), error.message);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(GeofenceFragment.this.getContext(), "response parse error");
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Utils.hideProgress();
                t.printStackTrace();
                if (!isFragmentAlive) {
                    return;
                }
                //pBarLoading.setVisibility(View.INVISIBLE);

                Utils.showShortToast(GeofenceFragment.this.getContext(), "server connect error");
            }
        });


    }

    @Override
    public void onStart() {
        super.onStart();
        if (mSensorAccelerometer != null) {
            mSensorManager.registerListener(this, mSensorAccelerometer,
                    SensorManager.SENSOR_DELAY_NORMAL);
        }
        if (mSensorMagnetometer != null) {
            mSensorManager.registerListener(this, mSensorMagnetometer,
                    SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        mSensorManager.unregisterListener(this);
    }
    @Override
    public void onResume() {
        super.onResume();
        Sensor accelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if (accelerometer != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                mSensorManager.registerListener(this, accelerometer,
                        SensorManager.SENSOR_DELAY_NORMAL, SensorManager.SENSOR_DELAY_UI);
            }
        }
        Sensor magneticField = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if (magneticField != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                mSensorManager.registerListener(this, magneticField,
                        SensorManager.SENSOR_DELAY_NORMAL, SensorManager.SENSOR_DELAY_UI);
            }
        }

    }
    @Override
    public  void onStop(){
        super.onStop();

    }




    @Override
    public void onSensorChanged(SensorEvent event) {
        if(gpsTracker==null) {
            gpsTracker=new GPSTracker(this.getActivity());
            gpsTracker.getLocation();

        }

        geomagneticField = new GeomagneticField(
                (float) gpsTracker.getLatitude(),
                (float) gpsTracker.getLongitude(),
                (float) gpsTracker.getAltitude(),
                System.currentTimeMillis());

        boolean accelOrMagnetic = false;

        // get accelerometer data
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            // we need to use a low pass filter to make data smoothed
            smoothed = LowPassFilter.filter(event.values, gravity);
            gravity[0] = smoothed[0];
            gravity[1] = smoothed[1];
            gravity[2] = smoothed[2];
            accelOrMagnetic = true;

        } else if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
            smoothed = LowPassFilter.filter(event.values, geomagnetic);
            geomagnetic[0] = smoothed[0];
            geomagnetic[1] = smoothed[1];
            geomagnetic[2] = smoothed[2];
            accelOrMagnetic = true;

        }

        // get rotation matrix to get gravity and magnetic data
        SensorManager.getRotationMatrix(rotation, null, gravity, geomagnetic);
        // get bearing to target
        SensorManager.getOrientation(rotation, orientation);
        // east degrees of true North
        bearing = orientation[0];
        // convert from radians to degrees
        bearing = Math.toDegrees(bearing);

        // fix difference between true North and magnetical North
        if (geomagneticField != null) {
            bearing += geomagneticField.getDeclination();
        }

        // bearing must be in 0-360
        if (bearing < 0) {
            bearing += 360;
        }


    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }


    class MyView extends View{

     public MyView(Context context) {
         super(context);

     }


  }

}
