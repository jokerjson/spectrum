package com.jo.spectrum.adapter;

import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.jo.spectrum.R;
import com.jo.spectrum.activity.MainActivity;
import com.jo.spectrum.fragment.GeofenceFragment;
import com.jo.spectrum.fragment.MonitorFragment;
import com.jo.spectrum.model.Resp_Asset;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by JO on 3/17/2018.
 */

public class AssetListMultiSelectRecyclerViewAdapter extends RecyclerView.Adapter <AssetListMultiSelectRecyclerViewAdapter.ViewHolder> {


    private List<Resp_Asset> itemList;
    private int itemLayoutResID;
    private Fragment fragment;


    public AssetListMultiSelectRecyclerViewAdapter(Fragment fragment, List<Resp_Asset> itemList, int itemLayoutResID) {
        this.itemList = itemList;
        this.itemLayoutResID = itemLayoutResID;
        this.fragment = fragment;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View viewHolder = LayoutInflater.from(parent.getContext()).inflate(itemLayoutResID, parent, false);
        int height = parent.getMeasuredHeight() / 4;
        viewHolder.setMinimumHeight(25);

        return new AssetListMultiSelectRecyclerViewAdapter.ViewHolder(viewHolder);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {

        final Resp_Asset item = itemList.get(position);

        if(fragment instanceof GeofenceFragment) {
            GeofenceFragment geofenceFragment=(GeofenceFragment)fragment;
            //geofenceFragment.onRightPanelAssetListCheckChanged(position, true);
            //item.isSelected=true;
            //holder.checkReplayRightOptions.setChecked(item.isSelected);
        }

        else holder.checkReplayRightOptions.setChecked(item.isSelected);

        holder.txtVehicleName.setText(item.name);
        holder.txtDriverName.setText(item.driverName);

        holder.checkReplayRightOptions.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if(fragment instanceof MonitorFragment) {
                    MonitorFragment monitorFragment=(MonitorFragment)fragment;
                    monitorFragment.onRightPanelAssetListCheckChanged(position, isChecked);
                    monitorFragment.zoomSelectedVehicles();
                }
                else if(fragment instanceof GeofenceFragment) {
                    GeofenceFragment geofenceFragment=(GeofenceFragment)fragment;
                    geofenceFragment.onRightPanelAssetListCheckChanged(position, isChecked);
                }


            }
        });

        holder.txt_driver_replay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(fragment instanceof MonitorFragment) {
                    MainActivity mainActivity=(MainActivity) fragment.getActivity();
                    mainActivity.showReplayFromMonitor(item);
                }
            }
        });

        holder.itemView.setTag(item);
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.check_replay_right_options)
        CheckBox checkReplayRightOptions;

        @BindView(R.id.txt_vehicle_name)
        TextView txtVehicleName;

        @BindView(R.id.txt_driver_name)
        TextView txtDriverName;

        @BindView(R.id.txt_driver_replay)
        ImageView txt_driver_replay;

        public ViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);

        }
    }

}
