package com.jo.spectrum.fragment;

import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.jo.spectrum.R;
import com.jo.spectrum.activity.MainActivity;
import com.jo.spectrum.api.ApiClient;
import com.jo.spectrum.api.ApiInterface;
import com.jo.spectrum.global.GlobalConstant;
import com.jo.spectrum.global.Utils;

import org.json.JSONObject;

import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ActivateTrackerFragment extends Fragment {


    @BindView(R.id.edit_tracker_id)
    EditText editTrackerId;

    @BindView(R.id.edit_plate_number)
    EditText editPlateNumber;

    @BindView(R.id.edit_card_cvcode)
    EditText editCardCVCode;

    @BindView(R.id.edit_card_name)
    EditText editCardName;

    @BindView(R.id.edit_driver_name)
    EditText editDriverName;

    @BindView(R.id.edit_card_number)
    EditText editCardNumber;

    @BindView(R.id.edit_card_expiry)
    EditText editCardExpiry;

    @BindView(R.id.comment)
    TextView txt_comment;

    boolean isFragmentAlive = false;

    public ActivateTrackerFragment() {
        // Required empty public constructor
    }

    public static ActivateTrackerFragment newInstance() {
        ActivateTrackerFragment fragment = new ActivateTrackerFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_activate_tracker, container, false);

        ButterKnife.bind(this, rootView);

        isFragmentAlive = true;
        String text = "1. Put the <font color=\"#f96f00\">SPECTRUMID</font> on your device into the box below.<br><br>" +
                "2. Plug the tracker into the OBD II port. Click <a href=\"https://www.carmd.com/wp/locating-the-obd2-port-or-dlc-locator/\" color='#f96f00' style=\"text-decoration: none;\">HERE</a> to locate OBD port.<br><br>" +
                "3. You will not be charged when you cancel service 24 hours before the end of 7 day free trial.<br><br>" +
                "Your vehicle should show on the map within 5~10 minutes. If you do not see it on the map, unplug the tracker, wait a few minutes and plug it back to reset.";
        txt_comment.setText(Html.fromHtml(text));
        txt_comment.setMovementMethod(LinkMovementMethod.getInstance());
        return rootView;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        isFragmentAlive = false;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        getActivity().setTitle("Activate Tracker");

    }

    class ActivateTrackerForm {
        String trackerId;
        String plateNumber;
        String cardName;
        String cardNumber;
        String cardCVCode;
        String driverName;
        String cardExpiry;

        public ActivateTrackerForm(String trackerId, String plateNumber, String driverName, String cardName, String cardNumber, String cardExpiry,String cardCVCode) {
            this.trackerId = trackerId;
            this.plateNumber = plateNumber;
            this.cardName = cardName;
            this.cardNumber = cardNumber;
            this.driverName = driverName;
            this.cardExpiry = cardExpiry;
            this.cardCVCode = cardCVCode;
        }
    }

    @OnClick(R.id.btn_activate)
    public void onActivateClick() {
        if(!Utils.isNetworkConnected(this.getContext())){
            return;
        }

        String trackerId = editTrackerId.getText().toString().trim();
        String plateNumber = editPlateNumber.getText().toString().trim();
        String cardName = editCardName.getText().toString().trim();
        String cardNumber = editCardNumber.getText().toString().trim();
        String driverName = editDriverName.getText().toString().trim();
        String cardExpiry = editCardExpiry.getText().toString().trim();
        String cardCVCode = editCardCVCode.getText().toString().trim();

        if("".equals(trackerId)) {
            Utils.showShortToast(this.getContext(), "please enter tracker ID");
            return;
        }

        if(cardExpiry.length() != 4) {
            Utils.showShortToast(this.getContext(), "expiration date format is wrong. Use mmyy. For example, if expiration date is December 2030, use 1230");
            return;
        }

        trackerId = trackerId.replaceAll("/(^\\s+|\\s+$)/", "").toUpperCase();
        cardNumber = cardNumber.replaceAll("/\\s+/g","");
        cardCVCode = cardCVCode.replaceAll("/\\s+/g","");

        final ActivateTrackerForm activateTrackerForm = new ActivateTrackerForm(trackerId, plateNumber, driverName, cardName, cardNumber, cardExpiry, cardCVCode);

        Utils.showProgress(this.getActivity());

        ApiInterface apiInterface = ApiClient.getClient(this.getContext()).create(ApiInterface.class);

        final String finalTrackerId = trackerId;

        apiInterface.doAuth(GlobalConstant.X_CSRF_TOKEN).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                Utils.hideProgress();

                int code = response.code();

                if (code == 200) {
                    // success
                    ResponseBody responseBody = response.body();
                    JSONObject object = null;
                    try {
                        object = new JSONObject(responseBody.string());
                        String userId = object.getString("userId");
                        String email=object.getString("email");

                        generateToken(userId, email, activateTrackerForm);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(ActivateTrackerFragment.this.getContext(), "response parse error");
                    }
                } else {
                    Utils.showShortToast(ActivateTrackerFragment.this.getContext(), "failed to auth");
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Utils.hideProgress();
                t.printStackTrace();
                Utils.showShortToast(ActivateTrackerFragment.this.getContext(), "server connect error");
            }
        });
    }
    private  void generateToken(final String userId, final String email, final ActivateTrackerForm activateTrackerForm) {
        if(!Utils.isNetworkConnected(this.getContext())){
            return;
        }
        Utils.showProgress(this.getActivity());

        ApiInterface apiInterface = ApiClient.getClient(this.getContext()).create(ApiInterface.class);

        HashMap<String, Object> body = new HashMap<>();

        body.put("card_holder_name", activateTrackerForm.cardName);
        body.put("auth", userId);
        body.put("card_number", activateTrackerForm.cardNumber);
        body.put("card_expiry", activateTrackerForm.cardExpiry);
        body.put("card_cvv", activateTrackerForm.cardCVCode);


        apiInterface.generateToken(GlobalConstant.X_CSRF_TOKEN,body).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                Utils.hideProgress();

                int code = response.code();

                if (code == 200) {
                    // success
                    ResponseBody responseBody = response.body();
                    JSONObject object = null;
                    try {
                        object = new JSONObject(responseBody.string());
                        if (!object.has("error")) {
                            registerTracker(userId, email, activateTrackerForm);
                        }
                        else {
                            Utils.showShortToast(ActivateTrackerFragment.this.getContext(), object.getString("error"));
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(ActivateTrackerFragment.this.getContext(), "response parse error");
                    }
                } else {
                    Utils.showShortToast(ActivateTrackerFragment.this.getContext(), "failed to register tracker");
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Utils.hideProgress();
                t.printStackTrace();
                Utils.showShortToast(ActivateTrackerFragment.this.getContext(), "server connect error");
            }
        });
    }
    private void registerTracker(final String userId, String email, final ActivateTrackerForm activateTrackerForm) {

        if(!Utils.isNetworkConnected(this.getContext())){
            return;
        }
        Utils.showProgress(this.getActivity());

        ApiInterface apiInterface = ApiClient.getClient(this.getContext()).create(ApiInterface.class);

        HashMap<String, Object> body = new HashMap<>();

        body.put("spectrumId", activateTrackerForm.trackerId);
        body.put("userId", userId);
        body.put("email",email);

        apiInterface.trackerRegister(GlobalConstant.X_CSRF_TOKEN,body).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                Utils.hideProgress();

                int code = response.code();

                if (code == 200) {
                    // success
                    ResponseBody responseBody = response.body();
                    JSONObject object = null;
                    try {
                        object = new JSONObject(responseBody.string());
                        String trackerId = object.getString("_id");

                        modify(userId, trackerId, activateTrackerForm);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(ActivateTrackerFragment.this.getContext(), "response parse error");
                    }
                } else {
                    Utils.showShortToast(ActivateTrackerFragment.this.getContext(), "failed to register tracker");
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Utils.hideProgress();
                t.printStackTrace();
                Utils.showShortToast(ActivateTrackerFragment.this.getContext(), "server connect error");
            }
        });
    }
    private void modify(final String userId, final String trackerId, final ActivateTrackerForm activateTrackerForm) {
        if(!Utils.isNetworkConnected(this.getContext())){
            return;
        }
        Utils.showProgress(this.getActivity());

        ApiInterface apiInterface = ApiClient.getClient(this.getContext()).create(ApiInterface.class);

        HashMap<String, Object> body = new HashMap<>();

        body.put("id", trackerId);
        body.put("driverName", activateTrackerForm.driverName);
        body.put("operation", "createNew");

        apiInterface.modify(GlobalConstant.X_CSRF_TOKEN,body).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                Utils.hideProgress();

                int code = response.code();

                if (code == 200) {
                    doFinialRegisterTrackerWork(userId,trackerId,activateTrackerForm);
                } else {
                    Utils.showShortToast(ActivateTrackerFragment.this.getContext(), "failed to register tracker");
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Utils.hideProgress();
                t.printStackTrace();
                Utils.showShortToast(ActivateTrackerFragment.this.getContext(), "server connect error");
            }
        });
    }
    private void doFinialRegisterTrackerWork(String userId, String trackerId, ActivateTrackerForm activateTrackerForm) {

        Utils.showProgress(this.getActivity());

        ApiInterface apiInterface = ApiClient.getClient(this.getContext()).create(ApiInterface.class);

        HashMap<String, Object> body = new HashMap<>();

        String plateNumber=activateTrackerForm.plateNumber;
        String driverName=activateTrackerForm.driverName;


        if(plateNumber.equals("")) {
            plateNumber=activateTrackerForm.trackerId;
        }
        if(driverName.equals("")) {
            driverName="driver";
        }

        body.put("name", plateNumber);
        body.put("trackerId", trackerId);
        body.put("userId", userId);
        body.put("driverName", driverName);
        body.put("spectrumId", activateTrackerForm.trackerId);

        apiInterface.createAssets(GlobalConstant.X_CSRF_TOKEN,body).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                Utils.hideProgress();

                int code = response.code();

                if (code == 201) {
                    // success
                    Utils.showShortToast(ActivateTrackerFragment.this.getContext(), "success create an asset");
                    MainActivity mainActivity= (MainActivity) ActivateTrackerFragment.this.getActivity();
                    mainActivity.showMonitorFragment();
                } else {
                    Utils.showShortToast(ActivateTrackerFragment.this.getContext(), "asset creation failed");
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Utils.hideProgress();
                t.printStackTrace();
                Utils.showShortToast(ActivateTrackerFragment.this.getContext(), "server connect error");
            }
        });
    }
}
