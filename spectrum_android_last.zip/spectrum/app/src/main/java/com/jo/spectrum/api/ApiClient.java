package com.jo.spectrum.api;


import android.content.Context;

import com.jo.spectrum.global.GlobalConstant;

import java.io.IOException;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.util.concurrent.TimeUnit;

import okhttp3.Interceptor;
import okhttp3.JavaNetCookieJar;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class ApiClient {

    static Retrofit retrofit = null;

    public static Retrofit getClient(Context ctx) {

        HttpLoggingInterceptor httpLoggingInterceptor = new HttpLoggingInterceptor();
        httpLoggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);

        CookieHandler cookieHandler = new CookieManager(new PersistentCookieStore(ctx), CookiePolicy.ACCEPT_ALL);

        OkHttpClient.Builder httpClient = new OkHttpClient.Builder().connectTimeout(60, TimeUnit.SECONDS).readTimeout(30,TimeUnit.SECONDS).writeTimeout(15,TimeUnit.SECONDS);
        httpClient.cookieJar(new JavaNetCookieJar(cookieHandler));
        httpClient.addInterceptor(httpLoggingInterceptor);

        OkHttpClient client = httpClient.build();


        retrofit = new Retrofit.Builder()
                .baseUrl(GlobalConstant.WEB_API_BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)

                .build();

        return retrofit;
    }


    public static Retrofit getWeatherClient(Context ctx) {

        HttpLoggingInterceptor httpLoggingInterceptor = new HttpLoggingInterceptor();
        httpLoggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);

        CookieHandler cookieHandler = new CookieManager(new PersistentCookieStore(ctx), CookiePolicy.ACCEPT_ALL);

        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
        httpClient.cookieJar(new JavaNetCookieJar(cookieHandler));
        httpClient.addInterceptor(httpLoggingInterceptor);

        OkHttpClient client = httpClient.build();

        retrofit = new Retrofit.Builder()
                .baseUrl(GlobalConstant.WEATHER_API_BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();

        return retrofit;
    }



}
