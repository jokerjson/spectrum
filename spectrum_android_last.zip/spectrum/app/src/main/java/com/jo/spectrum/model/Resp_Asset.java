package com.jo.spectrum.model;

/**
 * Created by JO on 3/21/2018.
 */

public class Resp_Asset implements  Cloneable{

    public String _id;
    public String name;
    public String trackerId;
    public String userId;
    public String driverName;
    public String driverPhoneNumber;
    public String __v;
    public Boolean isSelected;
    public Resp_Asset clone(){
        try {
            return  (Resp_Asset)super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        return null;
    }

}
