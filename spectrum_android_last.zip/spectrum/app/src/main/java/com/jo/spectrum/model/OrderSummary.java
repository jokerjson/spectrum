package com.jo.spectrum.model;

public class OrderSummary {
    public String  vehicle;
    public String  tracker;

    public String  dataPlan;
    public String  LTEData;
    public String  dateTd;
    public String  autoRenew;

}
