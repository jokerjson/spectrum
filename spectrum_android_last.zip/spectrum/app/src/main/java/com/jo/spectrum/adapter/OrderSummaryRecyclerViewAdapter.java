package com.jo.spectrum.adapter;

import android.app.Activity;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.TextView;

import com.jo.spectrum.R;
import com.jo.spectrum.model.OrderSummary;
import com.jo.spectrum.model.Resp_Asset;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class OrderSummaryRecyclerViewAdapter extends RecyclerView.Adapter <OrderSummaryRecyclerViewAdapter.ViewHolder>{
    private List<OrderSummary> itemList;
    private int itemLayoutResID;
    private Activity acitivity;
    public OrderSummaryRecyclerViewAdapter(Activity activity, List<OrderSummary> itemList, int itemLayoutResID){
        this.acitivity=activity;
        this.itemList=itemList;
        this.itemLayoutResID=itemLayoutResID;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View viewHolder = LayoutInflater.from(parent.getContext()).inflate(itemLayoutResID, parent, false);

        return new OrderSummaryRecyclerViewAdapter.ViewHolder(viewHolder);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        OrderSummary item=itemList.get(position);
        holder.summaryVehicleTextView.setText(item.vehicle);
        holder.summaryTrackerTextView.setText(item.tracker);
        holder.summaryDataplanTextView.setText(item.dataPlan);
        holder.summaryLTEDataTextView.setText(item.LTEData);
        holder.summaryDateTdTextView.setText(item.dateTd);
        holder.summaryAutoRenewTextView.setText(item.autoRenew);
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {


        @BindView(R.id.summary_vehicle)
        TextView summaryVehicleTextView;

        @BindView(R.id.summary_tracker)
        TextView summaryTrackerTextView;

        @BindView(R.id.summary_dataplan)
        TextView summaryDataplanTextView;

        @BindView(R.id.summary_LTEData)
        TextView summaryLTEDataTextView;

        @BindView(R.id.summary_dateTd)
        TextView summaryDateTdTextView;

        @BindView(R.id.summary_autorenew)
        TextView summaryAutoRenewTextView;


        public ViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);

        }
    }

}
