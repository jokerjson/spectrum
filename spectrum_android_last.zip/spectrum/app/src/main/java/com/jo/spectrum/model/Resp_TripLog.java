package com.jo.spectrum.model;

import java.util.Date;

public class Resp_TripLog {
    public int fatigueDriving;
    public double fuel;
    public int harshAcce;
    public int harshDece;
    public int idle;
    public double maxSpeed;
    public double mileage;
    public int speeding;
    public int stops;
}
