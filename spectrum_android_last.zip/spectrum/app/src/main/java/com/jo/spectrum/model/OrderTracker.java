package com.jo.spectrum.model;

/**
 * Created by JO on 3/17/2018.
 */

public class OrderTracker {
    public String image;
    public String name;
    public String description;
    public Integer count;
    public Double price;
}
