package com.jo.spectrum.model;

public class City {
    public long id;
    public String name;
    public Coord  coord;
    public  String country;
    public class Coord {
        double lat;
        double lon;
    }
}
