package com.jo.spectrum.adapter;

import android.content.Intent;
import android.net.Uri;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.TextView;

import com.jo.spectrum.R;
import com.jo.spectrum.fragment.AlarmFragment;
import com.jo.spectrum.fragment.EventFragment;
import com.jo.spectrum.fragment.GeofenceFragment;
import com.jo.spectrum.fragment.ReplayFragment;
import com.jo.spectrum.fragment.ReportsFragment;
import com.jo.spectrum.model.Resp_Asset;
import com.jo.spectrum.model.Resp_Event;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import okhttp3.ResponseBody;
import retrofit2.Callback;

/**
 * Created by JO on 3/17/2018.
 */

public class EventAdapter extends RecyclerView.Adapter <EventAdapter.ViewHolder> {


    private List<Resp_Event> itemList;
    private int itemLayoutResID;
    private Fragment fragment;


    public EventAdapter(Fragment fragment, List<Resp_Event> itemList, int itemLayoutResID) {
        this.itemList = itemList;
        this.itemLayoutResID = itemLayoutResID;
        this.fragment = fragment;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View viewHolder = LayoutInflater.from(parent.getContext()).inflate(itemLayoutResID, parent, false);
        viewHolder.setMinimumHeight(25);
        return new EventAdapter.ViewHolder(viewHolder);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {

        final Resp_Event item = itemList.get(itemList.size()-position-1);

        holder.date.setText(item.localDateTime);
        holder.event.setText(item.alarm);
        holder.address.setTag(new Integer(position));

        holder.address.setOnClickListener(new CompoundButton.OnClickListener() {

            @Override
            public void onClick(View v) {
                TextView cb = (TextView) v;
                int clickedPos = ((Integer)cb.getTag()).intValue();
                if(fragment instanceof EventFragment) {
                    ((EventFragment) fragment).setAddressClick(item.address);
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.date)
        TextView date;

        @BindView(R.id.event)
        TextView event;

        @BindView(R.id.address)
        TextView address;


        public ViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);

        }
    }

}






