package com.jo.spectrum.adapter;

import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.TextView;

import com.jo.spectrum.R;
import com.jo.spectrum.fragment.AlarmFragment;
import com.jo.spectrum.fragment.EventFragment;
import com.jo.spectrum.fragment.GeofenceFragment;
import com.jo.spectrum.fragment.ReplayFragment;
import com.jo.spectrum.fragment.ReportsFragment;
import com.jo.spectrum.model.Resp_Asset;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by JO on 3/17/2018.
 */

public class AssetListSingleSelectRecyclerViewAdapter extends RecyclerView.Adapter <AssetListSingleSelectRecyclerViewAdapter.ViewHolder> {


    private List<Resp_Asset> itemList;
    private int itemLayoutResID;
    private Fragment fragment;


    public AssetListSingleSelectRecyclerViewAdapter(Fragment fragment, List<Resp_Asset> itemList, int itemLayoutResID) {
        this.itemList = itemList;
        this.itemLayoutResID = itemLayoutResID;
        this.fragment = fragment;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View viewHolder = LayoutInflater.from(parent.getContext()).inflate(itemLayoutResID, parent, false);
        int height = parent.getMeasuredHeight() / 4;
        viewHolder.setMinimumHeight(25);
        return new AssetListSingleSelectRecyclerViewAdapter.ViewHolder(viewHolder);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {

        final Resp_Asset item = itemList.get(position);

        holder.radioReplayRightOptions.setChecked(item.isSelected);
        holder.txtVehicleName.setText(item.name);
        holder.txtDriverName.setText(item.driverName);

        holder.itemView.setTag(new Integer(position));
        holder.radioReplayRightOptions.setTag(new Integer(position));

        if(position == 0 && itemList.get(0).isSelected && holder.radioReplayRightOptions.isChecked())
        {
            lastChecked = holder.radioReplayRightOptions;
            lastCheckedPos = 0;
        }
        holder.radioReplayRightOptions.setOnClickListener(new CompoundButton.OnClickListener() {

            @Override
            public void onClick(View v) {
                RadioButton cb = (RadioButton) v;
              //  if(cb.isChecked()) return;
                int clickedPos = ((Integer)cb.getTag()).intValue();

                for(int i=0;i<itemList.size();i++) {
                    if(clickedPos!=i) {
                        itemList.get(i).isSelected=false;
                    }
                    else itemList.get(i).isSelected=true;
                }

                if(lastChecked!=null)
                        if(lastChecked.equals(cb))
                        {
                            return;
                        }

                lastChecked = cb;
                lastCheckedPos = clickedPos;

                if(fragment instanceof ReplayFragment) {
                    ((ReplayFragment) fragment).setSelectedAsset(itemList.get(position));
                    ((ReplayFragment) fragment).loadReplayClick();
                } else if(fragment instanceof ReportsFragment) {
                    ((ReportsFragment) fragment).setSelectedAsset(itemList.get(position));
                    ((ReportsFragment) fragment).loadReplayClick();
                }
                else if(fragment instanceof AlarmFragment) {
                    ((AlarmFragment) fragment).setSelectedAsset(itemList.get(position));
                }
                else if(fragment instanceof EventFragment) {
                    ((EventFragment) fragment).setSelectedAsset(itemList.get(position));
                }

            }
        });


    }
    private static RadioButton lastChecked = null;
    private static int lastCheckedPos = 0;

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.radio_replay_right_options)
        RadioButton radioReplayRightOptions;

        @BindView(R.id.txt_vehicle_name)
        TextView txtVehicleName;

        @BindView(R.id.txt_driver_name)
        TextView txtDriverName;


        public ViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);

        }
    }

}






