package com.jo.spectrum.fragment;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Switch;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.LongSerializationPolicy;
import com.google.gson.reflect.TypeToken;
import com.jo.spectrum.R;
import com.jo.spectrum.adapter.AssetListSingleSelectRecyclerViewAdapter;
import com.jo.spectrum.api.ApiClient;
import com.jo.spectrum.api.ApiInterface;
import com.jo.spectrum.global.GlobalConstant;
import com.jo.spectrum.global.Utils;
import com.jo.spectrum.model.Resp_Alarm;
import com.jo.spectrum.model.Resp_Asset;
import com.jo.spectrum.model.Resp_AssetLog;
import com.jo.spectrum.model.Resp_Error;
import com.jo.spectrum.widget.CustomSwitch;
import com.mapbox.mapboxsdk.Mapbox;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import it.carlom.stikkyheader.core.StikkyHeaderBuilder;
import it.carlom.stikkyheader.core.animator.AnimatorBuilder;
import it.carlom.stikkyheader.core.animator.HeaderStikkyAnimator;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AlarmFragment extends Fragment {


    @BindView(R.id.rv_alarm_right_options)
    RecyclerView rvAssetSingleSelect;

    @BindView(R.id.topView)
    RelativeLayout topView;

    @BindView(R.id.userTracker_speedLimit)
    EditText txt_userTracker_speedLimit;

    @BindView(R.id.userTracker_fatigueTime)
    EditText txt_userTracker_fatigueTime;

    @BindView(R.id.userTracker_email)
    EditText txt_userTracker_email;

    @BindView(R.id.userTracker_phoneNumber)
    EditText txt_userTracker_phoneNumber;

    @BindView(R.id.speedingAlarmStatus)
    CustomSwitch  s_speedingAlarmStatus;

    @BindView(R.id.fatigueAlarmStatus)
    CustomSwitch  s_fatigueAlarmStatus;

    @BindView(R.id.harshTurnAlarmStatus)
    CustomSwitch  s_harshTurnAlarmStatus;

    @BindView(R.id.harshAcceAlarmStatus)
    CustomSwitch  s_harshAcceAlarmStatus;

    @BindView(R.id.harshDeceAlarmStatus)
    CustomSwitch  s_harshDeceAlarmStatus;

    @BindView(R.id.tamperAlarmStatus)
    CustomSwitch  s_tamperAlarmStatus;

    @BindView(R.id.geoFenceAlarmStatus)
    CustomSwitch  s_geoFenceAlarmStatus;

    @BindView(R.id.engineAlarmStatus)
    CustomSwitch  s_engineAlarmStatus;



    @BindView(R.id.emailAlarmStatus)
    CustomSwitch s_emailAlarmStatus;

    @BindView(R.id.phoneAlarmStatus)
    CustomSwitch  s_phoneAlarmStatus;

    @BindView(R.id.switch_alertsound)
    CustomSwitch  s_alertSound;

    @BindView(R.id.switch_vibration)
    CustomSwitch  s_vibration;

    @BindView(R.id.engineOffAlarmStatus)
    CustomSwitch  s_engineOffAlarmStatus;

    @BindView(R.id.btn_set_alarm)
    Button btn_set_alarm;

    @BindView(R.id.bottomView)
    ScrollView bottomView;

    Boolean onViewCreatedOnceCalled = false;

    List<Resp_Asset> assetList = null; // entire assets

    Resp_Asset selectedAsset = null;
    List<Resp_AssetLog> assetLogList = null;

    AssetListSingleSelectRecyclerViewAdapter adapter = null;

    boolean isFragmentAlive = false;
    public AlarmFragment() {
        // Required empty public constructor
    }


    // TODO: Rename and change types and number of parameters
    public static AlarmFragment newInstance() {
        AlarmFragment fragment = new AlarmFragment();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        isFragmentAlive = true;

    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();

        isFragmentAlive = false;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_alarm, container, false);
        ButterKnife.bind(this, rootView);

        Mapbox.getInstance(this.getActivity(), GlobalConstant.MAP_BOX_ACCESS_TOKEN);
        return rootView;
    }
    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        if (onViewCreatedOnceCalled) {
            return;
        }
        onViewCreatedOnceCalled = true;

        getActivity().setTitle("Set Alarm");

        loadAllDrivers();

        rvAssetSingleSelect.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        rvAssetSingleSelect.setHasFixedSize(true);

        StikkyHeaderBuilder.stickTo(bottomView)
                .setHeader(topView.getId(), (ViewGroup) getView())
                .minHeightHeader(0)
                .animator(new ParallaxStikkyAnimator())
                .build();
    }
    private class ParallaxStikkyAnimator extends HeaderStikkyAnimator {
        @Override
        public AnimatorBuilder getAnimatorBuilder() {
            View mHeader_image = getHeader().findViewById(R.id.topScroll);
            return AnimatorBuilder.create().applyVerticalParallax(mHeader_image,1);
        }
    }

    private void loadAllDrivers() {

        if (!isFragmentAlive) {
            return;
        }
        if(!Utils.isNetworkConnected(this.getContext())){
            return;
        }
        if (assetList == null) {
            assetList = new ArrayList<>();
        }


       // Utils.showProgress(this.getContext());


        ApiInterface apiInterface = ApiClient.getClient(this.getContext()).create(ApiInterface.class);

        apiInterface.assets(GlobalConstant.X_CSRF_TOKEN).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                if (!isFragmentAlive) {
                    return;
                }

                Utils.hideProgress();

                int code = response.code();

                GsonBuilder gsonBuilder = new GsonBuilder();
                gsonBuilder.setLongSerializationPolicy(LongSerializationPolicy.STRING);

                Gson gson = gsonBuilder.create();

                if (code == 200) {
                    // success
                    ResponseBody responseBody = response.body();
                    JSONObject object = null;

                    try {
                        object = new JSONObject(responseBody.string());
                        JSONArray items = (JSONArray) object.get("items");


                        Type type = new TypeToken<List<Resp_Asset>>() {
                        }.getType();
                        assetList = gson.fromJson(items.toString(), type);

                        for (Resp_Asset asset : assetList) {
                            asset.isSelected = false;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(AlarmFragment.this.getContext(), "response parse error");
                    }

                    setAssetSingleSelectTableData();

                } else {

                    ResponseBody errorBody = response.errorBody();
                    Resp_Error error = null;
                    try {
                        error = gson.fromJson(errorBody.string(), Resp_Error.class);
                        Utils.showShortToast(AlarmFragment.this.getContext(), error.message);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(AlarmFragment.this.getContext(), "response parse error");
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {

                t.printStackTrace();

                if (!isFragmentAlive) {
                    return;
                }

                Utils.hideProgress();

                Utils.showShortToast(AlarmFragment.this.getContext(), "server connect error");
            }
        });

    }
    private void setAssetSingleSelectTableData() {

        if (!isFragmentAlive) {
            return;
        }

        // items
        adapter = new AssetListSingleSelectRecyclerViewAdapter(this, assetList, R.layout.recyclerview_row_asset_single_select);

        rvAssetSingleSelect.setAdapter(adapter);
        rvAssetSingleSelect.setLayoutManager(new LinearLayoutManager(this.getContext()));
        rvAssetSingleSelect.setItemAnimator(new DefaultItemAnimator());
    }
    public void setSelectedAsset(Resp_Asset selectedAsset) {

        if (!isFragmentAlive) {
            return;
        }


        btn_set_alarm.setEnabled(true);

        this.selectedAsset = selectedAsset;


        if (adapter != null) {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    adapter.notifyDataSetChanged();
                }
            }, 100);

        }

        if(selectedAsset==null) return;


        initialize_comps();
        String trackerId=selectedAsset.trackerId;
        ApiInterface apiInterface = ApiClient.getClient(this.getContext()).create(ApiInterface.class);

        //Utils.showProgress(this.getContext());
        apiInterface.alarm(GlobalConstant.X_CSRF_TOKEN, trackerId).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                if (!isFragmentAlive) {
                    return;
                }
                //Utils.hideProgress();
                //pBarLoading.setVisibility(View.INVISIBLE);

                int code = response.code();
                Gson gson = new Gson();

                if (code == 200) {
                    // success
                    ResponseBody responseBody = response.body();

                    Resp_Alarm respAlarm = null;

                    try {
                        String bodyString = responseBody.string();
                        Log.d("bodyString",bodyString);
                        respAlarm = gson.fromJson(bodyString, Resp_Alarm.class);

                        loadAlarmValues(respAlarm);


                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(AlarmFragment.this.getContext(), "response parse error");

                    }

                } else {
                   // Utils.hideProgress();
                    ResponseBody errorBody = response.errorBody();
                    Resp_Error error = null;
                    try {
                        error = gson.fromJson(errorBody.string(), Resp_Error.class);
                        Utils.showShortToast(AlarmFragment.this.getContext(), error.message);

                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(AlarmFragment.this.getContext(), "response parse error");

                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
               // Utils.hideProgress();
                t.printStackTrace();
                if (!isFragmentAlive) {
                    return;
                }
                //pBarLoading.setVisibility(View.INVISIBLE);

                Utils.showShortToast(AlarmFragment.this.getContext(), "server connect error");
            }
        });


    }

    private void loadAlarmValues(Resp_Alarm respAlarm) {

        txt_userTracker_speedLimit.setText(respAlarm.speedLimit);
        txt_userTracker_fatigueTime.setText(respAlarm.fatigueTime);
        txt_userTracker_email.setText(respAlarm.email);
        txt_userTracker_phoneNumber.setText(respAlarm.phoneNumber);

        s_speedingAlarmStatus.setChecked(respAlarm.speedingAlarmStatus);
        s_fatigueAlarmStatus.setChecked(respAlarm.fatigueAlarmStatus);
        s_harshTurnAlarmStatus.setChecked(respAlarm.harshTurnAlarmStatus);
        s_harshAcceAlarmStatus.setChecked(respAlarm.harshAcceAlarmStatus);
        s_harshDeceAlarmStatus.setChecked(respAlarm.harshDeceAlarmStatus);
        s_tamperAlarmStatus.setChecked(respAlarm.tamperAlarmStatus);
        s_geoFenceAlarmStatus.setChecked(respAlarm.geoFenceAlarmStatus);
        s_emailAlarmStatus.setChecked(respAlarm.emailAlarmStatus);
        s_phoneAlarmStatus.setChecked(respAlarm.phoneAlarmStatus);
        s_engineAlarmStatus.setChecked(respAlarm.accAlarmStatus);
        s_alertSound.setChecked(respAlarm.soundAlarmStatus);
        s_vibration.setChecked(respAlarm.vibrationAlarmStatus);
        s_engineOffAlarmStatus.setChecked(respAlarm.stopAlarmStatus);
    }

    private void initialize_comps() {
        txt_userTracker_speedLimit.setText("");
        txt_userTracker_fatigueTime.setText("");
        txt_userTracker_email.setText("");
        txt_userTracker_phoneNumber.setText("");

        s_speedingAlarmStatus.setChecked(false);
        s_fatigueAlarmStatus.setChecked(false);
        s_harshTurnAlarmStatus.setChecked(false);
        s_harshAcceAlarmStatus.setChecked(false);
        s_harshDeceAlarmStatus.setChecked(false);
        s_tamperAlarmStatus.setChecked(false);
        s_geoFenceAlarmStatus.setChecked(false);
        s_emailAlarmStatus.setChecked(false);
        s_phoneAlarmStatus.setChecked(false);
        s_alertSound.setChecked(false);
        s_vibration.setChecked(false);
        s_engineOffAlarmStatus.setChecked(false);
    }

    @OnClick(R.id.btn_set_alarm)
    public void onSetAlarmButton_click(){

        if(selectedAsset==null) {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                    this.getContext());

            // set title
            alertDialogBuilder.setTitle("Alert");

            // set dialog message
            alertDialogBuilder
                    .setMessage("Please choose vehicle.")
                    .setCancelable(false)
                    .setPositiveButton("Yes",new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog,int id) {
                            // if this button is clicked, close
                            // current activity
                            return;
                        }
                    })
                    .setNegativeButton("No",new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog,int id) {
                            // if this button is clicked, just close
                            // the dialog box and do nothing
                            dialog.cancel();
                        }
                    });

            // create alert dialog
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
            return;
        }

        String id = selectedAsset.trackerId;  //trackerId
        String speedLimit = txt_userTracker_speedLimit.getText().toString();
        String fatigueTime = txt_userTracker_fatigueTime.getText().toString();
        String harshTurn =  "120";//txt_userTracker_harshTurn.getText().toString();
        String harshAcceleration = "1";//txt_userTracker_harshAcceleration.getText().toString();
        String harshDeceleration = "1";//txt_userTracker_harshDeceleration.getText().toString();
        String email = txt_userTracker_email.getText().toString();
        String phoneNumber = txt_userTracker_phoneNumber.getText().toString();




        boolean speedingAlarmStatus = s_speedingAlarmStatus.isChecked();
        boolean fatigueAlarmStatus = s_fatigueAlarmStatus.isChecked();
        boolean harshTurnAlarmStatus = s_harshTurnAlarmStatus.isChecked();
        boolean harshAcceAlarmStatus = s_harshAcceAlarmStatus.isChecked();
        boolean harshDeceAlarmStatus = s_harshDeceAlarmStatus.isChecked();
        boolean tamperAlarmStatus = s_tamperAlarmStatus.isChecked();
        boolean geoFenceAlarmStatus = s_geoFenceAlarmStatus.isChecked();
        boolean emailAlarmStatus = s_emailAlarmStatus.isChecked();
        boolean phoneAlarmStatus = s_phoneAlarmStatus.isChecked();
        boolean accAlarmStatus=s_engineAlarmStatus.isChecked();
        boolean soundAlarmStatus = s_alertSound.isChecked();
        boolean vibrationAlarmStatus = s_vibration.isChecked();
        boolean stopAlarmStatus = s_engineOffAlarmStatus.isChecked();

        if (emailAlarmStatus && email.indexOf('@') <= -1)
        {

            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                    this.getContext());

            // set title
            alertDialogBuilder.setTitle("Alert");

            // set dialog message
            alertDialogBuilder
                    .setMessage("Use valid email address.")
                    .setCancelable(false)
                    .setPositiveButton("Yes",new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog,int id) {
                            return;
                        }
                    })
                    .setNegativeButton("No",new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog,int id) {
                            dialog.cancel();
                        }
                    });

            // create alert dialog
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();

            return;
        }

      if(phoneAlarmStatus && phoneNumber.length()!=10) {
          AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                  this.getContext());

          // set title
          alertDialogBuilder.setTitle("Alert");

          // set dialog message
          alertDialogBuilder
                  .setMessage("The 10 digits phone number only. For example, use 3525021234. Not 352-502-1234 nor 5021234.")
                  .setCancelable(false)
                  .setPositiveButton("Yes",new DialogInterface.OnClickListener() {
                      public void onClick(DialogInterface dialog,int id) {
                          return;
                      }
                  })
                  .setNegativeButton("No",new DialogInterface.OnClickListener() {
                      public void onClick(DialogInterface dialog,int id) {
                          dialog.cancel();
                      }
                  });

          // create alert dialog
          AlertDialog alertDialog = alertDialogBuilder.create();
          alertDialog.show();

          return;

      }
        HashMap<String,Object> param=new HashMap<String,Object>();
        param.put("id",id);
        param.put("speedLimit",speedLimit);
        param.put("fatigueTime",fatigueTime);
        param.put("harshTurn",harshTurn);
        param.put("harshAcceleration",harshAcceleration);
        param.put("harshDeceleration",harshDeceleration);
        param.put("email",email);
        param.put("phoneNumber",phoneNumber);
        param.put("speedingAlarmStatus",speedingAlarmStatus);
        param.put("fatigueAlarmStatus",fatigueAlarmStatus);
        param.put("harshTurnAlarmStatus",harshTurnAlarmStatus);
        param.put("harshAcceAlarmStatus",harshAcceAlarmStatus);
        param.put("harshDeceAlarmStatus",harshDeceAlarmStatus);
        param.put("geoFenceAlarmStatus",geoFenceAlarmStatus);
        param.put("tamperAlarmStatus",tamperAlarmStatus);
        param.put("emailAlarmStatus",emailAlarmStatus);
        param.put("phoneAlarmStatus",phoneAlarmStatus);
        param.put("accAlarmStatus",accAlarmStatus);
        param.put("soundAlarmStatus",soundAlarmStatus);
        param.put("vibrationAlarmStatus",vibrationAlarmStatus);
        param.put("stopAlarmStatus",stopAlarmStatus);

        ApiInterface apiInterface = ApiClient.getClient(this.getContext()).create(ApiInterface.class);
       // Utils.showProgress(this.getContext());
        apiInterface.modify(GlobalConstant.X_CSRF_TOKEN, param).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                if (!isFragmentAlive) {
                    return;
                }

               // Utils.hideProgress();

                int code = response.code();
                Gson gson = new Gson();

                if (code == 200) {
                    // success
                    Utils.showShortToast(AlarmFragment.this.getContext(), "Success");

                } else {
                    Utils.showShortToast(AlarmFragment.this.getContext(), "response parse error");
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                t.printStackTrace();
                if (!isFragmentAlive) {
                    return;
                }

                Utils.hideProgress();

                Utils.showShortToast(AlarmFragment.this.getContext(), "server connect error");
            }
        });

    }

}
