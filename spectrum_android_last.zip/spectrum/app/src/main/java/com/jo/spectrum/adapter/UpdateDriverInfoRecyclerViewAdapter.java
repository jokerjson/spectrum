package com.jo.spectrum.adapter;

import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import com.jo.spectrum.R;
import com.jo.spectrum.fragment.UpdateDriverInfoFragment;
import com.jo.spectrum.model.Resp_Asset;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by JO on 3/18/2018.
 */

public class UpdateDriverInfoRecyclerViewAdapter extends RecyclerView.Adapter<UpdateDriverInfoRecyclerViewAdapter.ViewHolder> {


    private List<Resp_Asset> itemList;
    private int itemLayoutResID;
    public Fragment fragment;

    public UpdateDriverInfoRecyclerViewAdapter(Fragment fragment, List<Resp_Asset> itemList, int itemLayoutResID) {
        this.fragment = fragment;
        this.itemList = itemList;
        this.itemLayoutResID = itemLayoutResID;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View viewHolder = LayoutInflater.from(parent.getContext()).inflate(itemLayoutResID, parent, false);

        return new UpdateDriverInfoRecyclerViewAdapter.ViewHolder(viewHolder);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        final Resp_Asset item = itemList.get(position);

        holder.editDriverName.setText(item.driverName);
        holder.editDriverPhone.setText(item.driverPhoneNumber);
        holder.editVehicleName.setText(item.name);

        holder.btnUpdateDriverInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(UpdateDriverInfoRecyclerViewAdapter.this.fragment instanceof UpdateDriverInfoFragment) {
                    UpdateDriverInfoFragment fragment = (UpdateDriverInfoFragment) UpdateDriverInfoRecyclerViewAdapter.this.fragment;

                    fragment.onUpdateButtonClick(item, holder.editDriverName.getText().toString(), holder.editDriverPhone.getText().toString(), holder.editVehicleName.getText().toString());
                }
            }
        });

        holder.itemView.setTag(item);
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.edit_driver_name)
        TextView editDriverName;

        @BindView(R.id.edit_driver_phone)
        TextView editDriverPhone;

        @BindView(R.id.edit_vehicle_name)
        TextView editVehicleName;

        @BindView(R.id.btn_update_driver_info)
        ImageButton btnUpdateDriverInfo;

        public ViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
