package com.jo.spectrum.model;

public class Resp_Event {
    public String localDateTime;
    public String alarm;
    public String address;
}
