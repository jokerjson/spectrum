package com.jo.spectrum.model;

/**
 * Created by JO on 3/18/2018.
 */

public class LTEData {
    public String lteData;
    public double price;

    public LTEData(String lteData, double price) {
        this.lteData = lteData;
        this.price = price;
    }
}
