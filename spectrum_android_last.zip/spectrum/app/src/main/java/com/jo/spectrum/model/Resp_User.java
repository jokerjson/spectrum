package com.jo.spectrum.model;

/**
 * Created by JO on 3/21/2018.
 */

public class Resp_User {
    public String email;
    public String firstName;
    public String lastName;
    public Billing billing;

    public static class Billing {
        public String address1;
        public String address2;
        public String city;
        public String state;
        public String zip;
        public String phone;
        public String creditCardToken;
        public String creditCardExpirationDate;
    }

}

