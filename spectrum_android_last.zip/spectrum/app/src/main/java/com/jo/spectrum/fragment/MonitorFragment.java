package com.jo.spectrum.fragment;


import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.LongSerializationPolicy;
import com.google.gson.reflect.TypeToken;
import com.jo.spectrum.R;
import com.jo.spectrum.adapter.AssetListMultiSelectRecyclerViewAdapter;
import com.jo.spectrum.adapter.VelocityRecyclerViewAdapter;
import com.jo.spectrum.api.ApiClient;
import com.jo.spectrum.api.ApiInterface;
import com.jo.spectrum.global.GlobalConstant;
import com.jo.spectrum.global.LowPassFilter;
import com.jo.spectrum.global.NetworkChangeReceiver;
import com.jo.spectrum.global.Utils;
import com.jo.spectrum.libs.MovableFloatingActionButton;
import com.jo.spectrum.model.Resp_Alarm;
import com.jo.spectrum.model.Resp_Asset;
import com.jo.spectrum.model.Resp_Error;
import com.jo.spectrum.model.Resp_Tracker;
import com.jo.spectrum.tracking.GPSTracker;
import com.jo.spectrum.view.CompassView;
import com.jo.spectrum.view.MapBoxCalloutMarker;
import com.mapbox.mapboxsdk.Mapbox;
import com.mapbox.mapboxsdk.annotations.Icon;
import com.mapbox.mapboxsdk.annotations.IconFactory;
import com.mapbox.mapboxsdk.annotations.Marker;
import com.mapbox.mapboxsdk.annotations.MarkerOptions;
import com.mapbox.mapboxsdk.annotations.MarkerViewOptions;
import com.mapbox.mapboxsdk.annotations.Polyline;
import com.mapbox.mapboxsdk.annotations.PolylineOptions;
import com.mapbox.mapboxsdk.camera.CameraPosition;
import com.mapbox.mapboxsdk.camera.CameraUpdateFactory;
import com.mapbox.mapboxsdk.constants.Style;
import com.mapbox.mapboxsdk.geometry.ILatLng;
import com.mapbox.mapboxsdk.geometry.LatLng;
import com.mapbox.mapboxsdk.geometry.LatLngBounds;
import com.mapbox.mapboxsdk.maps.MapView;
import com.mapbox.mapboxsdk.maps.MapboxMap;
import com.mapbox.mapboxsdk.maps.OnMapReadyCallback;
import com.mapbox.mapboxsdk.maps.UiSettings;
import com.mapbox.mapboxsdk.style.layers.Layer;
import com.mapbox.mapboxsdk.style.layers.PropertyFactory;
import com.mapbox.mapboxsdk.style.layers.SymbolLayer;
import com.mapbox.mapboxsdk.style.sources.GeoJsonSource;
import com.mapbox.mapboxsdk.style.sources.Source;
import com.mapbox.services.commons.geojson.Feature;
import com.mapbox.services.commons.geojson.FeatureCollection;
import com.mapbox.services.commons.geojson.Point;
import com.mapbox.services.commons.models.Position;
import org.json.JSONArray;
import org.json.JSONObject;
import java.lang.reflect.Type;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import it.carlom.stikkyheader.core.StikkyHeaderBuilder;
import it.carlom.stikkyheader.core.animator.AnimatorBuilder;
import it.carlom.stikkyheader.core.animator.HeaderStikkyAnimator;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.content.Context.VIBRATOR_SERVICE;
import static com.mapbox.mapboxsdk.Mapbox.getApplicationContext;
import static com.mapbox.mapboxsdk.style.layers.PropertyFactory.textAllowOverlap;
import static com.mapbox.mapboxsdk.style.layers.PropertyFactory.textColor;
import static com.mapbox.mapboxsdk.style.layers.PropertyFactory.textField;
import static com.mapbox.mapboxsdk.style.layers.PropertyFactory.textSize;


public class MonitorFragment extends Fragment{

    @BindView(R.id.mapView)
    MapView mapView;

    @BindView(R.id.seek_zoom)
    SeekBar seekBar;

    @BindView(R.id.rv_monitor_right_options)
    RecyclerView rvMonitorRightOptions;

    @BindView(R.id.rv_monitor_velocity)
    RecyclerView rvMonitorVelocity;

    @BindView(R.id.layout_velocityTable)
    LinearLayout layout_velocityTable;

    @BindView(R.id.btn_toggle_basemap)
    ImageView btn_toggle_basemap;

    @BindView(R.id.btn_ShowUser)
    ImageView btn_show_user;

    @BindView(R.id.header_layout)
    View topView;

    @BindView(R.id.bottomView)
    ScrollView bottomView;

    MapboxMap mapboxMap;
    private boolean isPause = false;
    private String style=GlobalConstant.MAP_BOX_STYLE_URL;
    Boolean onViewCreatedOnceCalled = false;
    List<Resp_Asset> assetList = null; // entire assets
    List<Resp_Asset> selectedAssets = null;
    Map<Resp_Asset, Resp_Tracker> trackers = null; // trackers
    public static Map<Resp_Asset, Resp_Tracker> oldTrackers = null; // trackers
    List<Marker> markers = null;
    boolean isFragmentAlive;
    private int refreshCount=0;
    private boolean firstAppearFlag = true;
    private LatLng centerPosition;
    private Feature user_feature;
    Resp_Alarm respAlarm;
    private boolean userShowFlag = true;
    private final Handler mHendler=new Handler();
    private float defaultZoom=9f;
    private float defaultPtZoom=15f;
    private NetworkChangeReceiver networkChangeReceiver;
    private Marker geoaddressMaker;
    private GPSTracker gpsTracker;
    private HashMap<String,ArrayList<LatLng>> trackPoints=new HashMap<String,ArrayList<LatLng>>();
    List<Marker> trackMarkers=null;
    private ArrayList<Polyline> trackLines;


    public MonitorFragment() {
        // Required empty public constructor
    }

    public static MonitorFragment newInstance() {
        MonitorFragment fragment = new MonitorFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        isFragmentAlive = true;

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_monitor, container, false);

        ButterKnife.bind(this, rootView);
        Resources resources=this.getActivity().getResources();
        Drawable drawable=resources.getDrawable(R.drawable.btn_hide);
        btn_toggle_velocity.setImageDrawable(drawable);
        layout_velocityTable.setVisibility(View.GONE);
        Mapbox.getInstance(this.getActivity(), GlobalConstant.MAP_BOX_ACCESS_TOKEN);

        networkChangeReceiver=new NetworkChangeReceiver();
        IntentFilter intentFilter=new IntentFilter();
        intentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
        this.getActivity().registerReceiver(networkChangeReceiver,intentFilter);
        return rootView;
    }

    @OnClick(R.id.btn_good)
    public  void onGood()
    {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse("https://www.amazon.com/review/review-your-purchases/?asin=B07BV4HBST"));
        MonitorFragment.this.getActivity().startActivity(i);
    }

    @OnClick(R.id.btn_bad)
    public  void onBad()
    {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse("https://spectrumtracking.com/feedback.html"));
        MonitorFragment.this.getActivity().startActivity(i);
    }

    @OnClick(R.id.btn_mail)
    public  void onMail()
    {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse("https://spectrumtracking.com/feedback.html"));
        MonitorFragment.this.getActivity().startActivity(i);
    }

    @OnClick(R.id.btn_refer)
    public  void onRefer()
    {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse("https://spectrumtracking.com/refer.html"));
        MonitorFragment.this.getActivity().startActivity(i);
    }

    private void geocode(final com.google.maps.model.LatLng latLng, final Marker marker){

        String latLngString=latLng.lng+","+latLng.lat;
        ApiInterface apiInterface = ApiClient.getClient(this.getContext()).create(ApiInterface.class);
        apiInterface.coord2AddressMapbox(GlobalConstant.X_CSRF_TOKEN,latLngString).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                //Utils.hideProgress();
                if (!isFragmentAlive) {
                    return;
                }
                int code = response.code();

                GsonBuilder gsonBuilder = new GsonBuilder();
                gsonBuilder.setLongSerializationPolicy(LongSerializationPolicy.STRING);

                Gson gson = gsonBuilder.create();

                if (code == 200) {
                    // success
                    ResponseBody responseBody = response.body();
                    JSONObject object = null;

                    try {
                        object = new JSONObject(responseBody.string());
                        JSONArray items = (JSONArray) object.get("features");
                        JSONObject feature=(JSONObject) items.get(0);
                        String place_name=feature.getString("place_name");

                        DecimalFormat df = new DecimalFormat("#.####");
                        String latLngString="("+df.format(latLng.lat)+" "+df.format(latLng.lng)+")";
                        if(marker==null) {
                            if(geoaddressMaker!=null)
                                mapboxMap.removeMarker(geoaddressMaker);

                            geoaddressMaker=mapboxMap.addMarker(new MarkerOptions()
                                    .position(new LatLng(latLng.lat,latLng.lng))
                                    .title(place_name+"\n"+latLngString));

                            mapboxMap.selectMarker(geoaddressMaker);

                        }
                        else {
                            marker.setTitle(marker.getTitle()+"\n"+place_name+"\n"+latLngString);
                            marker.getInfoWindow().update();
                            marker.showInfoWindow(mapboxMap,mapView);
                            //mapboxMap.selectMarker(marker);
                        }

                        System.out.println("ok");

                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(MonitorFragment.this.getContext(), "response parse error");
                    }


                } else {

                    if (!isFragmentAlive) {
                        return;
                    }

                    ResponseBody errorBody = response.errorBody();
                    Resp_Error error = null;
                    try {
                        error = gson.fromJson(errorBody.string(), Resp_Error.class);
                        Utils.showShortToast(MonitorFragment.this.getContext(), error.message);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(MonitorFragment.this.getContext(), "response parse error");
                    }
                }
            }
            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                //Utils.hideProgress();
                t.printStackTrace();

                if (!isFragmentAlive) {
                    return;
                }
                //pBarLoading.setVisibility(View.INVISIBLE);
                Utils.showShortToast(MonitorFragment.this.getContext(), "server connect error");
                //loadDriversThread();
            }
        });

    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        if (onViewCreatedOnceCalled) {
            return;
        }
        onViewCreatedOnceCalled = true;

        getActivity().setTitle("Monitor");

        initMap(savedInstanceState);

        loadAllDrivers();
        rvMonitorRightOptions.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        rvMonitorRightOptions.setHasFixedSize(true);
        rvMonitorRightOptions.setNestedScrollingEnabled(false);
        Log.d("result:","stikky");

        StikkyHeaderBuilder.stickTo(bottomView)
                .setHeader(topView.getId(), (ViewGroup) getView())
                .minHeightHeader(0)
                .animator(new ParallaxStikkyAnimator())
                .build();
        //seek_zoom.setProgress(9);
        //seek_zoom.setProgress((int)mapboxMap.getCameraPosition().zoom);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            int progressValue=0;
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                progressValue=progress;
                defaultPtZoom = progressValue;
                CameraPosition cameraPosition= mapboxMap.getCameraPosition();
                CameraPosition new_cameraPosition=new CameraPosition.Builder().target(cameraPosition.target).zoom((double)progressValue).bearing(0).tilt(0).build();
                mapboxMap.setCameraPosition(new_cameraPosition);
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }
    private class ParallaxStikkyAnimator extends HeaderStikkyAnimator {
        @Override
        public AnimatorBuilder getAnimatorBuilder() {
            View mHeader_image = getHeader().findViewById(R.id.mapView);
            return AnimatorBuilder.create().applyVerticalParallax(mHeader_image,1);
        }
    }
    public  void loadAllDrivers() {

        if (!isFragmentAlive) {
            return;
        }

        if (assetList == null) {
            assetList = new ArrayList<>();
        }
        if (trackers == null) {
            trackers = new LinkedHashMap<>();
        }
        if (selectedAssets == null) {
            selectedAssets = new ArrayList<>();
        }

        selectedAssets.clear();

        this.getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {

            }
        });

        //Utils.showProgress(this.getContext());

        ApiInterface apiInterface = ApiClient.getClient(this.getContext()).create(ApiInterface.class);

        apiInterface.assets(GlobalConstant.X_CSRF_TOKEN).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                //Utils.hideProgress();
                if (!isFragmentAlive) {
                    return;
                }

                int code = response.code();
                Log.d("codecode",""+code);
                GsonBuilder gsonBuilder = new GsonBuilder();
                gsonBuilder.setLongSerializationPolicy(LongSerializationPolicy.STRING);

                Gson gson = gsonBuilder.create();

                if (code == 200) {
                    // success
                    ResponseBody responseBody = response.body();
                    JSONObject object = null;

                    try {
                        object = new JSONObject(responseBody.string());
                        JSONArray items = (JSONArray) object.get("items");


                        Type type = new TypeToken<List<Resp_Asset>>() {
                        }.getType();
                        List<Resp_Asset> newAssetList = gson.fromJson(items.toString(), type);
                        int index=0;
                        for (Resp_Asset newAsset : newAssetList) {
                            if(refreshCount==0) {
                              if(index==0) newAsset.isSelected=true;
                              else newAsset.isSelected=false;

                              index++;
                            }
                           // newAsset.isSelected = true;
                            for (Resp_Asset oldAsset : assetList) {
                                if (newAsset._id.equals(oldAsset._id)) {
                                    newAsset.isSelected = oldAsset.isSelected;
                                    break;
                                }
                            }
                        }
                        assetList.clear();
                        assetList.addAll(newAssetList);
                        for (Resp_Asset asset : assetList) {
                            if (asset.isSelected) {
                                selectedAssets.add(asset);
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(MonitorFragment.this.getContext(), "response parse error");
                    }
                    trackers.clear();

                    loadTrackersFrom(0);

                } else {

                    if (!isFragmentAlive) {
                        return;
                    }

                    ResponseBody errorBody = response.errorBody();
                    Resp_Error error = null;
                    try {
                        error = gson.fromJson(errorBody.string(), Resp_Error.class);
                        Utils.showShortToast(MonitorFragment.this.getContext(), error.message);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(MonitorFragment.this.getContext(), "response parse error");
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {

                t.printStackTrace();

                if (!isFragmentAlive) {
                    return;
                }

                Utils.showShortToast(MonitorFragment.this.getContext(), "server connect error");
                loadDriversThread();
            }
        });

    }

    private void addGPSLocation() {
        if(gpsTracker==null) {
            gpsTracker=new GPSTracker(this.getActivity());
        }
        if (mapboxMap == null)return;
        gpsTracker.getLocation();

        double latitude;
        double longitude;

        latitude = gpsTracker.getLatitude();
        longitude = gpsTracker.getLongitude();

        String markerLayerId="gps";
        String labelLayerId="me";
        String vehicleSourceId="gps-source";

        SymbolLayer markerLayer=null;
        markerLayer=(SymbolLayer) mapboxMap.getLayer(markerLayerId);
        if(markerLayer!=null) mapboxMap.removeLayer(markerLayerId);

        SymbolLayer labelLayer=null;
        labelLayer=(SymbolLayer) mapboxMap.getLayer(labelLayerId);
        if(labelLayer!=null) mapboxMap.removeLayer(labelLayerId);

        Source geoJsonSource=null;
        geoJsonSource=mapboxMap.getSource(vehicleSourceId);
        if(geoJsonSource!=null) mapboxMap.removeSource(geoJsonSource);

        Bitmap icon = BitmapFactory.decodeResource(
                MonitorFragment.this.getResources(), R.drawable.pin);

        mapboxMap.addImage("gps-marker-image", icon);

        List<Feature> markerCoordinates = new ArrayList<>();
        /////////////////////////////////////////////////////////////////

        LatLng point = new LatLng(latitude, longitude);

        Point pt=Point.fromCoordinates(Position.fromCoordinates(longitude, latitude));
        user_feature = Feature.fromGeometry(pt);
        user_feature.addStringProperty("property","ME");

        markerCoordinates.add(user_feature);

        FeatureCollection featureCollection=FeatureCollection.fromFeatures(markerCoordinates);

        geoJsonSource=new GeoJsonSource(vehicleSourceId,featureCollection);
        mapboxMap.addSource(geoJsonSource);

        markerLayer=new SymbolLayer(markerLayerId,vehicleSourceId)
                .withProperties(PropertyFactory.iconImage("gps-marker-image"))
                .withProperties(PropertyFactory.iconSize(0.8f))
                .withProperties(PropertyFactory.fillColor(Color.RED))
                .withProperties(PropertyFactory.iconAllowOverlap(true));

        mapboxMap.addLayer(markerLayer);

        labelLayer=new SymbolLayer(labelLayerId,vehicleSourceId);
        labelLayer.setProperties(textField("{property}"),
                textSize(16f),
                textColor(Color.WHITE),
                textAllowOverlap(true)
        );
        mapboxMap.addLayer(labelLayer);

    }

    private void loadTrackersFrom(final int assetIdOnSelectedAssetList) {

        if (!isFragmentAlive) {
            return;
        }

        if (assetIdOnSelectedAssetList >= selectedAssets.size()) {
            onTrackersAllLoaded();
            return;
        }

        final Resp_Asset asset = selectedAssets.get(assetIdOnSelectedAssetList);

        ApiInterface apiInterface = ApiClient.getClient(this.getContext()).create(ApiInterface.class);

        apiInterface.trackers_id(GlobalConstant.X_CSRF_TOKEN, asset.trackerId).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                //Utils.hideProgress();
                if (!isFragmentAlive) {
                    return;
                }

                int code = response.code();
                Gson gson = new Gson();

                if (code == 200) {
                    // success
                    ResponseBody responseBody = response.body();

                    Resp_Tracker tracker = null;

                    try {
                        String bodyString = responseBody.string();
                        tracker = gson.fromJson(bodyString, Resp_Tracker.class);
                        trackers.put(asset, tracker);
                        addTrackPoints(asset,tracker);



                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(MonitorFragment.this.getContext(), "response parse error");
                    }

                } else {
                    ResponseBody errorBody = response.errorBody();
                    Resp_Error error = null;
                    try {
                        error = gson.fromJson(errorBody.string(), Resp_Error.class);
                        Utils.showShortToast(MonitorFragment.this.getContext(), error.message);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(MonitorFragment.this.getContext(), "response parse error");
                    }
                }
                loadTrackersFrom(assetIdOnSelectedAssetList + 1);
            }
            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Utils.hideProgress();
                t.printStackTrace();
                if (!isFragmentAlive) {
                    return;
                }

                Utils.showShortToast(MonitorFragment.this.getContext(), "server connect error");
            }
        });

    }

    int maxLocationCount=30;

    public void getAlarmStatus(String trackerId) {

        if (!isFragmentAlive) {
            return;
        }

        ApiInterface apiInterface = ApiClient.getClient(this.getContext()).create(ApiInterface.class);
        apiInterface.alarm(GlobalConstant.X_CSRF_TOKEN, trackerId).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (!isFragmentAlive) {
                    return;
                }
                int code = response.code();
                Gson gson = new Gson();
                if (code == 200) {
                    ResponseBody responseBody = response.body();
                    try {
                        String bodyString = responseBody.string();
                        Log.d("bodyString",bodyString);
                        respAlarm = gson.fromJson(bodyString, Resp_Alarm.class);
                        //sound
                        if (respAlarm.soundAlarmStatus) {
                            try {
                                Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                                Ringtone r = RingtoneManager.getRingtone(getApplicationContext(), notification);
                                r.play();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        //vibrate
                        if (respAlarm.vibrationAlarmStatus) {
                            if (Build.VERSION.SDK_INT >= 26) {
                                ((Vibrator) getContext().getSystemService(VIBRATOR_SERVICE)).vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE));
                            } else {
                                ((Vibrator) getContext().getSystemService(VIBRATOR_SERVICE)).vibrate(150);
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(MonitorFragment.this.getContext(), "response parse error");
                    }
                } else {
                    ResponseBody errorBody = response.errorBody();
                    Resp_Error error = null;
                    try {
                        error = gson.fromJson(errorBody.string(), Resp_Error.class);
                        Utils.showShortToast(MonitorFragment.this.getContext(), error.message);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(MonitorFragment.this.getContext(), "response parse error");
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                t.printStackTrace();
                if (!isFragmentAlive) {
                    return;
                }
                Utils.showShortToast(MonitorFragment.this.getContext(), "server connect error");
            }
        });
    }

    private void addTrackPoints(Resp_Asset asset, Resp_Tracker tracker) {

        if(!asset.isSelected) return;
        if(!GlobalConstant.alerts.containsKey(asset.driverName) || !GlobalConstant.alerts.get(asset.driverName).equals(tracker.lastAlert)) {
            if(tracker.lastAlert != null && !tracker.lastAlert.equals("no alert") && !tracker.lastAlert.equals("")) {
                Date current = new Date();
                Calendar calendar = Calendar.getInstance();
                int year = calendar.get(Calendar.YEAR);
                String lastAlert_time = year + "/" + tracker.lastAlert.substring(tracker.lastAlert.length() - 11, tracker.lastAlert.length());
                SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm");
                try {
                    Date date = format.parse(lastAlert_time);
                    long calDate = (current.getTime() - date.getTime()) / (24 * 60 * 60 * 1000);
                    Log.d("different", "/" + calDate);
                    if (calDate < 1) {
                        GlobalConstant.alerts.put(asset.driverName, tracker.lastAlert);
                        new AlertDialog.Builder(getContext())
                                .setTitle("")
                                .setMessage(tracker.lastAlert)
                                .setCancelable(false)
                                .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        // Whatever...
                                    }
                                }).show();
                        getAlarmStatus(asset.trackerId);
                    }
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        }
        if(!trackPoints.containsKey(asset.trackerId)) {
            trackPoints.put(asset.trackerId,new ArrayList<LatLng>());
        }

        ArrayList<LatLng> assetTrackPoints=this.trackPoints.get(asset.trackerId);
        LatLng latLng=new LatLng(tracker.lat,tracker.lng);
        Log.w("latlng: ",latLng.toString());

        if(assetTrackPoints.size()<maxLocationCount) {
            if(assetTrackPoints.size()<2) {

                assetTrackPoints.add(latLng);
                trackPoints.put(asset.trackerId,assetTrackPoints);
                return;

        }
            LatLng previousLatLng=assetTrackPoints.get(assetTrackPoints.size()-1);

            if(previousLatLng.getLatitude()==latLng.getLatitude() && previousLatLng.getLongitude()==latLng.getLongitude()) return;

               assetTrackPoints.add(latLng);
            trackPoints.put(asset.trackerId,assetTrackPoints);
        }
        else {
            LatLng previousLatLng=assetTrackPoints.get(assetTrackPoints.size()-1);

            if(previousLatLng.getLatitude()==latLng.getLatitude() && previousLatLng.getLongitude()==latLng.getLongitude()) return;

            assetTrackPoints.remove(0);
            assetTrackPoints.add(latLng);
            trackPoints.put(asset.trackerId,assetTrackPoints);
        }

    }

    private void showTrackPointsOnMap() {
        if (trackMarkers == null) {
            trackMarkers = new ArrayList<>();
        }
        for (Marker marker : trackMarkers) {
            mapboxMap.removeMarker(marker);
        }
        trackMarkers.clear();
    }

    private void onTrackersAllLoaded() {

        if (!isFragmentAlive) {
            return;
        }

        setRightPanelData();
        showCarsOnMap();
        showTrackPointsOnMap();
        setVelocityData();
            int DELAY = 5 * 1000;
            mHendler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if(Utils.isNetworkConnected(MonitorFragment.this.getContext())){
                        loadAllDrivers();
                    }
                    else {
                          loadDriversThread();
                    }
                }
            }, DELAY);
    }

    private void loadDriversThread() {
        if(!isFragmentAlive) return;
      new Thread(new Runnable() {
            @Override
            public void run() {
                while (true){
                    if(Utils.isNetworkConnected(MonitorFragment.this.getContext())) {
                        try {
                            Thread.sleep(5000);

                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        loadAllDrivers();
                        break;
                    }
                }
            }
        }).start();
    }

    private void setVelocityData() {
        if (!isFragmentAlive) {
            return;
        }
        VelocityRecyclerViewAdapter adapter = new VelocityRecyclerViewAdapter(this, trackers, R.layout.recyclerview_row_velocity);
        rvMonitorVelocity.setAdapter(adapter);
        rvMonitorVelocity.setLayoutManager(new LinearLayoutManager(this.getContext()));
        rvMonitorVelocity.setItemAnimator(new DefaultItemAnimator());
    }

    private void setRightPanelData() {
        if (!isFragmentAlive) {
            return;
        }
        AssetListMultiSelectRecyclerViewAdapter adapter = new AssetListMultiSelectRecyclerViewAdapter(this, assetList, R.layout.recyclerview_row_asset_multi_select);
       // if (firstAppearFlag) {
            rvMonitorRightOptions.setAdapter(adapter);
            rvMonitorRightOptions.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
            rvMonitorRightOptions.setHasFixedSize(true);
            rvMonitorRightOptions.setItemAnimator(new DefaultItemAnimator());
            firstAppearFlag = false;
       // }
    }

    public void onRightPanelAssetListCheckChanged(int position, boolean isChecked) {
        if (position >= assetList.size()) {
            return;
        }
        assetList.get(position).isSelected = isChecked;
        showCarsOnMap();
    }

    private void showCarsOnMap() {
        if (userShowFlag)addGPSLocation();
        if (!isFragmentAlive) {
            return;
        }

        if (markers == null) {
            markers = new ArrayList<>();
        }

        for (Marker marker : markers) {
            mapboxMap.removeMarker(marker);
        }
        markers.clear();

        if(trackLines==null) {
            trackLines=new ArrayList<>();
        }
        for(Polyline polyline:trackLines){
            mapboxMap.removePolyline(polyline);
        }
        trackLines.clear();
        if(mapboxMap == null)return;
//////////////////////////////////////////////////////////////////////////
        String markerLayerId="vehicle";
        String labelLayerId="label";
        String vehicleSourceId="vehicle-srouce";

        SymbolLayer markerLayer=null;
        markerLayer=(SymbolLayer) mapboxMap.getLayer(markerLayerId);
        if(markerLayer!=null) mapboxMap.removeLayer(markerLayerId);

        SymbolLayer labelLayer=null;
        labelLayer=(SymbolLayer) mapboxMap.getLayer(labelLayerId);
        if(labelLayer!=null) mapboxMap.removeLayer(labelLayerId);

        Source geoJsonSource=null;
        geoJsonSource=mapboxMap.getSource(vehicleSourceId);
        if(geoJsonSource!=null) mapboxMap.removeSource(geoJsonSource);



        Bitmap icon = BitmapFactory.decodeResource(
                MonitorFragment.this.getResources(), R.drawable.locationcirclesmall);

        mapboxMap.addImage("my-marker-image", icon);

        List<Feature> markerCoordinates = new ArrayList<>();
       /////////////////////////////////////////////////////////////////
        LatLngBounds.Builder latLngBoundsBuilder = new LatLngBounds.Builder();
        int includedCount = 0;
        for (Resp_Asset asset :
                assetList) {
            if (trackers.containsKey(asset)) {
                Resp_Tracker tracker = trackers.get(asset);

                double latitude;
                double longitude;

                latitude = tracker.lat;
                longitude = tracker.lng;
                if(latitude==0 && longitude==0) continue;

                LatLng point = new LatLng(latitude, longitude);

                latLngBoundsBuilder.include(point);
                includedCount++;

                //add track line
               LatLng point1=null;
               LatLng point2=null;
               if(tracker.ACCStatus==0) {
                   point1=new LatLng(tracker.lat,tracker.lng);
                   point2=new LatLng(tracker.lat,tracker.lng);
               }
               else {
                   point1=new LatLng(tracker.lat1,tracker.lng1);
                   point2=new LatLng(tracker.lat2,tracker.lng2);
               }

                Point pt1=Point.fromCoordinates(Position.fromCoordinates(longitude, latitude));
                Feature f1=Feature.fromGeometry(pt1);
                String name = asset.driverName;
                if (name.length() > 5)name = name.substring(0,5);
                f1.addStringProperty("property",Utils.trucatLabelString(name,5));

                Point pt2=Point.fromCoordinates(Position.fromCoordinates(point1.getLongitude(), point1.getLatitude()));
                Feature f2=Feature.fromGeometry(pt2);
                f2.addStringProperty("property",Utils.trucatLabelString(name,5));

                Point pt3=Point.fromCoordinates(Position.fromCoordinates(point2.getLongitude(), point2.getLatitude()));
                Feature f3=Feature.fromGeometry(pt3);
                f3.addStringProperty("property",Utils.trucatLabelString(name,5));

                markerCoordinates.add(f1);
               // markerCoordinates.add(f2);
              //  markerCoordinates.add(f3);
                PolylineOptions polylineOptions = new PolylineOptions();
                polylineOptions.add(point,point1,point2);
                polylineOptions.color(Color.parseColor("#FE2EF7")).width(4);

                Polyline polyline=mapboxMap.addPolyline(polylineOptions);
                trackLines.add(polyline);
            }
        }

        FeatureCollection featureCollection=FeatureCollection.fromFeatures(markerCoordinates);

        geoJsonSource=new GeoJsonSource(vehicleSourceId,featureCollection);
        mapboxMap.addSource(geoJsonSource);

        markerLayer=new SymbolLayer(markerLayerId,vehicleSourceId)
                .withProperties(PropertyFactory.iconImage("my-marker-image"))
                .withProperties(PropertyFactory.iconSize(1.5f))
                .withProperties(PropertyFactory.fillColor(Color.RED))
                .withProperties(PropertyFactory.iconAllowOverlap(true));

        mapboxMap.addLayer(markerLayer);

        labelLayer=new SymbolLayer(labelLayerId,vehicleSourceId);
        labelLayer.setProperties(textField("{property}"),
                textSize(16f),
                textColor(Color.WHITE),
                textAllowOverlap(true)
        );
        mapboxMap.addLayer(labelLayer);


        if(userShowFlag && user_feature != null)
        {
            markerCoordinates.add(user_feature);
            includedCount++;
        }
        CameraPosition cameraPosition=null;

        if (includedCount != 0) {
            if (includedCount == 1) {
                Feature marker = markerCoordinates.get(0);
                Point pt=(Point) marker.getGeometry();
                cameraPosition = new CameraPosition.Builder().target(new LatLng(pt.getCoordinates().getLatitude(),pt.getCoordinates().getLongitude())).bearing(0).zoom(defaultPtZoom).tilt(0).build();
                mapboxMap.setCameraPosition(cameraPosition);
                return;
            } else {
                checkContains(markerCoordinates);
                return;
            }
        }
    }


    private void checkContains(List<Feature> markers) {
        LatLngBounds.Builder latLngBoundsBuilder = new LatLngBounds.Builder();
        for (Feature marker : markers) {
                Point pt=(Point)marker.getGeometry();
                LatLng latLng = new LatLng(pt.getCoordinates().getLatitude(),pt.getCoordinates().getLongitude());
                latLngBoundsBuilder.include(latLng);
        }
        LatLngBounds latLngBounds=latLngBoundsBuilder.build();
        mapboxMap.moveCamera(CameraUpdateFactory.newLatLngBounds(latLngBounds, 50, 350, 50, 150));

        double zoomScale=mapboxMap.getCameraPosition().zoom;
        if(zoomScale>defaultPtZoom) {
            CameraPosition cameraPosition = new CameraPosition.Builder().target(new LatLng(latLngBounds.getCenter().getLatitude(),latLngBounds.getCenter().getLongitude())).bearing(0).tilt(0).zoom(defaultPtZoom).build();
            mapboxMap.setCameraPosition(cameraPosition);
        }
//        else {
//           // defaultPtZoom = (float)zoomScale;
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
//                seekBar.setProgress((int)zoomScale);
//            }
//        }
       // CameraPosition polylineCameraPosition = mapboxMap.getCameraForLatLngBounds(latLngBoundsBuilder.build(), new int[]{150, 350, 150, 150});
        //mapboxMap.setCameraPosition(polylineCameraPosition);
    }

    private void initMap(Bundle savedInstanceState) {

        mapView.onCreate(savedInstanceState);

        mapView.setStyleUrl(style);

        mapView.getMapAsync(new OnMapReadyCallback() {
            @Override
            public void onMapReady(MapboxMap mapboxMap) {
                MonitorFragment.this.mapboxMap = mapboxMap;
                MonitorFragment.this.mapboxMap.setMaxZoomPreference(20);
                MonitorFragment.this.mapboxMap.setCameraPosition(new CameraPosition.Builder().target(new LatLng(38.2534189, -85.7551944)).zoom(defaultZoom).build());
                MonitorFragment.this.mapboxMap.getUiSettings().setRotateGesturesEnabled(false);

               // Utils.setMapUtilityToolsInMonintor( MonitorFragment.this.mapboxMap,mapView.getRootView());

                MonitorFragment.this.mapboxMap.setOnMapLongClickListener(new MapboxMap.OnMapLongClickListener(){
                    @Override
                    public void onMapLongClick(@NonNull LatLng point) {
                        com.google.maps.model.LatLng latLng=new com.google.maps.model.LatLng(point.getLatitude(),point.getLongitude());
                        geocode(latLng,null);
                    }
                });

                MonitorFragment.this.mapboxMap.getMarkerViewManager().setOnMarkerViewClickListener(new MapboxMap.OnMarkerViewClickListener() {
                    @Override
                    public boolean onMarkerClick(@NonNull Marker marker, @NonNull View view, @NonNull MapboxMap.MarkerViewAdapter adapter) {
                        LatLng position=marker.getPosition();
                        com.google.maps.model.LatLng latLng=new com.google.maps.model.LatLng(position.getLatitude(),position.getLongitude());
                        geocode(latLng,marker);
                        return false;
                    }
                });
            }
        });
    }

    public void  zoomSelectedVehicles(){
        List<Resp_Asset> selectedAssets=new ArrayList<>();
        for(Resp_Asset asset:assetList){
             if(asset.isSelected) selectedAssets.add(asset);
        }
        if(selectedAssets.size()==0) return;

        if(selectedAssets.size()==1) {
            Resp_Asset asset=selectedAssets.get(0);
            Resp_Tracker tracker=trackers.get(asset);
            if(tracker==null) {
                addTracker(asset);
                return;
            }
            CameraPosition cameraPosition = new CameraPosition.Builder().target(new LatLng(tracker.lat,tracker.lng)).bearing(0).tilt(0).zoom(defaultPtZoom).build();
            mapboxMap.setCameraPosition(cameraPosition);
            return;
        }
        final LatLngBounds.Builder latLngBoundsBuilder = new LatLngBounds.Builder();
        int nothingCount=0;
        for(Resp_Asset asset:selectedAssets){
            Resp_Tracker tracker=trackers.get(asset);
            if(tracker==null) {
                nothingCount++;
                addTracker(asset);
                continue;
            }
            LatLng point = new LatLng(tracker.lat, tracker.lng);
            latLngBoundsBuilder.include(point);
        }
        if(nothingCount==selectedAssets.size()) return;
        try {
            LatLngBounds latLngBounds=latLngBoundsBuilder.build();
            mapboxMap.moveCamera(CameraUpdateFactory.newLatLngBounds(latLngBounds, 50, 350, 50, 150));

            double zoomScale=mapboxMap.getCameraPosition().zoom;
            if(zoomScale>defaultPtZoom) {
                CameraPosition cameraPosition = new CameraPosition.Builder().target(new LatLng(latLngBounds.getCenter().getLatitude(),latLngBounds.getCenter().getLongitude())).bearing(0).tilt(0).zoom(defaultPtZoom).build();
                mapboxMap.setCameraPosition(cameraPosition);
            }
        }
        catch (Exception ex){
            return;
        }


    }

    private void addTracker(final Resp_Asset asset) {
        ApiInterface apiInterface = ApiClient.getClient(this.getContext()).create(ApiInterface.class);

        apiInterface.trackers_id(GlobalConstant.X_CSRF_TOKEN, asset.trackerId).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                //Utils.hideProgress();
                if (!isFragmentAlive) {
                    return;
                }

                int code = response.code();
                Gson gson = new Gson();

                if (code == 200) {
                    // success
                    ResponseBody responseBody = response.body();

                    Resp_Tracker tracker = null;

                    try {
                        String bodyString = responseBody.string();
                        tracker = gson.fromJson(bodyString, Resp_Tracker.class);
                        trackers.put(asset, tracker);

                        zoomSelectedVehicles();

                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(MonitorFragment.this.getContext(), "response parse error");
                    }

                } else {
                    ResponseBody errorBody = response.errorBody();
                    Resp_Error error = null;
                    try {
                        error = gson.fromJson(errorBody.string(), Resp_Error.class);
                        Utils.showShortToast(MonitorFragment.this.getContext(), error.message);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(MonitorFragment.this.getContext(), "response parse error");
                    }
                }
            }
            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                t.printStackTrace();
                if (!isFragmentAlive) {
                    return;
                }
                Utils.showShortToast(MonitorFragment.this.getContext(), "server connect error");
            }
        });
    }
    @OnClick(R.id.btn_ShowUser)
    public  void onUserShowHide()
    {
        this.userShowFlag = !this.userShowFlag;
        showCarsOnMap();
    }

    @OnClick(R.id.btn_toggle_basemap)
    public  void onToogleBaseMapClick()
    {
        Resources resources=this.getActivity().getResources();
        if(style.equals(GlobalConstant.MAP_BOX_STYLE_URL)) {
            style=GlobalConstant.MAP_BOX_SATELLITE_URL;
        }
        else {
            style=GlobalConstant.MAP_BOX_STYLE_URL;
        }
        mapView.setStyleUrl(style);
    }
    @BindView(R.id.btn_toggle_velocity)
    ImageView btn_toggle_velocity;
    @OnClick(R.id.btn_toggle_velocity)
    public void onToogleVelocityButtonClick(){
        Resources resources=this.getActivity().getResources();
        if(this.layout_velocityTable.isShown()) {
            Drawable drawable=resources.getDrawable(R.drawable.btn_hide);
            btn_toggle_velocity.setImageDrawable(drawable);
            layout_velocityTable.setVisibility(View.GONE);
        }
        else {
            Drawable drawable=resources.getDrawable(R.drawable.btn_show);
            btn_toggle_velocity.setImageDrawable(drawable);

            layout_velocityTable.setVisibility(View.VISIBLE);
        }
    }
    @Override
    public void onStart() {
        super.onStart();
        //Toast.makeText(getContext(),"onResume",Toast.LENGTH_SHORT).show();
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        isFragmentAlive = false;
    }

    @Override
    public void onPause() {
        super.onPause();
        isPause = true;
    }
    @Override
    public void onResume() {
        super.onResume();
        if(!isFragmentAlive){
           // isPause = false;
            isFragmentAlive = true;
            loadAllDrivers();
            Toast.makeText(getContext(),"onResume",Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    public  void onStop(){
        super.onStop();
        if(networkChangeReceiver==null) return;
        try{
            this.getActivity().unregisterReceiver(networkChangeReceiver);
        }
        catch (Exception ex) {

        }
    }
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }



}
