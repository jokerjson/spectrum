package com.jo.spectrum.model;

import java.util.List;

/**
 * Created by JO on 3/17/2018.
 */

public class OrderService {
    public String name;
    public String trackerId;
    public String expirationDate;
    public List<ServicePlan> servicePlanList;
    public List<LTEData> lteDataList;
    public Boolean autoReview;

    public int selectedServicePlanId;
    public int selectedLTEDataId;

    public boolean servicePlanEnabled;
    public boolean lteDataEnabled;


}
