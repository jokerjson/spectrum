package com.jo.spectrum.model;

import java.util.List;

public class Resp_Weather {
    public String cod;
    public String message;
    public String cnt;
    public List<Weather> list;
    public City          city;
}
