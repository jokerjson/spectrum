package com.jo.spectrum.activity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.RecyclerView;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SlidingDrawer;
import android.widget.Switch;
import android.widget.TextView;

import com.jo.spectrum.R;
import com.jo.spectrum.fragment.EventFragment;
import com.jo.spectrum.fragment.WeatherFragment;
import com.jo.spectrum.fragment.ActivateTrackerFragment;
import com.jo.spectrum.fragment.AlarmFragment;
import com.jo.spectrum.fragment.GeofenceFragment;
import com.jo.spectrum.fragment.MonitorFragment;
import com.jo.spectrum.fragment.OrderServiceFragment;
import com.jo.spectrum.fragment.OrderTrackerFragment;
import com.jo.spectrum.fragment.ReplayFragment;
import com.jo.spectrum.fragment.ReportsFragment;
import com.jo.spectrum.fragment.UpdateDriverInfoFragment;
import com.jo.spectrum.global.GlobalConstant;
import com.jo.spectrum.global.Utils;
import com.jo.spectrum.libs.MovableFloatingActionButton;
import com.jo.spectrum.model.OrderService;
import com.jo.spectrum.model.Resp_Asset;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Timer;
import java.util.TimerTask;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity {

    @BindView(R.id.menuMoreLayout)
    LinearLayout menuMoreLayout;

    @BindView(R.id.backView)
    View backView;

    @BindView(R.id.icon_activate)
    ImageView icon_activate;

    @BindView(R.id.icon_monitor)
    ImageView icon_monitor;

    @BindView(R.id.icon_replay)
    ImageView icon_replay;

    @BindView(R.id.icon_report)
    ImageView icon_report;

    @BindView(R.id.icon_alarm)
    ImageView icon_alarm;

    @BindView(R.id.icon_set_alarms)
    ImageView icon_set_alarm;

    @BindView(R.id.icon_geofence)
    ImageView icon_geofence;

    @BindView(R.id.icon_order_service)
    ImageView icon_order_service;

    @BindView(R.id.icon_order_tracker)
    ImageView icon_order_tracker;

    @BindView(R.id.icon_driverinfo)
    ImageView icon_driverinfo;

    int currentSelectedNavigationItemID = -1;

    public Fragment getFragment() {
        return fragment;
    }

    private Fragment fragment = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_main);

        ButterKnife.bind(this);

        haveStoragePermission();
        GlobalConstant.alerts = new HashMap<String,String>();

        showMonitorFragment();
    }

    public void showMonitorFragment() {
        fragment = MonitorFragment.newInstance();
        setFragment();
    }
    public void showReplayFromMonitor(Resp_Asset item){

        currentSelectedNavigationItemID = R.id.drawer_replay;

        Resp_Asset asset=item.clone();
        asset.isSelected=true;

        fragment=ReplayFragment.newInstance(asset);
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.content_frame, fragment);
        getSupportFragmentManager().executePendingTransactions();
        ft.commit();
    }

    private Boolean exit = false;

    @Override
    public void onBackPressed() {
        if (exit) {
                finish(); // finish activity
        } else {
            Utils.showShortToast(this, "Press Back again to Exit.");
            exit = true;
            int BACK_CHARGE_LENGTH = 1500;
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    exit = false;
                }
            }, BACK_CHARGE_LENGTH);
        }
    }

    public  boolean haveStoragePermission() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED  && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED ) {
                return true;
            }
            else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION}, 1);
                return true;
            }
        }
        else {
            return true;
        }
    }
    private void setFragment()
    {
        if (fragment != null) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.content_frame, fragment);
            ft.commit();
        }
    }
    private void setDefaultColor()
    {
        icon_activate.setColorFilter(getResources().getColor(R.color.menu_normal_color));
        icon_alarm.setColorFilter(getResources().getColor(R.color.menu_normal_color));
        icon_driverinfo.setColorFilter(getResources().getColor(R.color.menu_normal_color));
        icon_geofence.setColorFilter(getResources().getColor(R.color.menu_normal_color));
        icon_monitor.setColorFilter(getResources().getColor(R.color.menu_normal_color));
        icon_order_service.setColorFilter(getResources().getColor(R.color.menu_normal_color));
        icon_order_tracker.setColorFilter(getResources().getColor(R.color.menu_normal_color));
        icon_replay.setColorFilter(getResources().getColor(R.color.menu_normal_color));
        icon_report.setColorFilter(getResources().getColor(R.color.menu_normal_color));
        icon_set_alarm.setColorFilter(getResources().getColor(R.color.menu_normal_color));
    }
    @OnClick(R.id.btn_monitor)
    public  void onMonitor()
    {
        setDefaultColor();
        icon_monitor.setColorFilter(getResources().getColor(R.color.menu_select_color));
        fragment = MonitorFragment.newInstance();
        setFragment();
    }
    @OnClick(R.id.btn_replay)
    public  void onReplay()
    {
        setDefaultColor();
        icon_replay.setColorFilter(getResources().getColor(R.color.menu_select_color));
        fragment = ReplayFragment.newInstance();
        setFragment();
    }
    @OnClick(R.id.btn_report)
    public  void onReport()
    {
        setDefaultColor();
        icon_report.setColorFilter(getResources().getColor(R.color.menu_select_color));
        fragment = ReportsFragment.newInstance();
        setFragment();
    }
    @OnClick(R.id.btn_alarms)
    public  void onAlarms()
    {
        setDefaultColor();
        icon_alarm.setColorFilter(getResources().getColor(R.color.menu_select_color));
        fragment = EventFragment.newInstance();
        setFragment();
    }
    @OnClick(R.id.btn_set_alarms)
    public  void onSetAlarms()
    {
        setDefaultColor();
        icon_set_alarm.setColorFilter(getResources().getColor(R.color.menu_select_color));
        fragment = AlarmFragment.newInstance();
        menuMoreLayout.setVisibility(View.GONE);
        backView.setVisibility(View.GONE);
        setFragment();
    }
    @OnClick(R.id.btn_geofence)
    public  void onGeofence()
    {
        setDefaultColor();
        icon_geofence.setColorFilter(getResources().getColor(R.color.menu_select_color));
        fragment = GeofenceFragment.newInstance();
        menuMoreLayout.setVisibility(View.GONE);
        backView.setVisibility(View.GONE);
        setFragment();
    }
    @OnClick(R.id.btn_driver_info)
    public  void onUpdateDriverInfo()
    {
        setDefaultColor();
        icon_driverinfo.setColorFilter(getResources().getColor(R.color.menu_select_color));
        fragment = UpdateDriverInfoFragment.newInstance();
        menuMoreLayout.setVisibility(View.GONE);
        backView.setVisibility(View.GONE);
        setFragment();
    }
    @OnClick(R.id.btn_order_service)
    public  void onOrderService()
    {
        setDefaultColor();
        icon_order_service.setColorFilter(getResources().getColor(R.color.menu_select_color));
        fragment = OrderServiceFragment.newInstance();
        menuMoreLayout.setVisibility(View.GONE);
        backView.setVisibility(View.GONE);
        setFragment();
    }
    @OnClick(R.id.btn_order_tracker)
    public  void onOrderTracker()
    {
        setDefaultColor();
        icon_order_tracker.setColorFilter(getResources().getColor(R.color.menu_select_color));
        fragment = OrderTrackerFragment.newInstance();
        menuMoreLayout.setVisibility(View.GONE);
        backView.setVisibility(View.GONE);
        setFragment();
    }
    @OnClick(R.id.btn_activate)
    public  void onActivate()
    {
        setDefaultColor();
        icon_activate.setColorFilter(getResources().getColor(R.color.menu_select_color));
        fragment = ActivateTrackerFragment.newInstance();
        menuMoreLayout.setVisibility(View.GONE);
        backView.setVisibility(View.GONE);
        setFragment();
    }
    @OnClick(R.id.btn_more)
    public  void onMore()
    {
       menuMoreLayout.setVisibility(View.VISIBLE);
       backView.setVisibility(View.VISIBLE);
    }
    @OnClick(R.id.btn_menu_close)
    public  void onClose()
    {
        menuMoreLayout.setVisibility(View.GONE);
        backView.setVisibility(View.GONE);
    }
    @OnClick(R.id.btn_logout)
    public  void onLogout()
    {
        this.startActivity(new Intent(this, LoginActivity.class));

        SharedPreferences preferences = getSharedPreferences("spectrum", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();

        editor.putBoolean("is_login", false);
        editor.commit();

        this.finish();
        return;
    }
}
