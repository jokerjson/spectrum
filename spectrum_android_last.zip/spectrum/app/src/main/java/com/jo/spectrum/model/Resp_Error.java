package com.jo.spectrum.model;

/**
 * Created by JO on 3/21/2018.
 */

public class Resp_Error {
    public String name;
    public String message;
    public int httpStatus;

}

