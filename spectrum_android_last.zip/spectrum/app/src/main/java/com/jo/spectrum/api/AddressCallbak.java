package com.jo.spectrum.api;

import android.support.annotation.NonNull;

public interface AddressCallbak {

    void onSuccess(@NonNull String value);

    void onError(@NonNull Throwable throwable);

}
