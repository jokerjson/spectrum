package com.jo.spectrum.global;

import android.app.ProgressDialog;

import com.jo.spectrum.model.OrderService;
import com.jo.spectrum.model.OrderTracker;
import com.jo.spectrum.model.ShippingAddressHolder;
import com.mapbox.mapboxsdk.constants.Style;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by BlueSky on 2017-11-18.
 */

public class GlobalConstant {

    public static final String WEB_API_BASE_URL = "https://api.spectrumtracking.com/v1/";
    public static final String WEATHER_API_BASE_URL = "https://api.openweathermap.org";
    public static final String WEATHER_IMAGE_BASE_URL ="http://openweathermap.org/img/w/";
    public static final String MAP_BOX_ACCESS_TOKEN = "pk.eyJ1IjoiZ2lzMTk4MTcyNiIsImEiOiJjamVwMndtejQxYW11MnhydGNpMGFic3E5In0.BgeygPFqtGxXww-KffncsQ";

    public static final String MAP_BOX_STYLE_URL = "https://osm.spectrumtracking.com/styles/ciw6czz2n00242kmg6hw20box/style.json";
    public static final String MAP_BOX_SATELLITE_URL = Style.SATELLITE;


    public static final String WEB_API_IMAGE_BASE_URL = "https://app.spectrumtracking.com/";



    static ProgressDialog progressDialog;

    public static String X_CSRF_TOKEN = "";
    public static Map<String, String> alerts = null;

    public static List<OrderService> orderServiceItemList = null; // order service fragment data to be used on checkout activity

    public static ShippingAddressHolder shippingAddress = null; // order tracker -> shipping address holder

    public static List<OrderTracker> orderTrackerList = null; // order tracker list to be used on checkout activity
}
