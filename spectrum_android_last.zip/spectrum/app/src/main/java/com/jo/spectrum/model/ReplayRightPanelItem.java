package com.jo.spectrum.model;

/**
 * Created by JO on 3/18/2018.
 */

public class ReplayRightPanelItem {
    public String driverPhone;
    public String vehicleName;
    public Boolean isSelected;
}
