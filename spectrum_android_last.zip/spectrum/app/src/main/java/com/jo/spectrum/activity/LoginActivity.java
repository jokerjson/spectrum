package com.jo.spectrum.activity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.Html;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.gson.Gson;
import com.jo.spectrum.R;
import com.jo.spectrum.api.ApiClient;
import com.jo.spectrum.api.ApiInterface;
import com.jo.spectrum.global.GlobalConstant;
import com.jo.spectrum.global.Utils;
import com.jo.spectrum.model.Resp_Error;

import org.json.JSONObject;

import java.io.IOException;
import java.util.Calendar;
import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Headers;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends Activity {

    @BindView(R.id.txt_copyright_year)
    TextView txtCopyRight;

    @BindView(R.id.edit_username)
    EditText editUsername;

    @BindView(R.id.edit_password)
    EditText editPassword;
/*
    @BindView(R.id.txt_contact_us)
    TextView txtContatUS;*/

    @BindView(R.id.txt_copyright)
    TextView txtCopyRightAsHTML;

   /* @BindView(R.id.txt_activate_tracker)
    TextView txtActivateTracker;*/

    private static final int RC_SIGN_IN = 9001;

    private GoogleSignInClient mGoogleSignInClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        ButterKnife.bind(this);
        // set copyright html
        String html=getString(R.string.copyright);
        Spanned htmlAsSpanned = Html.fromHtml(html);
        txtCopyRightAsHTML.setText(htmlAsSpanned);

        // set copyright year
        txtCopyRight.setText(String.valueOf(Calendar.getInstance().get(Calendar.YEAR)));



        SharedPreferences preferences = getSharedPreferences("spectrum", Context.MODE_PRIVATE);
        boolean isLoggedIn = preferences.getBoolean("is_login", false);
        if (isLoggedIn) {

            String username = preferences.getString("username", "");
            String password = preferences.getString("password", "");

            editUsername.setText(username);
            editPassword.setText(password);
            onLoginClick();

        }

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
         mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

    }


    @OnClick(R.id.txt_register)
    public void onRegisterClick() {
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
    }

    @OnClick(R.id.txt_forgot_password)
    public void onForgotPasswordClick() {

        final Dialog dialog = new Dialog(this, R.style.Dialog);
        dialog.setContentView(R.layout.dialog_forgot_password);
        //dialog.setTitle("Forgot password");
        dialog.setCancelable(false);

        Button btnOk = dialog.findViewById(R.id.btn_dlg_forgot_password_ok);

        final EditText editForgotPasswordEmail = dialog.findViewById(R.id.edit_forgot_password_email);

        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = editForgotPasswordEmail.getText().toString().toLowerCase();
                if ("".equals(email)) {
                    Utils.showShortToast(LoginActivity.this, "please enter email");
                    return;
                }
                doForgetPasswordWork(email);
                dialog.dismiss();
            }
        });

        Button btnCancel = dialog.findViewById(R.id.btn_dlg_forgot_password_cancel);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        WindowManager.LayoutParams lWindowParams = new WindowManager.LayoutParams();
        lWindowParams.copyFrom(dialog.getWindow().getAttributes());
        lWindowParams.width = WindowManager.LayoutParams.FILL_PARENT; // this is where the magic happens
        lWindowParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
        dialog.show();
        dialog.getWindow().setAttributes(lWindowParams);

        /*String email = editUsername.getText().toString();
        if ("".equals(email)) {
            Utils.showShortToast(LoginActivity.this, "please enter email");
            return;
        }
        doForgetPasswordWork(email);*/

    }

    @OnClick(R.id.btn_login)
    public void onLoginClick() {

        final String username = editUsername.getText().toString().replaceAll(" ","").toLowerCase();
        final String password = editPassword.getText().toString().replaceAll(" ","");

        if ("".equals(username)) {
            Utils.showShortToast(this, "please enter username");
            return;
        }
        if ("".equals(password)) {
            Utils.showShortToast(this, "please enter password");
            return;
        }

        Utils.showProgress(this);

        ApiInterface apiInterface = ApiClient.getClient(this).create(ApiInterface.class);
        HashMap<String, Object> body = new HashMap<>();

        body.put("email", username);
        body.put("password", password);

        apiInterface.authLogin(body).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                Utils.hideProgress();

                int code = response.code();
                Gson gson = new Gson();

                if (code == 200) {
                    // success
                    ResponseBody responseBody = response.body();
                    JSONObject object = null;
                    try {
                        object = new JSONObject(responseBody.string());
                        Boolean success = object.getBoolean("success");
                        if (success) {

                            SharedPreferences preferences = getSharedPreferences("spectrum", Context.MODE_PRIVATE);
                            SharedPreferences.Editor editor = preferences.edit();

                            editor.putBoolean("is_login", true);
                            editor.putString("username", username);
                            editor.putString("password", password);
                            editor.commit();

                            Headers responseHeaders = response.headers();

                            String csrfToken = responseHeaders.get("x-csrftoken");

                            GlobalConstant.X_CSRF_TOKEN = csrfToken;

                            Utils.showShortToast(LoginActivity.this, "login success");
                            gotoMain(username);
                            return;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(LoginActivity.this, "response parse error");
                    }
                } else {

                    ResponseBody errorBody = response.errorBody();
                    Resp_Error error = null;

                    try {
                        error = gson.fromJson(errorBody.string(), Resp_Error.class);
                        Utils.showShortToast(LoginActivity.this, error.message);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(LoginActivity.this, "response parse error");
                    }

                }

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Utils.hideProgress();
                t.printStackTrace();
                Utils.showShortToast(LoginActivity.this, "server connect error");
            }
        });

    }
    @OnClick(R.id.btn_google_login)
    public void OnGoogleLoginClick() {

        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInClient.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            // The Task returned from this call is always completed, no need to attach
            // a listener.
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult(task);
        }
    }
    // [END onActivityResult]

    // [START handleSignInResult]
    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);

            // Signed in successfully, show authenticated UI.
            updateUI(account);
        } catch (ApiException e) {
            // The ApiException status code indicates the detailed failure reason.
            // Please refer to the GoogleSignInStatusCodes class reference for more information.
           // Log.w(TAG, "signInResult:failed code=" + e.getStatusCode());
            updateUI(null);
        }
    }
    private void updateUI(@Nullable GoogleSignInAccount account) {
        if (account != null) {
          System.out.println("ok");
        } else {
            System.out.println("no");
        }
    }

    @OnClick(R.id.btn_facebook_login)
    public void OnFacebookClick(){

    }

    public void gotoMain(String username) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        intent.putExtra("username", username);
        startActivity(intent);
    }

    private void doForgetPasswordWork(final String email) {
        Utils.showProgress(this);

        ApiInterface apiInterface = ApiClient.getClient(this).create(ApiInterface.class);
        HashMap<String, Object> body = new HashMap<>();

        body.put("email", email.toLowerCase());

     /*   Intent intent=new Intent(LoginActivity.this,ResetPasswordActivity.class);
        intent.putExtra("email",editUsername.getText().toString());
        startActivity(intent);*/

        apiInterface.authResendPasswordReset(body).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                Utils.hideProgress();

                int code = response.code();
                Gson gson = new Gson();

                if (code == 200) {
                    // success
                    Utils.showShortToast(LoginActivity.this, "email sent");
                    Intent intent=new Intent(LoginActivity.this,ResetPasswordActivity.class);
                    intent.putExtra("email",email);
                    startActivity(intent);


                } else {
                    ResponseBody errorBody = response.errorBody();

                    Resp_Error error = null;
                    try {
                        error = gson.fromJson(errorBody.string(), Resp_Error.class);
                        Utils.showShortToast(LoginActivity.this, error.message);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(LoginActivity.this, "response parse error");
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Utils.hideProgress();
                t.printStackTrace();
                Utils.showShortToast(LoginActivity.this, "server connect error");
            }
        });

    }

}
