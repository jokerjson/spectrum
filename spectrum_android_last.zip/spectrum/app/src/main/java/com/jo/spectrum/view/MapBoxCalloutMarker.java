package com.jo.spectrum.view;

import com.google.android.gms.maps.model.LatLng;
import com.jo.spectrum.R;
import com.mapbox.mapboxsdk.annotations.BaseMarkerOptions;
import com.mapbox.mapboxsdk.annotations.InfoWindow;

import com.mapbox.mapboxsdk.annotations.Marker;
import com.mapbox.mapboxsdk.maps.MapView;
import com.mapbox.mapboxsdk.maps.MapboxMap;

public class MapBoxCalloutMarker //extends Marker
{
   /* private CalloutInfoWindow mInfowindow;
    *//**
     * Creates a instance of {@link Marker} using the builder of Marker.
     *

     *//*
    public MapBoxCalloutMarker(MapView mv, LatLng aLatLng){
        super(mv, "Title", "Description", aLatLng);

    }

    @Override
    protected InfoWindow createTooltip(MapView mv) {
        mInfowindow = new CalloutInfoWindow(R.layout.custom_tooltip_layout, mv);
        return mInfowindow;
    }
    public class CalloutInfoWindow extends InfoWindow{

        CalloutInfoWindow( int layoutResId,MapView mapView) {
            super(layoutResId,  mapView);
        }
        public void onOpen(Marker overlayItem) {
            //
            //  Set data on mInfoWindow.getView()
            //
        }
    }*/
}
