package com.jo.spectrum.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.jo.spectrum.R;

public class GoogleSignActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_google_sign);
    }
}
