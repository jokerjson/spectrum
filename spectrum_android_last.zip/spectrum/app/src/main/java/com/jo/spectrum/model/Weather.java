package com.jo.spectrum.model;

import java.util.List;

public class Weather {
    public long dt;
    public Weather_Main    main;
    public List<Weather_General> weather;
    public Weather_Cloud   clouds;
    public Weather_Wind    wind;
    public Weather_Rain    rain;
    public Weather_sys     sys;
    public String          dt_txt;

    public class Weather_Main{
        public float temp;
        public float temp_min;
        public float temp_max;
        public float pressure;
        public float sea_level;
        public float grnd_level;
        public float humidity;
        public float temp_kf;

    }
    public class Weather_General {
        public long id;
        public String rain;
        public String description;
        public String icon;

    }
    public class Weather_Cloud {
        public int all;

    }

    public class Weather_Wind{
       public float speed;
       public float deg;



    }
    public class Weather_Rain{
        public double rain;

    }
    public class Weather_sys{
        public String pod;

    }


}
