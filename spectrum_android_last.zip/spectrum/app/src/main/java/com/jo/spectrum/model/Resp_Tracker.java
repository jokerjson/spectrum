package com.jo.spectrum.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.Date;

/**
 * Created by JO on 3/21/2018.
 */

public class Resp_Tracker {
    @SerializedName("_id")
    public String _id;
    @SerializedName("spectrumId")
    public String spectrumId;
    @SerializedName("reportingId")
    public String reportingId;
    @SerializedName("SIMCardNum")
    public String SIMCardNum;
    @SerializedName("__v")
    public int __v;
//    @SerializedName("userId")
//    public String userId;
    @SerializedName("lastLogDateTime")
    public Date lastLogDateTime;
    @SerializedName("lat")
    public double lat;
    @SerializedName("latLngDateTime")
    public Date latLngDateTime;
    @SerializedName("expirationDate")
    public Date expirationDate;
    @SerializedName("dataPlan")
    public String dataPlan;
    @SerializedName("LTEData")
    public String LTEData;
    @SerializedName("lng")
    public double lng;
    @SerializedName("speedInMph")
    public Double speedInMph;
    @SerializedName("commandQueue")
    public ArrayList<String> commandQueue;

    @SerializedName("lat1")
    public double lat1;
    @SerializedName("lat2")
    public double lat2;
    @SerializedName("lng1")
    public double lng1;
    @SerializedName("lng2")
    public double lng2;



    @SerializedName("harshAcce")
    public int harshAcce;

    @SerializedName("harshDece")
    public int harshDece;

    @SerializedName("daySpeeding")
    public int daySpeeding;




    @SerializedName("lastACCOffTime")//voltage
    public Date lastACCOffTime;

    @SerializedName("lastACCOnTime")//voltage
    public Date lastACCOnTime;

    @SerializedName("voltage")//fuel
    public Double voltage;

    @SerializedName("tankVolume")//fuel
    public Double tankVolume;

    @SerializedName("lastACCOnLat")//fuel
    public Double lastACCOnLat;

    @SerializedName("lastACCOnLng")//fuel
    public Double lastACCOnLng;

    @SerializedName("lastACCOffLat")//fuel
    public Double lastACCOffLat;

    @SerializedName("lastACCOffLng")//fuel
    public Double lastACCOffLng;

    @SerializedName("ACCStatus")//fuel
    public Integer ACCStatus;

    @SerializedName("TrackerModel")
    public String trackerModel;


    @SerializedName("weekMile")
    public float weekMile;

    @SerializedName("dayMile")
    public float dayMile;

    @SerializedName("monthMile")
    public float monthMile;

    @SerializedName("yearMile")
    public float yearMile;

    public String ACCOnAddress;
    public String ACCOffAddress;

    @SerializedName("lastAlert")
    public String lastAlert;






}
