package com.jo.spectrum.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.LongSerializationPolicy;
import com.jo.spectrum.R;
import com.jo.spectrum.api.AddressCallbak;
import com.jo.spectrum.api.ApiClient;
import com.jo.spectrum.api.ApiInterface;
import com.jo.spectrum.fragment.MonitorFragment;
import com.jo.spectrum.global.GlobalConstant;
import com.jo.spectrum.global.Utils;
import com.jo.spectrum.model.Resp_Asset;
import com.jo.spectrum.model.Resp_Error;
import com.jo.spectrum.model.Resp_Tracker;
import com.mapbox.mapboxsdk.annotations.Marker;
import com.mapbox.mapboxsdk.annotations.MarkerOptions;
import com.mapbox.mapboxsdk.geometry.LatLng;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import butterknife.BindDimen;
import butterknife.BindView;
import butterknife.ButterKnife;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by JO on 3/17/2018.
 */

public class VelocityRecyclerViewAdapter extends RecyclerView.Adapter <VelocityRecyclerViewAdapter.ViewHolder> {


    private Map<Resp_Asset, Resp_Tracker> trackerMap;
    private int itemLayoutResID;
    private MonitorFragment monitorFragment;
    private String lastACCOnTimeString;
    private String lastACCOffTimeString;


    public VelocityRecyclerViewAdapter(MonitorFragment monitorFragment, Map<Resp_Asset, Resp_Tracker> trackerMap, int itemLayoutResID) {
        this.trackerMap = trackerMap;
        this.itemLayoutResID = itemLayoutResID;
        this.monitorFragment = monitorFragment;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View viewHolder = LayoutInflater.from(parent.getContext()).inflate(itemLayoutResID, parent, false);

        return new VelocityRecyclerViewAdapter.ViewHolder(viewHolder);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {

        Resp_Asset key = (Resp_Asset) trackerMap.keySet().toArray()[position];
        Resp_Tracker val = trackerMap.get(key);

        holder.txtName.setText(key.name);
        if(val.ACCStatus==0) {
            holder.txtStatus.setText("Park");
        }
        else {
            holder.txtStatus.setText("Drive");
        }
        holder.txtSpeed.setText(String.format("%.0f mph", val.speedInMph));

      //  if(val.)

        /*if(val.trackerModel.toLowerCase().equals("huaheng")) {
            holder.txtVoltage.setText(String.valueOf(val.voltage));
          //  holder.txtFuel.setText(String.valueOf(Math.min(100, Math.floor(val.tankVolume * 100))));
        }
        else {
            holder.txtVoltage.setText("");
           // holder.txtFuel.setText("");
        }
*/

        SimpleDateFormat sdf_ = new SimpleDateFormat("MM/dd/yyyy");
        holder.txt_expiration_date.setText(sdf_.format(val.expirationDate));


        boolean vehicleExist=false;
        boolean accOnChanged=false;
        boolean accOffChanged=false;

        Resp_Asset oldAsset=null;
        if(MonitorFragment.oldTrackers==null) {
            MonitorFragment.oldTrackers=new HashMap<Resp_Asset,Resp_Tracker>();
            vehicleExist=false;
        }
        else {
            Iterator<Resp_Asset> oldKey=MonitorFragment.oldTrackers.keySet().iterator();

            while(oldKey.hasNext()) {
                oldAsset=oldKey.next();
                String oldName=oldAsset.name;
                if(oldName.equals(key.name)) {
                    vehicleExist=true;
                    break;
                }
            }

        }
        if(!vehicleExist) {
            MonitorFragment.oldTrackers.put(key,val);
            oldAsset=key;
        }
        else {
            Resp_Tracker oldTracker=MonitorFragment.oldTrackers.get(oldAsset);
            if(val.lastACCOnTime!=null) {
                if(oldTracker.lastACCOnTime.equals(val.lastACCOnTime)) {
                    accOnChanged=false;
                }
                else {
                    accOnChanged=true;
                }
            }

            else {
                accOnChanged=false;
            }

            if(val.lastACCOffTime!=null) {
                if(oldTracker.lastACCOffTime.equals(val.lastACCOffTime)) {
                    accOffChanged=false;
                }
                else {
                    accOffChanged=true;
                }
            }

            else {
                accOnChanged=false;
            }

        }

        holder.txt_speeding.setText(String.valueOf((int)val.daySpeeding));
        holder.txt_harsh_ace.setText(String.valueOf(val.harshAcce));
        holder.txt_harsh_dece.setText(String.valueOf(val.harshDece));
        holder.txt_lastAlert.setText(val.lastAlert);

       // holder.txtThisTrip.setText(String.format("%.1f",val.weekMile));
        holder.txtDayTrip.setText(String.format("%.1f",val.dayMile));
        holder.txtMonthTrip.setText(String.format("%.1f",val.monthMile));
        holder.txtYearTrip.setText(String.format("%.1f",val.yearMile));


        String lastACCOnAdd="";
        String lastACCOffAdd="";

        final Date lastACCOnTime=val.lastACCOnTime;
        final Date lastACCOffTime=val.lastACCOffTime;

        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd hh:mm");
        lastACCOnTimeString="";
        lastACCOffTimeString="";
        if(lastACCOnTime==null) {
            lastACCOnTimeString="";
        }
        else {
            lastACCOnTimeString=sdf.format(lastACCOnTime);
        }
        if(lastACCOffTime==null) {
            lastACCOffTimeString="";
        }
        else {
            lastACCOffTimeString=sdf.format(lastACCOffTime);
        }

        if(!vehicleExist || accOnChanged) {

            if(val.lastACCOnLat==null) {
               return;
            }
            if(val.lastACCOnLng==null) {
                return;
            }

            double lastACCOnLat=val.lastACCOnLat;
            double lastACCOnLng=val.lastACCOnLng;
            final Resp_Asset finalOldAsset = oldAsset;
            coord2Address2(lastACCOnLat, lastACCOnLng, new AddressCallbak() {
                @Override
                public void onSuccess(@NonNull String address) {
                    //System.out.println(value);
                    MonitorFragment.oldTrackers.get(finalOldAsset).lastACCOnTime=lastACCOnTime;
                    MonitorFragment.oldTrackers.get(finalOldAsset).ACCOnAddress=address;
                    if(address.equals("null"))
                        address="Unknown address";

                    String[] splitAddress= address.split(",");
                    holder.txtLastStart.setText(lastACCOnTimeString);
                    holder.txtLastStartAddress.setText(splitAddress[0]);

                }

                @Override
                public void onError(@NonNull Throwable throwable) {
                    holder.txtLastStart.setText(lastACCOnTimeString);
                    holder.txtLastStartAddress.setText("Unknown address");
                }
            });
        }
        else {
            String address=MonitorFragment.oldTrackers.get(oldAsset).ACCOnAddress;
            if(address!=null) {
                String[] splitAddress= address.split(",");
                //if(splitAddress==null) return;
                holder.txtLastStart.setText(lastACCOnTimeString);
                holder.txtLastStartAddress.setText(splitAddress[0]);
            }
            else {
                if(val.lastACCOnLat!=null && val.lastACCOnLng!=null) {
                    double lastACCOnLat=val.lastACCOnLat;
                    double lastACCOnLng=val.lastACCOnLng;
                    final Resp_Asset finalOldAsset = oldAsset;
                    coord2Address2(lastACCOnLat, lastACCOnLng, new AddressCallbak() {
                        @Override
                        public void onSuccess(@NonNull String address) {
                            //System.out.println(value);
                            MonitorFragment.oldTrackers.get(finalOldAsset).lastACCOnTime=lastACCOnTime;
                            MonitorFragment.oldTrackers.get(finalOldAsset).ACCOnAddress=address;
                            if(address.equals("null"))
                                address="Unknown address";

                            String[] splitAddress= address.split(",");
                            holder.txtLastStart.setText(lastACCOnTimeString);
                            holder.txtLastStartAddress.setText(splitAddress[0]);

                        }

                        @Override
                        public void onError(@NonNull Throwable throwable) {
                            holder.txtLastStart.setText(lastACCOnTimeString);
                            holder.txtLastStartAddress.setText("Unknown address");
                        }
                    });
                }
            }


        }

        if(!vehicleExist || accOffChanged) {
            double lastACCOffLat=0d;
            double lastACCOffLng=0d;
            try{
                 lastACCOffLat= val.lastACCOffLat;
                 lastACCOffLng=val.lastACCOffLng;
            }
            catch (Exception ex) {
                ex.printStackTrace();
                return;
            }
            final Resp_Asset finalOldAsset1 = oldAsset;
            coord2Address2(lastACCOffLat, lastACCOffLng, new AddressCallbak() {
                @Override
                public void onSuccess(@NonNull String address) {
                  //  System.out.println(value);
                    MonitorFragment.oldTrackers.get(finalOldAsset1).lastACCOffTime=lastACCOffTime;
                    MonitorFragment.oldTrackers.get(finalOldAsset1).ACCOffAddress=address;
                    if(address.equals("null"))
                           address="Unknown address";
                    if(address==null) return;
                    String[] splitAddress= address.split(",");
                    if(splitAddress==null) return;
                    holder.txtLastStop.setText(lastACCOffTimeString);
                    holder.txtLastStopAddress.setText(splitAddress[0]);
                }

                @Override
                public void onError(@NonNull Throwable throwable) {

                    holder.txtLastStop.setText(lastACCOffTimeString);
                    holder.txtLastStopAddress.setText("Unknown address");
                }
            });
        }
        else {
            holder.txtLastStop.setText(lastACCOffTimeString);
            String address=MonitorFragment.oldTrackers.get(oldAsset).ACCOffAddress;
            if(address==null) {
                if(val.lastACCOffLat!=null && val.lastACCOffLng!=null) {
                    final Resp_Asset finalOldAsset = oldAsset;
                    coord2Address2(val.lastACCOffLat, val.lastACCOffLng, new AddressCallbak() {
                        @Override
                        public void onSuccess(@NonNull String address) {
                            //  System.out.println(value);
                            MonitorFragment.oldTrackers.get(finalOldAsset).lastACCOffTime=lastACCOffTime;
                            MonitorFragment.oldTrackers.get(finalOldAsset).ACCOffAddress=address;
                            if(address.equals("null"))
                                address="Unknown address";
                            if(address==null) return;
                            String[] splitAddress= address.split(",");
                            if(splitAddress==null) return;
                            holder.txtLastStop.setText(lastACCOffTimeString);
                            holder.txtLastStopAddress.setText(splitAddress[0]);
                        }

                        @Override
                        public void onError(@NonNull Throwable throwable) {

                            holder.txtLastStop.setText(lastACCOffTimeString);
                            holder.txtLastStopAddress.setText("Unknown address");
                        }
                    });
                }

                else

                  holder.txtLastStopAddress.setText("");


               // return;
            }
            else {
                String[] splitAddress= address.split(",");

                holder.txtLastStopAddress.setText(splitAddress[0]);
            }

        }

        /*final SimpleDateFormat sdf = new SimpleDateFormat("MM/dd hh:mm:ss");
        if(val==null) return;
        if(val.latLngDateTime!=null)
        holder.txtLastOnlineTime.setText(sdf.format(val.latLngDateTime).substring(0,sdf.format(val.latLngDateTime).length()-3));
        else
            holder.txtLastOnlineTime.setText("");

        final SimpleDateFormat sdf_ = new SimpleDateFormat("MM/dd/yy");
        if(val.expirationDate!=null)
        holder.txtExpirationDate.setText(sdf_.format(val.expirationDate));
        else
            holder.txtExpirationDate.setText("");*/

        holder.itemView.setTag(key);
    }

    private String  coord2Address2(double lat, double lng, final AddressCallbak addressCallbakCallback) {
        String address="";

        ApiInterface apiInterface = ApiClient.getClient(monitorFragment.getContext()).create(ApiInterface.class);
        Call<ResponseBody> call=apiInterface.coord2Address(GlobalConstant.X_CSRF_TOKEN,lng+","+lat);

        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                String  responseBody = null;
                try {
                    responseBody = response.body().string();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                JSONObject object = null;

                try {
                    object = new JSONObject(responseBody);
                    JSONArray items = (JSONArray) object.get("features");
                    JSONObject feature=(JSONObject) items.get(0);
                    addressCallbakCallback.onSuccess( feature.getString("place_name"));

                    System.out.println("ok");

                } catch (Exception e) {
                    e.printStackTrace();

                }

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                addressCallbakCallback.onError( t);

            }
        });
      return address;
    }

    @Override
    public int getItemCount() {
        return trackerMap.keySet().size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {


        @BindView(R.id.txt_name)
        TextView txtName;


        @BindView(R.id.txt_status)
        TextView txtStatus;

        @BindView(R.id.txt_speed)
        TextView txtSpeed;

       /* @BindView(R.id.txt_voltage)
        TextView txtVoltage;
*/
        @BindView(R.id.txt_expiration_date)
        TextView txt_expiration_date;

        @BindView(R.id.txt_speeding)
        TextView txt_speeding;

        @BindView(R.id.txt_harsh_ace)
        TextView txt_harsh_ace;

        @BindView(R.id.txt_harsh_dece)
        TextView txt_harsh_dece;


        @BindView(R.id.txt_alert)
        TextView txt_lastAlert;



        @BindView(R.id.txt_last_start)
        TextView txtLastStart;

        @BindView(R.id.txt_last_start_address)
        TextView txtLastStartAddress;


        @BindView(R.id.txt_last_stop)
        TextView txtLastStop;

        @BindView(R.id.txt_last_stop_address)
        TextView txtLastStopAddress;

        //@BindView(R.id.txt_this_trip)
        //TextView txtThisTrip;

        @BindView(R.id.txt_day_trip)
        TextView txtDayTrip;

        @BindView(R.id.txt_month_trip)
        TextView txtMonthTrip;

        @BindView(R.id.txt_year_trip)
        TextView txtYearTrip;



        public ViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);

        }
    }

}
