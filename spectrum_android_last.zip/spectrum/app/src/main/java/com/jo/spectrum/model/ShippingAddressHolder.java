package com.jo.spectrum.model;

public class ShippingAddressHolder {
    public String name;
    public String email;
    public String streetAddress;
    public String city;
    public String zipCode;
    public String state;

    public ShippingAddressHolder(String name, String email, String streetAddress, String city, String zipCode, String state) {
        this.name = name;
        this.email = email;
        this.streetAddress = streetAddress;
        this.city = city;
        this.zipCode = zipCode;
        this.state = state;
    }
}
