package com.jo.spectrum.activity;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.gson.Gson;
import com.jo.spectrum.R;
import com.jo.spectrum.api.ApiClient;
import com.jo.spectrum.api.ApiInterface;
import com.jo.spectrum.global.Utils;
import com.jo.spectrum.model.Resp_Error;
import com.jo.spectrum.model.Resp_User;

import java.io.IOException;
import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class VerificationActivity extends AppCompatActivity {
    @BindView(R.id.verify_email)
    EditText verifyEmailTxt;

    @BindView(R.id.verify_code)
    EditText verifyCodeTxt;

    @BindView(R.id.btn_verify)
    Button   btnVerify;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verification);
        ButterKnife.bind(this);
        Intent intent = getIntent();
        String email=intent.getStringExtra("email");
        verifyEmailTxt.setText(email);


    }
    @OnClick(R.id.txt_back)
    public void onBackClick() {
        this.finish();
    }

    @OnClick(R.id.btn_verify)
    public void onVerifyClick()
    {

                verify();
    }

    private void verify() {
        ApiInterface apiInterface = ApiClient.getClient(this).create(ApiInterface.class);
        HashMap<String, Object> body = new HashMap<>();
        Utils.showProgress(VerificationActivity.this);
        body.put("email", verifyEmailTxt.getText().toString());
        body.put("code", verifyCodeTxt.getText().toString());


        apiInterface.authVerify(body).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {


                int code = response.code();

                if (code == 200) {
                    // success
                    ResponseBody responseBody = response.body();
                    Utils.showShortToast(VerificationActivity.this, "Verification success");
                    Intent intent=new Intent(VerificationActivity.this,LoginActivity.class);
                    startActivity(intent);

                } else {
                    ResponseBody errorBody = response.errorBody();
                    Resp_Error error = null;
                    try {

                        Utils.showShortToast(VerificationActivity.this, error.message);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(VerificationActivity.this, "Response parse error");
                    }
                }
                Utils.hideProgress();
             //   btnVerify.setEnabled(true);

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Utils.hideProgress();
                t.printStackTrace();
                Utils.showShortToast(VerificationActivity.this, "server connect error");
               // btnVerify.setEnabled(true);
            }
        });

    }
}
