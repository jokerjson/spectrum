package com.jo.spectrum.model;

/**
 * Created by JO on 3/18/2018.
 */

public class ServicePlan {
    public String servicePlan;
    public double price;

    public ServicePlan(String servicePlan, double price) {
        this.servicePlan = servicePlan;
        this.price = price;
    }

}
