package com.jo.spectrum.fragment;

import android.annotation.SuppressLint;
//import android.app.DatePickerDialog;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.hardware.GeomagneticField;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.CalendarContract;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.api.client.util.DateTime;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.LongSerializationPolicy;
import com.google.gson.reflect.TypeToken;
import com.jo.spectrum.R;
import com.jo.spectrum.adapter.AssetListSingleSelectRecyclerViewAdapter;
import com.jo.spectrum.api.AddressCallbak;
import com.jo.spectrum.api.ApiClient;
import com.jo.spectrum.api.ApiInterface;
import com.jo.spectrum.fragment.datepicker.DatePickerDialog;
import com.jo.spectrum.fragment.datepicker.DateRangePickedListener;
import com.jo.spectrum.global.GlobalConstant;
import com.jo.spectrum.global.LowPassFilter;
import com.jo.spectrum.global.Utils;
import com.jo.spectrum.libs.MovableFloatingActionButton;
import com.jo.spectrum.model.Resp_Asset;
import com.jo.spectrum.model.Resp_AssetLog;
import com.jo.spectrum.model.Resp_Error;
import com.jo.spectrum.tracking.GPSTracker;
import com.mapbox.mapboxsdk.Mapbox;
import com.mapbox.mapboxsdk.annotations.Icon;
import com.mapbox.mapboxsdk.annotations.IconFactory;
import com.mapbox.mapboxsdk.annotations.Marker;
import com.mapbox.mapboxsdk.annotations.MarkerOptions;
import com.mapbox.mapboxsdk.annotations.MarkerView;
import com.mapbox.mapboxsdk.annotations.MarkerViewOptions;
import com.mapbox.mapboxsdk.annotations.Polyline;
import com.mapbox.mapboxsdk.annotations.PolylineOptions;
import com.mapbox.mapboxsdk.camera.CameraPosition;
import com.mapbox.mapboxsdk.camera.CameraUpdateFactory;
import com.mapbox.mapboxsdk.geometry.LatLng;
import com.mapbox.mapboxsdk.geometry.LatLngBounds;
import com.mapbox.mapboxsdk.maps.MapView;
import com.mapbox.mapboxsdk.maps.MapboxMap;
import com.mapbox.mapboxsdk.maps.OnMapReadyCallback;
import com.mapbox.mapboxsdk.style.layers.CircleLayer;
import com.mapbox.mapboxsdk.style.layers.Property;
import com.mapbox.mapboxsdk.style.layers.PropertyFactory;
import com.mapbox.mapboxsdk.style.layers.SymbolLayer;
import com.mapbox.mapboxsdk.style.sources.GeoJsonSource;
import com.mapbox.services.commons.geojson.Feature;
import com.mapbox.services.commons.geojson.Point;
import com.mapbox.services.commons.models.Position;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.lang.reflect.Type;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.TimeZone;
import java.util.Timer;
import java.util.TimerTask;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import it.carlom.stikkyheader.core.StikkyHeaderBuilder;
import it.carlom.stikkyheader.core.animator.AnimatorBuilder;
import it.carlom.stikkyheader.core.animator.HeaderStikkyAnimator;
import okhttp3.ResponseBody;
import okhttp3.Route;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.mapbox.mapboxsdk.style.layers.PropertyFactory.circleColor;
import static com.mapbox.mapboxsdk.style.layers.PropertyFactory.circleOpacity;
import static com.mapbox.mapboxsdk.style.layers.PropertyFactory.circleRadius;
import static com.mapbox.mapboxsdk.style.layers.PropertyFactory.iconAllowOverlap;
import static com.mapbox.mapboxsdk.style.layers.PropertyFactory.iconIgnorePlacement;
import static com.mapbox.mapboxsdk.style.layers.PropertyFactory.textAllowOverlap;
import static com.mapbox.mapboxsdk.style.layers.PropertyFactory.textColor;
import static com.mapbox.mapboxsdk.style.layers.PropertyFactory.textField;
import static com.mapbox.mapboxsdk.style.layers.PropertyFactory.textSize;

public class ReplayFragment extends Fragment  {

    @BindView(R.id.mapView)
    MapView mapView;

    @BindView(R.id.rv_replay_right_options)
    RecyclerView rvAssetSingleSelect;

    @BindView(R.id.txt_speed)
    TextView txtSpeed;

    @BindView(R.id.txt_gage_date)
    TextView txtGageDate;

    @BindView(R.id.img_speed_indicator)
    ImageView imgSpeedIndicator;

    @BindView(R.id.btn_play_pause)
    ImageView btnPlayPause;

    @BindView(R.id.trip_scroll)
    ScrollView tripScroll;

    @BindView(R.id.mapPanel)
    FrameLayout mapPanel;

    @BindView(R.id.ll_animation_controls)
    LinearLayout llAnimationControls;

    @BindView(R.id.seek_geo)
    SeekBar seekGeo;

    @BindView(R.id.trip_log_layout)
    LinearLayout tripLogLayout;

    @BindView(R.id.topView)
    LinearLayout topView;

    @BindView(R.id.txt_trip_log)
    TextView txtTripLog;

    @BindView(R.id.btn_toggle_basemap)
    ImageView btn_toggle_basemap;

    @BindView(R.id.layout_trip_log)
    LinearLayout layout_trip_log;

    @BindView(R.id.txt_trip_time)
    TextView txt_trip_time;

    @BindView(R.id.txt_total_speed)
    TextView txt_total_speed;

    @BindView(R.id.txt_harsh_acce)
    TextView txt_harsh_acce;

    @BindView(R.id.txt_total_stops)
    TextView txt_total_stops;

    @BindView(R.id.txt_top_speed)
    TextView txt_top_speed;

    @BindView(R.id.txt_harsh_dece)
    TextView txt_harsh_dece;

    @BindView(R.id.layout_route_trip_log)
    LinearLayout layout_route_trip_log;

    @BindView(R.id.txt_route_trip_time)
    TextView txt_route_trip_time;

    @BindView(R.id.txt_route_total_speed)
    TextView txt_route_total_speed;

    @BindView(R.id.txt_route_harsh_acce)
    TextView txt_route_harsh_acce;

    @BindView(R.id.txt_route_top_speed)
    TextView txt_route_top_speed;

    @BindView(R.id.txt_route_harsh_dece)
    TextView txt_route_harsh_dece;

    @BindView(R.id.btn_next_day)
    ImageView btn_next_day;

    @BindView(R.id.btn_next)
    ImageView btn_next_route;

    @BindView(R.id.btn_previous)
    ImageView btn_prev_route;

    @BindView(R.id.btn_prev_day)
    ImageView btn_prev_day;

    @BindView(R.id.bottomView)
    ScrollView bottomView;

    MapboxMap mapboxMap;

    Calendar replayStartDate;
    Calendar replayEndDate;

    Boolean onViewCreatedOnceCalled = false;

    List<Resp_Asset> assetList = null;

    Resp_Asset selectedAsset = null;

    List<Resp_AssetLog> assetLogList = null;

    List<Resp_AssetLog> assetLogList_backup=null;

    AssetListSingleSelectRecyclerViewAdapter adapter = null;

    Timer animatingTimer = null;

    MarkerView geoMarker = null;

    int geoMarkerIndex = 0;

    boolean isFragmentAlive = false;


    List<LatLng> points = null;
    List<Double> speed_Array = null;
    List<String> dateTime_Array = null;
    List<String> layerList_Array = null;
    List<String> sourceList_Array = null;
    List<Integer> speeding_Array = null;
    List<Integer> harshDriving_Array = null;
    List<Integer> accOffAlarm_Array = null;
    List<Integer> accOnAlarm_Array=null;
    List<Integer> harshAcce_Array=null;
    List<Integer> harshDece_Array=null;
    List<Integer> idling_Array=null;
    List<Integer> plugOut_Array=null;

    List<LatLng> points_backup = null;
    List<Double> speed_Array_backup = null;
    List<String> dateTime_Array_backup = null;
    List<Integer> speeding_Array_backup = null;
    List<Integer> harshDriving_Array_backup = null;
    List<Integer> accOffAlarm_Array_backup = null;
    List<Integer> accOnAlarm_Array_backup=null;
    List<Integer> harshAcce_Array_backup=null;
    List<Integer> harshDece_Array_backup=null;
    List<Integer> idling_Array_backup=null;
    List<Integer> plugOut_Array_backup=null;

    int current_route_segment=-1;

    HashMap<Marker,MarkerModel> markerModels=new HashMap<Marker, MarkerModel>();
    List<RouteSegment> route_segment=new ArrayList<RouteSegment>();

    private float defaultZoom=15f;
    private String style=GlobalConstant.MAP_BOX_STYLE_URL;
    private int trip_index = 0;
    private String displayAddress = "";
    private DatePickerDialog datePickerDialog;
    private DateRangePickedListener dateRangePickedListener;
    public ReplayFragment() {

    }
    public static ReplayFragment newInstance() {
        ReplayFragment fragment = new ReplayFragment();
        return fragment;
    }
    public static ReplayFragment newInstance(Resp_Asset item) {

        ReplayFragment fragment = new ReplayFragment();
        fragment.selectedAsset=item;
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        isFragmentAlive = true;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        isFragmentAlive = false;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_replay, container, false);

        ButterKnife.bind(this, rootView);
        //tripLogDrawerLayout.setVisibility(View.VISIBLE);
        Mapbox.getInstance(this.getActivity(), GlobalConstant.MAP_BOX_ACCESS_TOKEN);

        seekGeo.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            int progressChangedValue = 0;
            @Override
            public void onProgressChanged(final SeekBar seekBar, final int progress, boolean fromUser) {
                progressChangedValue = progress;
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                geoMarkerIndex = progressChangedValue;
                showReplayPointOfIndex();
            }
        });
        return rootView;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        if (onViewCreatedOnceCalled) {
            return;
        }
        onViewCreatedOnceCalled = true;
        getActivity().setTitle("Replay");

        initMap(savedInstanceState);

        initRightPanel();

        setSpeed(0);

        if(selectedAsset!=null) {
            bottomView.setVisibility(View.GONE);
            loadReplayClick();
        }
        else {
            loadAllDrivers();
            llAnimationControls.setVisibility(View.GONE);
            seekGeo.setVisibility(View.INVISIBLE);
            layout_trip_log.setVisibility(View.GONE);
            StikkyHeaderBuilder.stickTo(bottomView)
                    .setHeader(topView.getId(), (ViewGroup) getView())
                    .minHeightHeader(0)
                    .animator(new ParallaxStikkyAnimator1())
                    .build();
        }
    }
    private class ParallaxStikkyAnimator1 extends HeaderStikkyAnimator {
        @Override
        public AnimatorBuilder getAnimatorBuilder() {
            View mHeader_image = getHeader().findViewById(R.id.mapPanel);
            return AnimatorBuilder.create().applyVerticalParallax(mHeader_image,1);
        }
    }
    private void divideRoute() {
        route_segment=new ArrayList<RouteSegment>();
        if(accOnAlarm_Array.size()==0) return;
        int totalEvent=0;
        int firstIndex=-1;
        int firstValue=0;
        for(int i=0;i<accOnAlarm_Array.size();i++) {
            if (accOnAlarm_Array.get(i)==1 || accOffAlarm_Array.get(i)==1) { //end

                RouteSegment segment=new RouteSegment();
                if(firstIndex != -1) {
                    segment.firstIndex = firstIndex;
                    segment.endIndex = i;
                    segment.firstValue = accOffAlarm_Array.get(i);
                    segment.endValue = accOnAlarm_Array.get(i);
                    route_segment.add(segment);
                }
                firstIndex=i;
                totalEvent++;
            }
        }
        if(route_segment.size()==0) return;
        RouteSegment lastSegment=route_segment.get(route_segment.size()-1);
        if(lastSegment.endIndex!=accOnAlarm_Array.size()-1) {
            RouteSegment segment=new RouteSegment();
            segment.firstIndex=lastSegment.endIndex;
            segment.endIndex=lastSegment.endIndex+1;
            route_segment.add(segment);
        }
        //System.out.println(route_segment.size());
    }
    public void displayRouteSegment(int current_segment){
        if(route_segment.size()==0) return;
        RouteSegment routeSegment=this.route_segment.get(current_segment);
        Log.d("point_number",points_backup.size() + ":" + accOnAlarm_Array_backup.size());
        if(routeSegment.endIndex+1 < points_backup.size()) {
            points = points_backup.subList(routeSegment.firstIndex, routeSegment.endIndex + 1);
        }
        if(routeSegment.endIndex+1 < speed_Array_backup.size()) {
            speed_Array = speed_Array_backup.subList(routeSegment.firstIndex, routeSegment.endIndex + 1);
        }
        if(routeSegment.endIndex+1 < speeding_Array_backup.size()) {
            speeding_Array = speeding_Array_backup.subList(routeSegment.firstIndex, routeSegment.endIndex + 1);
        }
        if(routeSegment.endIndex+1 < harshDriving_Array_backup.size()) {
            harshDriving_Array = harshDriving_Array_backup.subList(routeSegment.firstIndex, routeSegment.endIndex + 1);
        }
        if(routeSegment.endIndex+1 < accOffAlarm_Array_backup.size()) {
            accOffAlarm_Array = accOffAlarm_Array_backup.subList(routeSegment.firstIndex, routeSegment.endIndex + 1);
        }
        if(routeSegment.endIndex+1 < accOnAlarm_Array_backup.size()) {
            accOnAlarm_Array = accOnAlarm_Array_backup.subList(routeSegment.firstIndex, routeSegment.endIndex + 1);
        }
        if(routeSegment.endIndex+1 < dateTime_Array_backup.size()) {
            dateTime_Array = dateTime_Array_backup.subList(routeSegment.firstIndex, routeSegment.endIndex + 1);
        }
        if(routeSegment.endIndex+1 < harshAcce_Array_backup.size()) {
            harshAcce_Array = harshAcce_Array_backup.subList(routeSegment.firstIndex, routeSegment.endIndex + 1);
        }
        if(routeSegment.endIndex+1 < harshDece_Array_backup.size()) {
            harshDece_Array = harshDece_Array_backup.subList(routeSegment.firstIndex, routeSegment.endIndex + 1);
        }
        if(routeSegment.endIndex+1 < idling_Array_backup.size()) {
            idling_Array = idling_Array_backup.subList(routeSegment.firstIndex, routeSegment.endIndex + 1);
        }
        if(routeSegment.endIndex+1 < plugOut_Array_backup.size()) {
            plugOut_Array = plugOut_Array_backup.subList(routeSegment.firstIndex, routeSegment.endIndex + 1);
        }
        System.out.println(points.size());
        drawPath();
    }

    private void loadAllDrivers() {

        if (!isFragmentAlive) {
            return;
        }
        if(!Utils.isNetworkConnected(this.getContext())){
            return;
        }
        if (assetList == null) {
            assetList = new ArrayList<>();
        }

        ApiInterface apiInterface = ApiClient.getClient(this.getContext()).create(ApiInterface.class);

        apiInterface.assets(GlobalConstant.X_CSRF_TOKEN).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                if (!isFragmentAlive) {
                    return;
                }

                int code = response.code();

                GsonBuilder gsonBuilder = new GsonBuilder();
                gsonBuilder.setLongSerializationPolicy(LongSerializationPolicy.STRING);

                Gson gson = gsonBuilder.create();

                if (code == 200) {
                    // success
                    ResponseBody responseBody = response.body();
                    JSONObject object = null;

                    try {
                        object = new JSONObject(responseBody.string());
                        JSONArray items = (JSONArray) object.get("items");


                        Type type = new TypeToken<List<Resp_Asset>>() {
                        }.getType();
                        assetList = gson.fromJson(items.toString(), type);

                        for (Resp_Asset asset : assetList) {
                            asset.isSelected = false;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(ReplayFragment.this.getContext(), "response parse error");
                    }

                    setAssetSingleSelectTableData();

                } else {

                    ResponseBody errorBody = response.errorBody();
                    Resp_Error error = null;
                    try {
                        error = gson.fromJson(errorBody.string(), Resp_Error.class);
                        Utils.showShortToast(ReplayFragment.this.getContext(), error.message);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(ReplayFragment.this.getContext(), "response parse error");
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                t.printStackTrace();

                if (!isFragmentAlive) {
                    return;
                }
               // Utils.hideProgress();
                Utils.showShortToast(ReplayFragment.this.getContext(), "server connect error");
            }
        });

    }
   private String getRouteColor(int vertexCount){

        double speedInValue=speed_Array.get(vertexCount);
        String color=null;
        if(speedInValue!=0) {

          if(speedInValue<=45) {
                color="#F96F00";
            }
            else if (speedInValue>45 && speedInValue<=60) {
                color="#0000FF";
            }
            else if (speedInValue>60 && speedInValue<=80) {
                color="#32CD32";
            }
          else if (speedInValue>80) {
              color="#ff0000";
          }
            else {
                color="#FF0000";
            }
        }
        return color;
    }

    private void initRightPanel() {

        if (!isFragmentAlive) {
            return;
        }
        // txtReplayTimeFrom

        Calendar day6before = Calendar.getInstance();
        day6before.add(Calendar.DAY_OF_YEAR, 0);

        Calendar day1after = Calendar.getInstance();
        day1after.add(Calendar.DAY_OF_YEAR, 1);

        setReplayStartDate(day6before);
        setReplayEndDate(day1after);
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd");
        txt_trip_time.setText(sdf.format(replayStartDate.getTime())+" To "+sdf.format(replayEndDate.getTime()));
    }

    private void setAssetSingleSelectTableData() {
        if (!isFragmentAlive) {
            return;
        }
        // items
        adapter = new AssetListSingleSelectRecyclerViewAdapter(this, assetList, R.layout.recyclerview_row_asset_single_select);
        rvAssetSingleSelect.setAdapter(adapter);
        rvAssetSingleSelect.setLayoutManager(new LinearLayoutManager(this.getContext()));
        rvAssetSingleSelect.setItemAnimator(new DefaultItemAnimator());
        bottomView.setScrollY(getPixel(75));
    }

    private void setReplayStartDate(Calendar date) {

        if (!isFragmentAlive) {
            return;
        }
        replayStartDate = date;
    }

    private void setReplayEndDate(Calendar date) {

        if (!isFragmentAlive) {
            return;
        }
        replayEndDate = date;
    }

    private void initMap(Bundle savedInstanceState) {

        mapView.onCreate(savedInstanceState);
        mapView.setStyleUrl(GlobalConstant.MAP_BOX_STYLE_URL);
        mapView.getMapAsync(new OnMapReadyCallback() {
            @Override
            public void onMapReady(MapboxMap mapboxMap) {
                ReplayFragment.this.mapboxMap = mapboxMap;
                ReplayFragment.this.mapboxMap.setCameraPosition(new CameraPosition.Builder().target(new LatLng(38.2534189, -85.7551944)).zoom(10f).build());
               // ReplayFragment.this.mapboxMap.getUiSettings().setRotateGesturesEnabled(false);
                Utils.setMapUtilityToolsInReplay(ReplayFragment.this.mapboxMap,mapView.getRootView());

                ReplayFragment.this.mapboxMap.setOnMarkerClickListener(new MapboxMap.OnMarkerClickListener() {
                    @Override
                    public boolean onMarkerClick(@NonNull final Marker marker) {
                         List<Marker> markers=new ArrayList<Marker>(markerModels.keySet());
                         for(Marker marker1:markers) {
                             if(marker1.isInfoWindowShown()) {
                                 marker1.hideInfoWindow();
                             }
                         }

                        LatLng position=marker.getPosition();

                        final MarkerModel markerModel=markerModels.get(marker);
                        if(markerModel==null) return false;

                        else {
                            if(markerModel.markerproperty.equals(MarkerProperty.HASHDACE) || markerModel.markerproperty.equals(MarkerProperty.HASHACE) || markerModel.markerproperty.equals(MarkerProperty.SPEEDING)) {
                                return false;
                            }

                            String[] splitString=markerModel.eventTime.split(" ");

                            String[] splitString1=splitString[0].split("/");
                            String[] splitString2=splitString[1].split(":");

                            String eventTime=splitString1[0]+"/"+splitString1[1]+" "+splitString2[0]+":"+splitString2[1];

                            marker.setTitle(markerModel.markerproperty+" at "+eventTime+" "+splitString[2]);
                            marker.showInfoWindow(ReplayFragment.this.mapboxMap,mapView);
                        }
                        return false;
                    }
                });
            }
        });

    }

    @OnClick(R.id.btn_calendar)
    public void replayStartDateClick() {

        if (!isFragmentAlive) {
            return;
        }
        FragmentManager fragmentManager = this.getActivity().getSupportFragmentManager(); //Initialize fragment manager
        datePickerDialog = DatePickerDialog.newInstance(); // Create datePickerDialog Instance
        dateRangePickedListener=new DateRangePickedListener() {
            @Override
            public void OnDateRangePicked(Calendar from, Calendar to) {
                replayStartDate=from;
                replayEndDate=to;
                setReplayStartDate(from);
                setReplayEndDate(to);
                loadReplayClick();
            }
            @Override
            public void OnDatePickCancelled() {

            }
        };
        datePickerDialog.setOnDateRangePickedListener(dateRangePickedListener);
        datePickerDialog.show(fragmentManager,"Date Picker3");
    }

    @OnClick(R.id.btn_next)
    public void OnNextRouteSegment(){
        if(points == null || points.size() == 0)return;
        current_route_segment++;
        if(current_route_segment>=route_segment.size()) {
            current_route_segment=route_segment.size()-1;
        }
        if(layout_trip_log.isShown()) {
            layout_trip_log.setVisibility(View.GONE);
        }
        if(!layout_route_trip_log.isShown()) {
            layout_route_trip_log.setVisibility(View.VISIBLE);
        }
        //System.out.print();
        displayRouteSegment(current_route_segment);
        report_route_trip_table();
    }
    @OnClick(R.id.btn_previous)
    public void OnPreviousRouteSegment(){
        if(points == null || points.size() == 0)return;
        current_route_segment--;
        if(current_route_segment<0) {
            current_route_segment=0;
        }
        if(layout_trip_log.isShown()) {
            layout_trip_log.setVisibility(View.GONE);
        }
        if(!layout_route_trip_log.isShown()) {
            layout_route_trip_log.setVisibility(View.VISIBLE);
        }
        displayRouteSegment(current_route_segment);
        report_route_trip_table();
    }
    @OnClick(R.id.btn_prev_day)
    public void OnPreviousDay(){

        replayStartDate.add(Calendar.DAY_OF_YEAR, -1);
        setReplayStartDate(replayStartDate);

        replayEndDate.add(Calendar.DAY_OF_YEAR, -1);
        setReplayEndDate(replayEndDate);

        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd");
        txt_trip_time.setText(sdf.format(replayStartDate.getTime())+" To "+sdf.format(replayEndDate.getTime()));
        txt_route_trip_time.setText(sdf.format(replayStartDate.getTime())+" To "+sdf.format(replayEndDate.getTime()));

        loadReplayClick();

        if(!layout_trip_log.isShown()) {
            layout_trip_log.setVisibility(View.VISIBLE);
            layout_route_trip_log.setVisibility(View.GONE);
        }
    }
    @OnClick(R.id.btn_next_day)
    public void OnNextDay() {
        replayStartDate.add(Calendar.DAY_OF_YEAR, 1);
        setReplayStartDate(replayStartDate);

        replayEndDate.add(Calendar.DAY_OF_YEAR, 1);
        setReplayEndDate(replayEndDate);

        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd");
        txt_trip_time.setText(sdf.format(replayStartDate.getTime())+" To "+sdf.format(replayEndDate.getTime()));
        txt_route_trip_time.setText(sdf.format(replayStartDate.getTime())+" To "+sdf.format(replayEndDate.getTime()));

        loadReplayClick();

        if(!layout_trip_log.isShown()) {
            layout_trip_log.setVisibility(View.VISIBLE);
            layout_route_trip_log.setVisibility(View.GONE);
        }
    }

    @OnClick(R.id.btn_trip_log)
    public void OnTripLogButtonClick(){

        if(!tripScroll.isShown()) {
            tripScroll.setVisibility(View.VISIBLE);
        }
        else {
            tripScroll.setVisibility(View.GONE);
        }
    }
    private int getPixel(int dp) {
        int height = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, getResources().getDisplayMetrics());
        return height;
    }
    @OnClick(R.id.btn_toggle_basemap)
    public  void onToogleBaseMapClick()
    {

        if(style.equals(GlobalConstant.MAP_BOX_STYLE_URL)) {
            style=GlobalConstant.MAP_BOX_SATELLITE_URL;
        }
        else {
            style=GlobalConstant.MAP_BOX_STYLE_URL;
        }
        mapView.setStyleUrl(style);

    }

    public void setSpeed(double speed) {

        if (!isFragmentAlive) {
            return;
        }

        txtSpeed.setText(String.valueOf(speed));
        imgSpeedIndicator.setRotation(((360 - 90) * (float) speed / 100));

    }

    public void setSelectedAsset(Resp_Asset selectedAsset) {

        if (!isFragmentAlive) {
            return;
        }

        llAnimationControls.setVisibility(View.VISIBLE);
        layout_trip_log.setVisibility(View.VISIBLE);
        seekGeo.setVisibility(View.VISIBLE);

        this.selectedAsset = selectedAsset;

        if (adapter != null) {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    adapter.notifyDataSetChanged();
                }
            }, 100);
        }
    }
    //@OnClick(R.id.btn_load_replay)
    public void loadReplayClick() {

        if (!isFragmentAlive) {
            return;
        }
        if(!Utils.isNetworkConnected(this.getContext())){
            return;
        }

        if (selectedAsset == null) {
            Utils.showShortToast(this.getContext(), "please select vehicle");
            return;
        }

        if(!selectedAsset.isSelected) return;

        if(!layout_trip_log.isShown()) {
            layout_trip_log.setVisibility(View.VISIBLE);
            layout_route_trip_log.setVisibility(View.GONE);
        }
        current_route_segment = -1;
        loadReplay();
    }
    public void loadReplay(){
        geoMarker = null;
        bottomView.setScrollY(0);
        layout_route_trip_log.setVisibility(View.GONE);
        String id = selectedAsset._id;

        Date startTime = replayStartDate.getTime();
        Date endTime = replayEndDate.getTime();

        startTime.setHours(0);
        startTime.setMinutes(0);
        startTime.setSeconds(0);

        endTime.setHours(0);
        endTime.setMinutes(0);
        endTime.setSeconds(0);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        sdf.setTimeZone(TimeZone.getTimeZone("GMT"));

        String startTimeString = sdf.format(startTime);
        String endTimeString = sdf.format(endTime);

        markerModels=new HashMap<Marker, MarkerModel>();

        // Utils.showProgress(ReplayFragment.this.getContext());

        ApiInterface apiInterface = ApiClient.getClient(this.getActivity()).create(ApiInterface.class);

        apiInterface.assets_logs(GlobalConstant.X_CSRF_TOKEN, id, startTimeString, endTimeString).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                //btnOptionsShowHide.setVisibility(View.VISIBLE);
                if (!isFragmentAlive) {
                    return;
                }

                int code = response.code();

                GsonBuilder gsonBuilder = new GsonBuilder();
                gsonBuilder.setLongSerializationPolicy(LongSerializationPolicy.STRING);

                Gson gson = gsonBuilder.create();

                if (code == 200) {
                    // success
                    ResponseBody responseBody = response.body();
                    JSONObject object = null;

                    assetLogList = null;

                    try {
                        object = new JSONObject(responseBody.string());

                        JSONArray items = (JSONArray) object.get("items");
                        Log.d("aaabbbcc",items.toString());
                        Type type = new TypeToken<List<Resp_AssetLog>>() {
                        }.getType();

                        assetLogList = gson.fromJson(items.toString(), type);

                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(ReplayFragment.this.getContext(), "response parse error");
                    }
                    if (assetLogList != null) {

                        if (assetLogList.size() != 0) {
                            init_variables();
                            drawPath();
                            Log.d("datetimexxx",points.size() + ":" + accOnAlarm_Array.size() + ":" + accOffAlarm_Array.size());
                            assetLogList_backup=new ArrayList<Resp_AssetLog>(assetLogList);
                            points_backup = new ArrayList<>(points);
                            speed_Array_backup = new ArrayList<>(speed_Array);
                            speeding_Array_backup = new ArrayList<>(speeding_Array);
                            harshDriving_Array_backup = new ArrayList<>(harshDriving_Array);
                            accOffAlarm_Array_backup = new ArrayList<>(accOffAlarm_Array);
                            accOnAlarm_Array_backup=new ArrayList<>(accOnAlarm_Array);
                            dateTime_Array_backup = new ArrayList<>(dateTime_Array);
                            harshAcce_Array_backup=new ArrayList<>(harshAcce_Array);
                            harshDece_Array_backup=new ArrayList<>(harshDece_Array);
                            idling_Array_backup=new ArrayList<>(idling_Array);
                            plugOut_Array_backup=new ArrayList<>(plugOut_Array);

                            if(harshDriving_Array_backup.size()==0) {
                                for(int i=0;i<points_backup.size();i++) {
                                    harshDriving_Array_backup.add(0);
                                }
                            }
                            if(plugOut_Array_backup.size()==0) {
                                for(int i=0;i<points_backup.size();i++) {
                                    plugOut_Array_backup.add(0);
                                }
                            }

                            report_trip_table();

                            if(selectedAsset!=null) {
                                divideRoute();
                                eventNum = 1;
                                trip_index = 0;
                                display_trip();
                            }
                        }
                        else {
                            Utils.showShortToast(ReplayFragment.this.getContext(), "No Data. Change to another day");
                            txt_total_speed.setText("0");
                            txt_harsh_acce.setText("0");
                            txt_total_stops.setText("0");
                            txt_top_speed.setText("0");
                            txt_harsh_dece.setText("0");
                        }
                    }

                } else {
                    ResponseBody errorBody = response.errorBody();
                    Resp_Error error = null;
                    try {
                        error = gson.fromJson(errorBody.string(), Resp_Error.class);
                        Utils.showShortToast(ReplayFragment.this.getContext(), error.message);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(ReplayFragment.this.getContext(), "response parse error");
                    }
                }
                // Utils.hideProgress();
            }
            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                // btnOptionsShowHide.setVisibility(View.VISIBLE);
                t.printStackTrace();

                if (!isFragmentAlive) {
                    return;
                }

                Utils.showShortToast(ReplayFragment.this.getContext(), "server connect error");
            }
        });

    }
    private void display_trip() {
        if (trip_index >= route_segment.size()) {
            txtTripLog.setText(Html.fromHtml(tripLog));
            return;
        }

        RouteSegment routeSegment=this.route_segment.get(trip_index);
        List<LatLng> temp_points=points_backup.subList(routeSegment.firstIndex,routeSegment.endIndex+1);
        List<Integer> temp_accOnAlarm_Array = accOnAlarm_Array_backup.subList(routeSegment.firstIndex,routeSegment.endIndex+1);
        List<Integer> temp_accOffAlarm_Array = accOffAlarm_Array_backup.subList(routeSegment.firstIndex,routeSegment.endIndex+1);
        List<String> temp_dateTime_Array = dateTime_Array_backup.subList(routeSegment.firstIndex,routeSegment.endIndex+1);
        Log.d("routeindex",routeSegment.firstIndex + "-" + routeSegment.endIndex+1);
        if(temp_points==null) return;
        //if(points.size()<2) return;

        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
        //formatter.setTimeZone(TimeZone.);
        Date startDate=null;
        Date endDate=null;
        try{
            startDate=formatter.parse(temp_dateTime_Array.get(0));
            Log.d("startDate",temp_dateTime_Array.get(0).toString());
            endDate=formatter.parse(temp_dateTime_Array.get(temp_dateTime_Array.size()-1));

        }
        catch (Exception ex) {
            ex.printStackTrace();
        }

        long timeDiff=Math.abs((int)Math.floor(endDate.getTime()/60000)-(int)Math.floor(startDate.getTime()/60000));
        int hours=(int)Math.floor(timeDiff/60);
        double minutes=timeDiff;
        String durationText="";
        if(minutes>=60) {
            minutes=minutes-60*hours;
            durationText=String.valueOf((int)hours)+"hours"+" "+String.valueOf((int)minutes)+" minutes";
        }
        else {
            durationText=String.valueOf((int)minutes)+" minutes";
        }

        final SimpleDateFormat dateFormat=new SimpleDateFormat("MM/dd  hh:mm a");
        displayAddress = "";
        if(trip_index==0 || trip_index==route_segment.size()-1) {
           // final String eventTime=dateTime_Array.get(index);
            final String latLngString=temp_points.get(0).getLongitude()+","+temp_points.get(0).getLatitude();
            final String _durationText = durationText;
            final Date _startDate = startDate;
            final List<Integer> _accOnAlarm_Array = temp_accOnAlarm_Array;
            final List<Integer> _accOffAlarm_Array = temp_accOffAlarm_Array;
            ApiInterface apiInterface = ApiClient.getClient(this.getContext()).create(ApiInterface.class);
            apiInterface.coord2AddressMapbox(GlobalConstant.X_CSRF_TOKEN,latLngString).enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    //Utils.hideProgress();
                    if (!isFragmentAlive) {
                        return;
                    }
                    int code = response.code();
                    GsonBuilder gsonBuilder = new GsonBuilder();
                    gsonBuilder.setLongSerializationPolicy(LongSerializationPolicy.STRING);

                    Gson gson = gsonBuilder.create();

                    if (code == 200) {
                        // success
                        ResponseBody responseBody = response.body();
                        JSONObject object = null;
                        try {
                            object = new JSONObject(responseBody.string());
                            JSONArray items = (JSONArray) object.get("features");
                            JSONObject feature=(JSONObject) items.get(0);
                            String address=feature.getString("place_name");
                            if(address==null) {
                                address="("+latLngString+")";
                            }
                            DecimalFormat df = new DecimalFormat("#.####");
                            String[] splitAddess=address.split(",");
                           // String displayAddess="";
                            for(int j=0;j<splitAddess.length-3;j++) {
                                displayAddress+=splitAddess[j]+",";
                            }
                            displayAddress+=splitAddess[splitAddess.length-3];
                            if(_accOnAlarm_Array!=null && _accOnAlarm_Array.size() != 0) {
                                if (_accOnAlarm_Array.get(0) == 1) {
                                    if (!displayAddress.equals("")) {
                                        tripLog += "<p align='left' style='color:#555555; padding-top:5px'>" + eventNum + ": Trip " + _durationText + ". Left from" + displayAddress + " at " + dateFormat.format(_startDate) + " </p> ";
                                    } else {
                                        tripLog += "<p align='left' style='color:#555555; padding-top:5px'>" + eventNum + ": Trip " + _durationText + ". Left at " + dateFormat.format(_startDate) + " </p> ";
                                    }
                                    eventNum++;
                                }
                                if (_accOffAlarm_Array.get(0) == 1) {
                                    if (!displayAddress.equals("")) {
                                        tripLog += "<p align='left' style='color:#555555; padding-top:5px'>" + eventNum + ": Stop at " + displayAddress + " at " + dateFormat.format(_startDate) + " </p> ";
                                    }
                                    else {
                                        tripLog += "<p align='left' style='color:#555555; padding-top:5px'>" + eventNum + ": Stop at " + dateFormat.format(_startDate) + " for " + _durationText + ". </p> ";
                                    }
                                    eventNum++;
                                }
                            }
                            trip_index++;
                            display_trip();
                        }
                        catch (Exception e) {
                            trip_index++;
                            display_trip();
                        }
                    }
                    else {
                        trip_index++;
                        display_trip();
                    }
                }
                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    trip_index++;
                    display_trip();
                }
            });
        }
        else if(temp_accOnAlarm_Array!=null && temp_accOnAlarm_Array.size() != 0) {
            if (temp_accOnAlarm_Array.get(0) == 1) {
                tripLog += "<p align='left' style='color:#555555; padding-top:5px'>" + eventNum + ": Trip " + durationText + ". Left at " + dateFormat.format(startDate) + " </p> ";
                eventNum++;
            }
            if (temp_accOffAlarm_Array.get(0) == 1){
                tripLog += "<p align='left' style='color:#555555; padding-top:5px'>" + eventNum + ": Stop at " + dateFormat.format(startDate) + " for " + durationText + ". </p> ";
                eventNum++;
            }
            trip_index++;
            display_trip();
        }
    }
    private void report_trip_table() {
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd");
        txt_trip_time.setText(sdf.format(replayStartDate.getTime())+" To "+sdf.format(replayEndDate.getTime()));
        txt_total_speed.setText("0");
        txt_harsh_acce.setText("0");
        txt_total_stops.setText("0");
        txt_top_speed.setText("0");
        txt_harsh_dece.setText("0");
        if(points_backup.size()<2) return;
        int total_speed=0;
        float maxSpeed=0;
        int harsh_acce=0;
        int harsh_dece=0;
        int total_stops=0;
        for(int i=0;i<points_backup.size();i++) {
            maxSpeed=Math.max(maxSpeed, speed_Array_backup.get(i).floatValue());
            if(i<harshAcce_Array_backup.size()) {
                harsh_acce += harshAcce_Array_backup.get(i);
            }
            if(i<harshDece_Array_backup.size()) {
                harsh_dece += harshDece_Array_backup.get(i);
            }
            if (i<speeding_Array_backup.size() && speeding_Array_backup.get(i) == 1) {
                total_speed += speeding_Array_backup.get(i);
            }
            if (i<accOffAlarm_Array_backup.size() && accOffAlarm_Array_backup.get(i) == 1) {
                    total_stops++;
            }
        }
        txt_total_speed.setText(String.valueOf(total_speed));
        txt_harsh_acce.setText(String.valueOf(harsh_acce));
        txt_total_stops.setText(String.valueOf(total_stops));
        txt_top_speed.setText(String.format("%.2f", maxSpeed));
        txt_harsh_dece.setText(String.valueOf(harsh_dece));

    }

    private void report_route_trip_table() {

        txt_route_trip_time.setText(" ");

        txt_route_total_speed.setText("0");

        txt_route_harsh_acce.setText("0");

        txt_route_top_speed.setText("0");
        txt_route_harsh_dece.setText("0");

        if(points==null) return;
        //if(points.size()<2) return;

        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
      //  formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
        Date startDate=null;
        Date endDate=null;
        try{
            startDate=formatter.parse(dateTime_Array.get(0));
            endDate=formatter.parse(dateTime_Array.get(dateTime_Array.size()-1));
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        long timeDiff=Math.abs((int)Math.floor(endDate.getTime()/60000)-(int)Math.floor(startDate.getTime()/60000));
        int hours=(int)Math.floor(timeDiff/60);
        double minutes=timeDiff;
        String durationText="";
        if(minutes>=60) {
            minutes=minutes-60*hours;
            durationText=String.valueOf((int)hours)+"h"+" "+String.valueOf((int)minutes)+"min";
        }
        else {
            durationText=String.valueOf((int)minutes)+"min";
        }


        SimpleDateFormat dateFormat=new SimpleDateFormat("MM/dd  HH:mm");
        if(accOnAlarm_Array!=null && accOnAlarm_Array.size() != 0) {
            if (accOnAlarm_Array.get(0) == 1) {

                txt_route_trip_time.setText(durationText + " trip " + dateFormat.format(startDate) + " -- " + dateFormat.format(endDate));

            } else {
                txt_route_trip_time.setText(durationText + " stop " + dateFormat.format(startDate) + " -- " + dateFormat.format(endDate));

            }
        }
        int total_speed=0;
        float maxSpeed=0;
        int harsh_acce=0;
        int harsh_dece=0;

        for(int i=0;i<points.size();i++) {
            maxSpeed=Math.max(maxSpeed, speed_Array.get(i).floatValue());
            if(i<harshAcce_Array.size()) {
                harsh_acce += harshAcce_Array.get(i);
                harsh_dece += harshDece_Array.get(i);
                if (speeding_Array.get(i) == 1)
                    total_speed += speeding_Array.get(i);
            }
        }
        txt_route_total_speed.setText(String.valueOf(total_speed));
        txt_route_harsh_acce.setText(String.valueOf(harsh_acce));
        txt_route_top_speed.setText(String.format("%.2f", maxSpeed));
        txt_route_harsh_dece.setText(String.valueOf(harsh_dece));

    }

    @OnClick(R.id.btn_play_pause)
    public void playPauseClick() {

        if (!isFragmentAlive) {
            return;
        }
        if(points == null || points.size()==0) return;
        if (animatingTimer == null) {
            btnPlayPause.setImageResource(R.drawable.ic_pause);
//            seekGeo.setEnabled(false);
            startAnimation();
        } else {
            animatingTimer.cancel();
            animatingTimer = null;
//            seekGeo.setEnabled(true);
            btnPlayPause.setImageResource(R.drawable.ic_play);
        }
    }


    private void init_variables() {
        if(layerList_Array != null) {
            for (int i = 0; i < layerList_Array.size(); i++) {
                mapboxMap.removeLayer(layerList_Array.get(i));
            }
        }
        if(sourceList_Array != null) {
            for (int i = 0; i < sourceList_Array.size(); i++) {
                mapboxMap.removeSource(sourceList_Array.get(i));
            }
        }
        points = new ArrayList<>();
        speed_Array = new ArrayList<>();
        speeding_Array = new ArrayList<>();
        harshDriving_Array = new ArrayList<>();
        accOffAlarm_Array = new ArrayList<>();
        accOnAlarm_Array=new ArrayList<>();
        dateTime_Array = new ArrayList<>();
        layerList_Array = new ArrayList<>();
        sourceList_Array = new ArrayList<>();
        harshAcce_Array=new ArrayList<>();
        harshDece_Array=new ArrayList<>();
        idling_Array=new ArrayList<>();
        plugOut_Array=new ArrayList<>();

        int  ACCStatusNum=0;
        LatLng  coorOld=null;
        double speedOld=80;
        int accStatusOld=0;

        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");

        for (int i = 0; i < assetLogList.size(); i++) {

            Resp_AssetLog device = assetLogList.get(i);
            Log.d("datetimexxx",device.dateTime.toString() + ":" + device.ACCStatus);
            double lat = Math.abs(device.lat);
            double lng = Math.abs(device.lng);
            String trackerModel = device.trackerModel;
            double  diffTime = 200;

            //LIAN
            if (lat != 0 && lng != 0) {


                String dateTime="";
                try {
                    if(device.dateTime==null) {
                        device.dateTime=new Date();
                    }
                    dateTime = sdf.format(device.dateTime);
                }
                catch (Exception ex) {
                    System.out.println(device.dateTime);
                }
                //String

                LatLng point = new LatLng(device.lat, device.lng);


                if (trackerModel.equals("huaheng") || trackerModel.equals("mictrack")) {

                    if (i!=0 && i!=assetLogList.size()-1) {
                        Date dateTimeNow=assetLogList.get(i).dateTime;
                        Date dateTimeNext=assetLogList.get(i+1).dateTime;
                        diffTime = (dateTimeNext.getTime()-dateTimeNow.getTime());
                        //console.log(diffTime, devices[i].ACCStatus, devices[i+1].ACCStatus);
                    }

                    if (device.ACCStatus==1 && accStatusOld==0 && diffTime>12000) {	//start; avoid false start
                        accOnAlarm_Array.add(1);
                        accOffAlarm_Array.add(0);
                    }
                    else if (device.ACCStatus==0 && accStatusOld==1 ) { //from on to off; avoid false stop
                        coorOld= point;
                        accOffAlarm_Array.add(1);
                        accOnAlarm_Array.add(0);
                    }
                    else if (device.ACCStatus==0 && accStatusOld ==0) { //off to off
                        if (coorOld != null) {
                            point = coorOld;
                        } else {
                            coorOld = point;
                        }
                        accOffAlarm_Array.add(0);
                        accOnAlarm_Array.add(0);
                    }
                    else {
                        accOffAlarm_Array.add(0);
                        accOnAlarm_Array.add(0);
                    }

                    accStatusOld = device.ACCStatus;
                }


                //avoid shiffing during parking
                if (trackerModel.equals("sinocastel")) {

                    if (device.speedInMph==0 &&  ACCStatusNum ==0) {
                        coorOld= point;
                        ACCStatusNum++;
                    }
                    else if (device.speedInMph==0  && ACCStatusNum >0)
                    {
                        point = coorOld;
                    }
                    else {
                        ACCStatusNum =0;
                    }
                }

                //console.log(dateTime, device.ACCStatus, coor, device.speedInMph);

                points.add(point);

                speed_Array.add(device.speedInMph);
                dateTime_Array.add(dateTime);

                //check vehicle status and add to alarmArray

                if (trackerModel.equals("huaheng")) {

                    if ( device.huaheng!=null) {  //alarm array; only huahengOBDPackage has device.huaheng field

                        int alarm=device.huaheng.alarmNumberAdd1-1;
                        if(alarm == 3){
                            speeding_Array.add(1);
                        }
                        else {
                            speeding_Array.add(0);
                        }

                        if (alarm ==7)  {
                            harshDece_Array.add(1);
                        }
                        else {
                            harshDece_Array.add(0);
                        }

                        if (alarm ==8)  {
                            harshAcce_Array.add(1);
                        }
                        else {
                            harshAcce_Array.add(0);
                        }

                        if (alarm ==14)  {
                            idling_Array.add(1);
                        }
                        else {
                            idling_Array.add(0);
                        }

                        if (alarm ==16)  {
                            plugOut_Array.add(1);
                        }
                        else {
                            plugOut_Array.add(0);
                        }

                    }
                    else {
                        speeding_Array.add(0);
                        harshDece_Array.add(0);
                        harshAcce_Array.add(0);
                        idling_Array.add(0);
                        plugOut_Array.add(0);
                    }
                }
                else if (trackerModel.equals("sinocastel") && ! device.reportType.equals("sinoOBDPackage")) {
                    //IMPORTANT undefined when there is no alarm in the alarmPackage.
                    // OBD package has device.sinocastel but has no coor, do not push to alarm for OBDPackage
                    // otherwise, the coor array length is not the same as alarm array
                    if (device.reportType.equals("sinoAlarmPackage") &&  device.sinocastel!=null) { //alarmPackage, must have vehicleStatus
                        Resp_AssetLog.vehicleStatusType vehicleStatus=device.sinocastel.vehicleStatus;

                        if(vehicleStatus!=null) {
                            if (vehicleStatus.hardAcce!=null) {
                                harshAcce_Array.add(1);
                            }
                            else {
                                harshAcce_Array.add(0);
                            }
                            if (vehicleStatus.hardDece!=null){
                                harshDece_Array.add(1);
                            }
                            else {
                                harshDece_Array.add(0);
                            }

                            if (vehicleStatus.idleEngine!=null){
                                idling_Array.add(1);
                            }
                            else {
                                idling_Array.add(0);
                            }

                            if (vehicleStatus.ignitionOff!=null) {
                                accOffAlarm_Array.add(1);
                                accOnAlarm_Array.add(0);
                            }
                            else if(vehicleStatus.ignitionOn!=null){
                                accOnAlarm_Array.add(1);
                                accOffAlarm_Array.add(0);
                            }
                            else {
                                accOnAlarm_Array.add(0);
                                accOffAlarm_Array.add(0);
                            }

                            if (vehicleStatus.speeding!=null) {
                                speeding_Array.add(1);
                            }
                            else {
                                speeding_Array.add(0);
                            }
                        }
                        else {
                            idling_Array.add(0);
                            harshAcce_Array.add(0);
                            harshDece_Array.add(0);
                            accOffAlarm_Array.add(0);
                            speeding_Array.add(0);
                            accOnAlarm_Array.add(0);

                        }
                    }
                    else{  //gps package that has no vehicleStatus
                        idling_Array.add(0);
                        harshAcce_Array.add(0);
                        harshDece_Array.add(0);
                        accOffAlarm_Array.add(0);
                        speeding_Array.add(0);
                        accOnAlarm_Array.add(0);
                    }
                }
                else if (trackerModel.equals("cctr")) {

                    if (device.cctr !=null) {
                        if (device.cctr.vehicleStatus !=null) {
                            Resp_AssetLog.vehicleStatusType vehicleStatus = device.cctr.vehicleStatus;

                            harshDriving_Array.add(0);

                            if (vehicleStatus.overSpeed2==1) {
                                speeding_Array.add(1);
                            }
                            else {
                                speeding_Array.add(0);
                            }
                        }
                        else {
                            idling_Array.add(0);
                            harshAcce_Array.add(0);
                            harshDece_Array.add(0);
                            accOffAlarm_Array.add(0);
                            accOnAlarm_Array.add(0);
                            speeding_Array.add(0);
                        }
                    }
                }
                else {
                    idling_Array.add(0);
                    harshAcce_Array.add(0);
                    harshDece_Array.add(0);
                    accOffAlarm_Array.add(0);
                    accOnAlarm_Array.add(0);
                    speeding_Array.add(0);
                }

            }

        }
    }

    Marker marker=null;
    int index=0;
    int eventNum=0;
    String tripLog="";


    private void drawPath() {

        if(geoMarker!=null){
            mapboxMap.removeMarker(geoMarker);
            geoMarker=null;
        }

        mapboxMap.clear();
        mapboxMap.removeAnnotations();
        for (int i=0;i<layerList_Array.size();i++)
        {
            mapboxMap.removeLayer(layerList_Array.get(i));
        }
        for (int i=0;i<sourceList_Array.size();i++)
        {
            mapboxMap.removeSource(sourceList_Array.get(i));
        }
        final IconFactory iconFactory = IconFactory.getInstance(ReplayFragment.this.getContext());

        final Icon geoIcon = iconFactory.fromResource(R.drawable.cartoprightsmall);
        //final Icon arrowIcon=iconFactory.fromResource(R.drawable.greenarrow);

        ReplayFragment.this.getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                geoMarker = mapboxMap.addMarker(new MarkerViewOptions()
                        .position(points.get(0))
                        .icon(geoIcon).anchor(0.5f,0.5f)
                );
            }
        });
        index=0;
        LatLngBounds.Builder latLngBoundsBuilder = new LatLngBounds.Builder();
        LatLng lastCoordinate = points.get(0);
        if (current_route_segment != -1 && route_segment.get(current_route_segment).firstValue != 1)
        {
            latLngBoundsBuilder.include(points.get(0));
            marker = mapboxMap.addMarker(new MarkerOptions()
                    .position(points.get(0))
                    .setIcon(iconFactory.fromResource(R.drawable.stop))
            );
            Point pt1 = Point.fromCoordinates(Position.fromCoordinates(points.get(0).getLongitude(), points.get(0).getLatitude()));
            Feature f1 = Feature.fromGeometry(pt1);
            f1.addStringProperty("property", Utils.trucatLabelString(String.valueOf((int)(current_route_segment+1)), 5));
            GeoJsonSource geoJsonSource = new GeoJsonSource("stopId" + index, f1);
            mapboxMap.addSource(geoJsonSource);
            CircleLayer layer = new CircleLayer("stopCircle" + index, "stopId" + index);
            layer.setProperties(
                    PropertyFactory.visibility(Property.VISIBLE),
                    PropertyFactory.circleRadius(9f),
                    PropertyFactory.circleColor(Color.RED),
                    PropertyFactory.circleStrokeWidth(1f),
                    PropertyFactory.circleStrokeColor(Color.WHITE),
                    PropertyFactory.iconImage("stopImage" + index)
            );
            mapboxMap.addLayer(layer);
            SymbolLayer labelLayer = new SymbolLayer("stopLabel" + index, "stopId" + index);
            labelLayer.setProperties(textField("{property}"),
                    textSize(11f),
                    textColor(Color.WHITE),
                    textAllowOverlap(true)
            );
            mapboxMap.addLayer(labelLayer);
            layerList_Array.add("stopCircle" + index);
            layerList_Array.add("stopLabel" + index);
            sourceList_Array.add("stopId" + index);
            markerModels.put(marker, new MarkerModel(MarkerProperty.STOP, dateTime_Array.get(index), index));
        }
        else {

            for (int i = 0; i < points.size(); i++) {
                latLngBoundsBuilder.include(points.get(i));
            }

            PolylineOptions polylineOptions = null;

            String color = "#0000FF";
            String previousColor = "#FE2EF7";
            lastCoordinate = points.get(points.size() - 1);
            for (int i = 0; i < points.size() - 1; i++) {
                LatLng start = points.get(i);
                LatLng end = points.get(i + 1);
                Log.d("result", start.toString());
                System.out.print(start.toString());
                color = getRouteColor(i);
                if (color == null) color = "#0000FF";
                if (polylineOptions == null) {
                    polylineOptions = new PolylineOptions();
                    polylineOptions.add(start, end);
                } else {
                    if (!color.equals(previousColor)) {
                        polylineOptions.color(Color.parseColor(previousColor)).width(4);
                        Polyline polyline = mapboxMap.addPolyline(polylineOptions);
                        polylineOptions = new PolylineOptions();
                        polylineOptions.add(start, end);
                    } else polylineOptions.add(end);
                }

                if (end.getLatitude() == lastCoordinate.getLatitude() && end.getLongitude() == lastCoordinate.getLongitude()) {
                    polylineOptions.color(Color.parseColor(color)).width(4);
                    Polyline polyline = mapboxMap.addPolyline(polylineOptions);
                }
                previousColor = color;

            }

            int routeLength = points.size();
            seekGeo.setMax(routeLength - 1);
            geoMarkerIndex = 0;
            eventNum=1;
            tripLog="";
            int firstStop=accOffAlarm_Array.size(), lastStop=0;

            for (int i=0; i<accOffAlarm_Array.size(); i++){
                if (accOffAlarm_Array.get(i)==1) {
                    if (i<firstStop) firstStop=i;
                    if (i>lastStop) lastStop=i;
                }
            }
            getReportLog(firstStop, lastStop, routeLength);
        }
        try {

            LatLngBounds latLngBounds = latLngBoundsBuilder.build();
            mapboxMap.moveCamera(CameraUpdateFactory.newLatLngBounds(latLngBounds, 150, 350, 150, 150));

            double zoomScale = mapboxMap.getCameraPosition().zoom;

            if (zoomScale > defaultZoom) {

                CameraPosition cameraPosition = new CameraPosition.Builder().target(new LatLng(latLngBounds.getCenter().getLatitude(), latLngBounds.getCenter().getLongitude())).bearing(0).tilt(0).zoom(defaultZoom).build();
                mapboxMap.setCameraPosition(cameraPosition);

            }

        } catch (Exception ex) {
            // LatLng lastCoordinate=points.get(points.size()-1);
            CameraPosition cameraPosition = new CameraPosition.Builder().target(lastCoordinate).bearing(0).tilt(0).zoom(defaultZoom).build();
            mapboxMap.setCameraPosition(cameraPosition);
            //  return;
        }

    }

    private void getReportLog(final int firstStop, final int lastStop, final int routeLength) {
        if(index>=points.size()) return;
        LatLng currentPoint = points.get(index);
        final IconFactory iconFactory = IconFactory.getInstance(ReplayFragment.this.getContext());

        if(accOffAlarm_Array.size()>index){
            if(accOffAlarm_Array.get(index)==1) {
                if(current_route_segment !=-1) {
                    marker = mapboxMap.addMarker(new MarkerOptions()
                            .position(currentPoint)
                            .setIcon(iconFactory.fromResource(R.drawable.stop))
                    );
                    Point pt1 = Point.fromCoordinates(Position.fromCoordinates(currentPoint.getLongitude(), currentPoint.getLatitude()));
                    Feature f1 = Feature.fromGeometry(pt1);
                    f1.addStringProperty("property", Utils.trucatLabelString(String.valueOf((int)(current_route_segment+1)), 5));
                    GeoJsonSource geoJsonSource = new GeoJsonSource("stopId" + index, f1);
                    mapboxMap.addSource(geoJsonSource);
                    CircleLayer layer = new CircleLayer("stopCircle" + index, "stopId" + index);
                    layer.setProperties(
                            PropertyFactory.visibility(Property.VISIBLE),
                            PropertyFactory.circleRadius(9f),
                            PropertyFactory.circleColor(Color.RED),
                            PropertyFactory.circleStrokeWidth(1f),
                            PropertyFactory.circleStrokeColor(Color.WHITE),
                            PropertyFactory.iconImage("stopImage" + index)
                    );
                    mapboxMap.addLayer(layer);
                    SymbolLayer labelLayer = new SymbolLayer("stopLabel" + index, "stopId" + index);
                    labelLayer.setProperties(textField("{property}"),
                            textSize(11f),
                            textColor(Color.WHITE),
                            textAllowOverlap(true)
                    );
                    mapboxMap.addLayer(labelLayer);
                    layerList_Array.add("stopCircle" + index);
                    layerList_Array.add("stopLabel" + index);
                    sourceList_Array.add("stopId" + index);
                    markerModels.put(marker, new MarkerModel(MarkerProperty.STOP, dateTime_Array.get(index), index));
                }
                else {
                    marker = mapboxMap.addMarker(new MarkerOptions()
                            .position(currentPoint)
                            .setIcon(iconFactory.fromResource(R.drawable.stop_all))
                    );
                    markerModels.put(marker, new MarkerModel(MarkerProperty.STOP, dateTime_Array.get(index), index));
                }
            }
        }

        if(accOnAlarm_Array.size()>index){
            if(accOnAlarm_Array.get(index)==1) {
                if(current_route_segment!=-1) {
                    marker=  mapboxMap.addMarker(new MarkerOptions()
                            .position(currentPoint)
                            .setIcon(iconFactory.fromResource(R.drawable.start))
                    );
                    Point pt1 = Point.fromCoordinates(Position.fromCoordinates(currentPoint.getLongitude(), currentPoint.getLatitude()));
                    Feature f1 = Feature.fromGeometry(pt1);
                    f1.addStringProperty("property", Utils.trucatLabelString(String.valueOf((int)(current_route_segment+1)), 5));
                    GeoJsonSource geoJsonSource = new GeoJsonSource("startId" + index, f1);
                    mapboxMap.addSource(geoJsonSource);
                    CircleLayer layer = new CircleLayer("startCircle" + index, "startId" + index);
                    layer.setProperties(
                            PropertyFactory.visibility(Property.VISIBLE),
                            PropertyFactory.circleRadius(9f),
                            PropertyFactory.circleColor(Color.parseColor("#7bb24d")),
                            PropertyFactory.circleStrokeWidth(1f),
                            PropertyFactory.circleStrokeColor(Color.WHITE),
                            PropertyFactory.iconImage("startImage" + index)
                    );
                    mapboxMap.addLayer(layer);
                    SymbolLayer labelLayer = new SymbolLayer("startLabel" + index, "startId" + index);
                    labelLayer.setProperties(textField("{property}"),
                            textSize(11f),
                            textColor(Color.WHITE),
                            textAllowOverlap(true)
                    );
                    mapboxMap.addLayer(labelLayer);
                    layerList_Array.add("startCircle" + index);
                    layerList_Array.add("startLabel" + index);
                    sourceList_Array.add("startId" + index);
                    markerModels.put(marker,new MarkerModel(MarkerProperty.START,dateTime_Array.get(index),index));
                }
               else {
                    marker=  mapboxMap.addMarker(new MarkerOptions()
                            .position(currentPoint)
                            .setIcon(iconFactory.fromResource(R.drawable.start_all))
                    );
                    markerModels.put(marker,new MarkerModel(MarkerProperty.START,dateTime_Array.get(index),index));
                }
            }
        }

        if(speeding_Array.size()>index){
            if (speeding_Array.get(index) == 1) {
              marker= mapboxMap.addMarker(new MarkerOptions()
                        .position(currentPoint)
                        .setIcon(iconFactory.fromResource(R.drawable.totalspeeding))
                );
                markerModels.put(marker,new MarkerModel(MarkerProperty.SPEEDING,dateTime_Array.get(index),index));
            }
        }

        if(harshAcce_Array.size()>index) {
            if (harshAcce_Array.get(index) == 1) {
              marker= mapboxMap.addMarker(new MarkerOptions()
                        .position(currentPoint)
                        .setIcon(iconFactory.fromResource(R.drawable.harsh_acce_image))

                );
                markerModels.put(marker,new MarkerModel(MarkerProperty.HASHACE,dateTime_Array.get(index),index));
            }
        }

        if(harshDece_Array.size()>index) {
            if (harshDece_Array.get(index) == 1) {
               marker= mapboxMap.addMarker(new MarkerOptions()
                        .position(currentPoint)
                        .setIcon(iconFactory.fromResource(R.drawable.harsh_dece_image))


                );
                markerModels.put(marker,new MarkerModel(MarkerProperty.HASHDACE,dateTime_Array.get(index),index));
            }
        }
        if(idling_Array.size()>index) {
            if (idling_Array.get(index) == 1) {

             marker= mapboxMap.addMarker(new MarkerOptions()
                        .position(currentPoint)
                        .setIcon(iconFactory.fromResource(R.drawable.idling_image))

                );
                markerModels.put(marker,new MarkerModel(MarkerProperty.IDLING,dateTime_Array.get(index),index));

            }
        }
        index++;
        if (index < routeLength) {
            getReportLog(firstStop, lastStop, routeLength);
        }
    }

    private void startAnimation() {

        if (animatingTimer != null) {
            animatingTimer.cancel();
        } else {
            animatingTimer = new Timer();
        }

        animatingTimer.schedule(new TimerTask() {
            @SuppressLint("NewApi")
            @Override
            public void run() {

                if (!isFragmentAlive || points == null) {
                    return;
                }

                if (geoMarkerIndex >= points.size()) {
                    animatingTimer.cancel();
                    animatingTimer = null;

                    ReplayFragment.this.getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            btnPlayPause.setImageResource(R.drawable.ic_play);
                            seekGeo.setEnabled(true);
                        }
                    });
                    return;
                }

                showReplayPointOfIndex();
                geoMarkerIndex++;

            }
        }, 0, 1000);

    }

    private void showReplayPointOfIndex() {
        if(points == null || points.size()==0) return;

        if (geoMarkerIndex >= points.size()) {
            if (animatingTimer != null) {
                animatingTimer.cancel();
            }
            animatingTimer = null;

            ReplayFragment.this.getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    btnPlayPause.setImageResource(R.drawable.ic_play);
                    seekGeo.setEnabled(true);
                    if (geoMarker == null) {
                        return;
                    }
                }
            });

            return;
        }

        ReplayFragment.this.getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                LatLng point = points.get(geoMarkerIndex);

                float rotation=0;
                if(geoMarkerIndex<points.size()-1) {
                    LatLng nextPoint=points.get(geoMarkerIndex+1);
                    rotation=(float)computeHeading(point,nextPoint);
                }
                if(point==null) {
                    System.out.println(geoMarkerIndex);
                    System.out.println(" point null");
                }
                if(geoMarker==null) {
                    IconFactory iconFactory = IconFactory.getInstance(ReplayFragment.this.getContext());

                    Icon geoIcon = iconFactory.fromResource(R.drawable.cartoprightsmall);

                    geoMarker = mapboxMap.addMarker(new MarkerViewOptions()
                            .position(points.get(0))
                            .icon(geoIcon).anchor(0.5f,0.5f)
                    );
                }
                geoMarker.setPosition(point);
                LatLngBounds latLngBounds=mapboxMap.getProjection().getVisibleRegion().latLngBounds;
                if(!latLngBounds.contains(point))
                ReplayFragment.this.mapboxMap.setCameraPosition(new CameraPosition.Builder().target(point).build());
                geoMarker.setRotation(rotation);
            }
        });

        final double speed = Math.min(speed_Array.get(geoMarkerIndex), 100);
        final String dateString = dateTime_Array.get(geoMarkerIndex);

        ReplayFragment.this.getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                setSpeed(speed);
                SimpleDateFormat sdf = new SimpleDateFormat("MM/dd hh:mm aaa");
                Date d=new Date(dateString);
                txtGageDate.setText(sdf.format(d));
            }
        });

        seekGeo.post(new Runnable() {
            @Override
            public void run() {
                seekGeo.setProgress(geoMarkerIndex);
            }
        });
        Runtime.getRuntime().gc();
        System.gc();
    }
    public static double computeHeading(LatLng from, LatLng to) {
        double fromLat = Math.toRadians(from.getLatitude());
        double fromLng = Math.toRadians(from.getLongitude());
        double toLat = Math.toRadians(to.getLatitude());
        double toLng = Math.toRadians(to.getLongitude());
        double dLng = toLng - fromLng;
        double heading = Math.atan2(Math.sin(dLng) * Math.cos(toLat),
                Math.cos(fromLat) * Math.sin(toLat) - Math.sin(fromLat) * Math.cos(toLat) * Math.cos(dLng));
        return (Math.toDegrees(heading) >= -180 && Math.toDegrees(heading) < 180) ?
                Math.toDegrees(heading)-90 : ((((Math.toDegrees(heading) + 180) % 360) + 360) % 360 + -180)-90;
    }


    @Override
    public void onStart() {
        super.onStart();

    }

    @Override
    public void onPause() {
        super.onPause();

    }
    @Override
    public void onResume() {
        super.onResume();


    }
    @Override
    public  void onStop(){
        super.onStop();

    }


    private void geocode(final LatLng latLng, final Marker marker,final String date_time){

        String latLngString=latLng.getLongitude()+","+latLng.getLatitude();
        ApiInterface apiInterface = ApiClient.getClient(this.getContext()).create(ApiInterface.class);
        apiInterface.coord2AddressMapbox(GlobalConstant.X_CSRF_TOKEN,latLngString).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                //Utils.hideProgress();
                if (!isFragmentAlive) {
                    return;
                }

                int code = response.code();

                GsonBuilder gsonBuilder = new GsonBuilder();
                gsonBuilder.setLongSerializationPolicy(LongSerializationPolicy.STRING);

                Gson gson = gsonBuilder.create();

                if (code == 200) {
                    // success
                    ResponseBody responseBody = response.body();
                    JSONObject object = null;

                    try {
                        object = new JSONObject(responseBody.string());
                        JSONArray items = (JSONArray) object.get("features");
                        JSONObject feature=(JSONObject) items.get(0);
                        String place_name=feature.getString("place_name");

                        DecimalFormat df = new DecimalFormat("#.####");

                            marker.setTitle(place_name+"\n"+date_time);
                            //marker.getInfoWindow().update();
                            marker.showInfoWindow(mapboxMap,mapView);
                            //mapboxMap.selectMarker(marker);

                        System.out.println("ok");

                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(ReplayFragment.this.getContext(), "response parse error");
                    }


                } else {

                    if (!isFragmentAlive) {
                        return;
                    }

                    ResponseBody errorBody = response.errorBody();
                    Resp_Error error = null;
                    try {
                        error = gson.fromJson(errorBody.string(), Resp_Error.class);
                        Utils.showShortToast(ReplayFragment.this.getContext(), error.message);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Utils.showShortToast(ReplayFragment.this.getContext(), "response parse error");
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                //Utils.hideProgress();
                t.printStackTrace();

                if (!isFragmentAlive) {
                    return;
                }
                //pBarLoading.setVisibility(View.INVISIBLE);
                Utils.showShortToast(ReplayFragment.this.getContext(), "server connect error");
                //loadDriversThread();
            }
        });

    }

    public void monitor_replay(Resp_Asset asset) {
        isFragmentAlive=true;
        this.selectedAsset=asset;
        Calendar day6before = Calendar.getInstance();
        day6before.add(Calendar.DAY_OF_YEAR, 0);
        replayStartDate=day6before;


        Calendar day1after = Calendar.getInstance();
        day1after.add(Calendar.DAY_OF_YEAR, 1);

        replayEndDate=day1after;

        loadReplay();

    }

    public interface MarkerProperty{
        public static final String STOP="stop";
        public static final String IDLING="idling";
        public static final String SPEEDING="speeding";
        public static final String HASHACE="harshAcce";
        public static final String HASHDACE="harshDace";
        public static final String START = "start";
    }
    private class MarkerModel{
        public MarkerModel(String markerproperty,String eventTime,int index){
            this.markerproperty=markerproperty;
            this.eventTime=eventTime;
            this.index=index;
        }
        public String markerproperty;
        public String eventTime;
        public int    index;
    }
    private class RouteSegment{
        public int firstIndex;
        public int endIndex;
        public int firstValue;
        public int endValue;

    }
    private String  coord2Address2(double lat, double lng, final AddressCallbak addressCallbakCallback) {
        String address="";

        ApiInterface apiInterface = ApiClient.getClient(ReplayFragment.this.getContext()).create(ApiInterface.class);
        Call<ResponseBody> call=apiInterface.coord2Address(GlobalConstant.X_CSRF_TOKEN,lng+","+lat);

        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                String  responseBody = null;
                try {
                    responseBody = response.body().string();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                JSONObject object = null;

                try {
                    object = new JSONObject(responseBody);
                    JSONArray items = (JSONArray) object.get("features");
                    JSONObject feature=(JSONObject) items.get(0);
                    addressCallbakCallback.onSuccess( feature.getString("place_name"));

                    System.out.println("ok");

                } catch (Exception e) {
                    e.printStackTrace();

                }

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                addressCallbakCallback.onError( t);

            }
        });
        return address;
    }
}
